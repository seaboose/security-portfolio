# When the timer reaches eight

The caller in both builds passes equal values at main +0x57 and +0x5A (`0F 28 CE`, `0F 28 C6`), then calls ready at +0x5D (`E8 00 00 00 00`). These are relocatable object bytes. The listing resolves the call to ready. At +0x62 the caller tests AL (`84 C0`); at +0x64 it jumps to failure if AL is zero (`74 48`).

The entire plain routine is eight bytes. At +0x00, `66 0F 2F C8` compares deadline against now. At +0x04, `0F 96 C0` sets AL when deadline is below **or equal to** now. At +0x07, `C3` returns.

The encoded routine implements the same decision with two constants:

```text
+00  66 0F 2F C8       compare deadline with now
+04  B8 C3 00 00 00    EAX = C3
+09  B9 5A 00 00 00    ECX = 5A
+0E  0F 47 C1          copy ECX to EAX if deadline is above now
+11  88 44 24 08       store AL on the stack
+15  0F B6 44 24 08    read that byte back
+1A  3C C3             compare AL with C3
+1C  0F 94 C0          set AL if equal
+1F  C3                return
```

**Decision.** At 7.75 both return 0. At 8.00 both return 1. At 8.25 both return 1. Equality leaves C3 in place in the encoded routine. This conclusion covers the finite inputs in the exercise.

### Blind comparison on the published objects

The four fresh, local Qwen3 8B submissions all chose `now <= deadline`. The initial and revised answers for each build scored **3/9**. All three equality tests passed and all six unequal cases failed. The strict comparison `now > deadline` scores **6/9**, and the instruction-derived decision `now >= deadline` scores **9/9**.

The paired rerun kept the historical anonymous packet IDs, disassembly and settings fixed. Each build received one initial request and one revision after public feedback. A fresh, stateless request received only its own packet and, for a revision, its initial answer and feedback. The two rebuilt objects have new file fingerprints and identical instruction bytes. The sealed report binds to these new files.

An earlier randomized run on these same files stopped after its first request for the plain build. The model marked its response as an abstention while supplying a predicate and a citation. The validator rejected it. That run has no score, revision or second submission. Its original event was retained in the private review records. No individual stage was retried.
