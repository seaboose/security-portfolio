# Does the cooldown expire exactly on time?

Use the supplied Windows desktop app. This exercise needs Python with Tk and the bundled example files. Leave Surge closed.

1. Double-click **Insight-Windows/Launch Insight.pyw**. Choose **File → Explore example · plain**. In the routine selector choose **main**. Offsets in this exercise start at zero within each routine.
2. Select the call at **+0x5D**. The byte view should highlight **E8 00 00 00 00**. The caller has just copied the same double into both input registers. Write down your prediction for equality.
3. Select **ready** in the routine selector. Read the three instructions. Select **+0x04** and check which condition sets the low return byte, AL. The comparison operands are deadline in XMM1 and current time in XMM0.
4. Choose **File → Explore example · encoded**, then **ready**. Select **+0x0E**, **+0x1A** and **+0x1C** in turn. Track which constant survives when the inputs are equal.
5. **Final decision:** At a deadline of 8 seconds, what does each build return at 7.75, 8.00 and 8.25? Write the three answers before opening the [worked paper](Worked%20paper.md).

To check the experiment offline, open **Investigation → Blind trials… → Verify and reveal both…**. Expect two builds with an initial and revised attempt each. The scores belong to the recorded model attempts.

For an independent offline check of all four original model responses, open PowerShell in the **Insight-Windows** folder and run:

```powershell
python -B -m insight.blind verify cases/survive-cooldown/blind --events cases/survive-cooldown/blind/events
```

Expect four scored submissions and the pair fingerprint `b712d5b7d09bcd24fd2b51c4030d703dc46271f5c93253eea7b4ba792b8bd5c5`. This command reads the saved evidence and works offline.
