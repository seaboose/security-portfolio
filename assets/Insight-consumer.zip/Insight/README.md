# Insight

Insight is a native Windows x64 workbench for read-only binary investigation. On Windows with Python 3.12 or later and Tk, open **Insight-Windows/Launch Insight.pyw**. The bundled cooldown example works with its retained listings. Opening an independent DLL requires the MSVC x64 build tools. See the [Windows setup instructions](Insight-Windows/README.md) for optional Ghidra decompilation.

| Start here | Then read |
| --- | --- |
| [1 · Inspect a cooldown boundary](examples/01-cooldown/Field%20guide.md) | [Worked paper and decision](examples/01-cooldown/Worked%20paper.md) |
| [2 · Take a Surge observation through Insight and back into a report](examples/02-surge-handoff/Field%20guide.md) | [Worked paper and decision](examples/02-surge-handoff/Worked%20paper.md) |

For the second guide, the included setup program installs the pinned Windows x64 Electron runtime from its official release and verifies the download. Both guides use recorded evidence. The optional Surge live collector is unsigned and may be blocked by Windows Application Control.

Use a new report and export folder for each run. Notes, revisions and findings are separate from the source binaries.

## License

Insight is copyright Sebastian Marquez and available under the [MIT License](LICENSE). Bundled components retain their own licenses. See the [third-party notices](Surge/THIRD-PARTY-NOTICES.txt).
