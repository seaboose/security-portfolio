# Native evidence examples

In Surge, choose **Case library → Open case file** and select one of the five cases in this folder. Each contains two samples of two ranges. Clear **Findings only** to see all four records, then select record 3 to inspect the second sample’s first range.

| Case | Expected result |
| --- | --- |
| approved-update | All four observations match the approved build. |
| unapproved-update | All four require review because the build lacks approval. |
| changed-code | The bytes in one sampled range differ from the approved bytes. |
| unreadable | One range could not be read and its result is unknown. |
| outside-coverage | All four samples match. A controlled change outside both sampled ranges goes undetected. |

The cases derive from captures on the Surge-owned sample. Paths, process identifiers, addresses and timings were normalized for publication. Use the recorded bytes and coverage to interpret each result. The accompanying `expected.json` lists the expected outcomes.
