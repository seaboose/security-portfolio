@echo off
setlocal
cd /d "%~dp0" || exit /b 1
if not defined SURGE_PYTHON for %%P in (python.exe) do set "SURGE_PYTHON=%%~$PATH:P"
if not defined SURGE_PYTHON goto setup
if not exist "runtime\electron.exe" goto setup
set "ELECTRON_RUN_AS_NODE="
set "NODE_OPTIONS="
set "NODE_PATH="
"runtime\electron.exe" .
exit /b %errorlevel%
:setup
echo Install Python and run "Set up Surge.py" as described in the field guide.
pause
exit /b 1
