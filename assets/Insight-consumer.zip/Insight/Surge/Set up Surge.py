"""Install the verified Windows x64 Electron runtime beside the Surge receiver."""

import hashlib
from pathlib import Path
import sys
from tempfile import TemporaryDirectory
from urllib.request import urlopen
from zipfile import ZipFile

VERSION = "44.11.3"
ARCHIVE = f"electron-v{VERSION}-win32-x64.zip"
URL = f"https://github.com/electron/electron/releases/download/v{VERSION}/{ARCHIVE}"
SHA256 = "97fca9b8e9b90cdc88c1efd44160ca4b89b15101721d93c8befcbeb35b93fb59"
SIZE = 158283059
ROOT = Path(__file__).resolve().parent


def install(source=None):
    target = ROOT / "runtime"
    if target.exists():
        raise ValueError("The runtime folder already exists. To reinstall, move it aside first.")
    with TemporaryDirectory(dir=ROOT) as scratch:
        temporary = Path(scratch)
        archive = temporary / ARCHIVE
        print(f"Verifying Electron {VERSION} for Windows x64…", flush=True)
        with (source.open("rb") if source else urlopen(URL, timeout=90)) as incoming, archive.open("xb") as output:
            checksum = hashlib.sha256()
            length = 0
            while chunk := incoming.read(1024 * 1024):
                length += len(chunk)
                if length > SIZE:
                    raise ValueError("Unexpected runtime archive size.")
                checksum.update(chunk)
                output.write(chunk)
        if length != SIZE or checksum.hexdigest() != SHA256:
            raise ValueError("The runtime archive failed its size or SHA-256 check.")
        extracted = temporary / "runtime"
        with ZipFile(archive) as package:
            package.extractall(extracted)
        (extracted / "electron.exe").stat()
        extracted.rename(target)


if __name__ == "__main__":
    if len(sys.argv) > 2:
        sys.exit('Usage: py "Set up Surge.py" [downloaded-archive.zip]')
    try:
        install(Path(sys.argv[1]) if len(sys.argv) == 2 else None)
    except (OSError, ValueError) as error:
        sys.exit(f"Setup stopped. {error}")
    print("Ready. Open Start Surge.cmd.")
