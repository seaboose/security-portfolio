"""Self-contained Insight finding format for Surge's offline report receiver."""
