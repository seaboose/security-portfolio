"""Bind the struct builder to the selected build and recovered stack storage."""

from tkinter import ttk

from . import dialogs, layout_editor
from .appearance import MONO, scrollable
from .knowledge import StaleEdit
from .layout_store import LayoutStore
from .stack_frame import project_regions
from .struct_layout import candidate_layout


class LayoutSession:
    def __init__(self, app):
        self.app = app
        self.store = None
        self.version = 0

    def bind(self, case):
        self.store = LayoutStore(self.app.store, case.digest)
        self.version = 0

    def project(self, slots):
        if not slots:
            return ()
        key = self.app.case.key(self.app.routine)
        native = {(s.offset, s.size) for s in slots}
        try:
            ranges = [r for r in self.store.regions(key) if r not in native]
            return project_regions(ranges, slots) if ranges else ()
        except ValueError as error:
            self.app.status.set(f"Saved stack ranges could not be displayed. {error}")
            return ()

    def _refresh_frame(self, selected):
        app, stack = self.app, self.app.views.stack
        slots = stack.native_slots
        stack.populate(slots, app.rows, app.rows[app.index].rva, regions=self.project(slots))
        if selected:
            stack.select_slot(*selected)
        app.edits.stack_names()

    def define_region(self):
        app, selection = self.app, self._selection()
        if not selection or not selection[2]:
            return
        store, key, slot = selection
        slots = app.views.stack.native_slots
        prompt = dialogs.Prompt(app.root, "Define stack range")
        low = min(s.offset for s in slots)
        end = max(s.offset+s.size for s in slots)
        ttk.Label(prompt.body, text=f"{app.routine.name}  ·  recovered extent {low:+#x} to {end:+#x} (exclusive)",
                  font=MONO, wraplength=400).grid(row=0, column=0, columnspan=2, sticky="w")
        entries = []
        for i, (label, value) in enumerate((("Start from entry RSP", f"{slot.offset:+#x}"),
                                            ("Size in bytes", str(slot.size))), start=1):
            ttk.Label(prompt.body, text=label).grid(row=i, column=0, sticky="w", padx=(0, 8), pady=3)
            entry = ttk.Entry(prompt.body, font=MONO, width=16)
            entry.insert(0, value)
            entry.grid(row=i, column=1, sticky="ew")
            entries.append(entry)
        message = ttk.Label(prompt.body, text="Use decimal or signed 0x hexadecimal values.", wraplength=400)
        message.grid(row=3, column=0, columnspan=2, sticky="w")
        def accept():
            if self._selection() != selection:
                prompt.finish()
                return
            try:
                values = [entry.get().strip() for entry in entries]
                offset, size = (int(v, 16 if v.lstrip("+-").lower().startswith("0x") else 10) for v in values)
            except ValueError:
                message.configure(text="Enter a signed offset and a positive byte size.")
                return
            try:
                store.add_region(key, offset, size, slots)
            except ValueError as error:
                message.configure(text=str(error))
                return
            prompt.finish((offset, size))
        chosen = prompt.show(accept, "Open range", entries[0])
        if chosen is not None and self._selection() == selection:
            self._refresh_frame(chosen)
            app.views.reader.select(app.views.struct)

    def remove_region(self):
        app, selection = self.app, self._selection()
        if not selection or selection[2] not in app.views.stack.regions:
            return
        store, key, slot = selection
        message = "Remove this range from the frame? Defining the same range again restores its saved layout."
        if dialogs.confirm(app.root, "Remove stack range", message, "Remove range", "Keep range") and self._selection() == selection:
            store.remove_region(key, slot.offset, slot.size)
            self._refresh_frame(None)

    def show(self, slot):
        app = self.app
        try:
            saved, self.version = self.store.get(app.case.key(app.routine), slot)
        except ValueError as error:
            self.version = 0
            app.views.struct.reset(str(error))
            return
        if saved is not None:
            layout, source = saved, "Analyst layout saved for this build"
        elif slot.layout is not None:
            layout, source = slot.layout, "Verified Windows declaration"
        else:
            layout, truncated = candidate_layout(slot)
            source = "Observed operand spans · C field boundaries and types are unknown"
            if truncated:
                source += " · partial span list"
        app.views.struct.populate(slot, app.rows, layout=layout, provenance=source,
                                  saved=saved is not None, has_revisions=self.version > 0)

    def _selection(self):
        app = self.app
        return (self.store, app.case.key(app.routine), app.views.stack.current_slot) if app.case else None

    def _save(self, selection, version, layout):
        if self._selection() != selection:
            return
        store, key, slot = selection
        pane = self.app.views.struct
        selected = pane.capture_state()
        try:
            store.save(key, slot, layout, expected=version)
        except StaleEdit:
            self.app.status.set("Another editor changed this layout. Review the refreshed fields and retry.")
        else:
            self.app.status.set("Layout saved for this build." if layout else "Recovered layout restored.")
        self.show(slot)
        pane.restore(selected)

    def edit(self):
        selection = self._selection()
        if selection and (slot := selection[2]):
            version = self.version
            proposal = layout_editor.edit_layout(self.app.root, slot, self.app.views.struct.current_layout)
            if proposal is not None:
                self._save(selection, version, proposal)

    def reset(self):
        selection = self._selection()
        if selection and selection[2]:
            version = self.version
            if dialogs.confirm(self.app.root, "Use recovered layout",
                               "Display the recovered storage? Your current layout stays in revisions.",
                               "Use recovered layout", "Keep editing"):
                self._save(selection, version, None)

    def revisions(self):
        selection = self._selection()
        if not selection or not selection[2]:
            return
        store, key, slot = selection
        version = self.version
        if version < 1:
            return
        prompt = dialogs.Prompt(self.app.root, "Layout revisions")
        scope = f"{self.app.case.label}  ·  {self.app.case.digest[:16]}  ·  {self.app.routine.name}"
        ttk.Label(prompt.body, text=scope, wraplength=480).pack(anchor="w")
        bar = ttk.Frame(prompt.body)
        bar.pack(fill="x", pady=(4, 2))
        ttk.Label(bar, text="Revision").pack(side="left")
        number = ttk.Spinbox(bar, from_=0, to=version, width=8, state="readonly")
        number.set(version)
        number.pack(side="left", padx=4)
        ttk.Label(bar, text=f"of {version}  ·  entry RSP {slot.offset:+#x}  ·  {slot.size} B", font=MONO).pack(side="left")
        summary = ttk.Label(prompt.body, wraplength=480)
        summary.pack(anchor="w")
        box = ttk.Frame(prompt.body)
        box.pack(fill="both", expand=True)
        fields = ttk.Treeview(box, columns=("offset", "size", "field", "type"), show="headings",
                              height=6, style="Insight.Treeview")
        for col, title, width in (("offset", "Offset", 72), ("size", "Bytes", 60),
                                  ("field", "Field", 160), ("type", "Type", 160)):
            fields.heading(col, text=title, anchor="w")
            fields.column(col, width=width, minwidth=48, stretch=col in ("field", "type"))
        scrollable(box, fields)

        def preview():
            layout = store.get_revision(key, slot, int(number.get()))
            fields.delete(*fields.get_children())
            if layout is None:
                summary.configure(text="Recovered layout")
                return
            summary.configure(text=f"{layout.name}  ·  {len(layout.fields)} fields")
            for field in layout.fields:
                fields.insert("", "end", values=(f"+0x{field.offset:X}", field.size, field.name, field.type_name))

        number.configure(command=preview)
        preview()
        picked = prompt.show(lambda: prompt.finish(int(number.get())), "Use this revision", number)
        if picked is not None and picked != version and self._selection() == selection:
            self._save(selection, version, store.get_revision(key, slot, picked))
