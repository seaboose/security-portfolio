"""A pinned instruction and its analyst-authored revisions in the native workspace."""

from pathlib import Path
import tkinter as tk
from tkinter import ttk

from . import dialogs
from .appearance import AMBER, INK, RIM, SELECTION, SURFACE, UI, WELL
from .note_markdown import MAX_SOURCE, MarkdownPreview


class Notes(tk.Frame):
    def __init__(self, parent, store, citation, navigate, notify, *, follow_address=None):
        super().__init__(parent, padx=10, pady=4, bg=SURFACE, borderwidth=0)
        self.store, self.citation, self.navigate, self.notify = store, citation, navigate, notify
        self.follow_address = follow_address
        self.previewing = False
        self.prediction = False
        self.case = self.pinned = self.note = None
        self.saved, self.history = [], []
        self.baseline = ""
        bar = ttk.Frame(self)
        bar.pack(fill="x")
        ttk.Label(bar, text="Analyst notes", style="DockTitle.TLabel").pack(side="left", padx=(0,10))
        ttk.Button(bar, text="New note", command=self.new).pack(side="right")
        self.picker = ttk.Combobox(bar, state="readonly", width=20)
        self.picker.bind("<<ComboboxSelected>>", self.choose)
        self.revision = ttk.Combobox(bar, state="readonly", width=15)
        self.revision.pack(side="right", padx=5)
        self.picker.pack(side="left", fill="x", expand=True)
        self.revision.bind("<<ComboboxSelected>>", self.choose_revision)
        self.editor = tk.Text(self, height=3, wrap="word", undo=True, background=WELL,
                              foreground=INK, insertbackground=AMBER, relief="flat", borderwidth=0,
                              padx=6, pady=4, selectbackground=SELECTION, highlightthickness=1,
                              highlightbackground=RIM, highlightcolor=AMBER, font=UI)
        self.editor.configure(state="disabled")
        self.editor.bind("<<Modified>>", self.edited)
        self.preview = MarkdownPreview(self, self._follow_link)
        actions = ttk.Frame(self)
        actions.pack(side="bottom", fill="x")
        self.editor.pack(fill="both", expand=True, pady=4)
        self.cite = ttk.Button(actions, command=self.follow)
        self.cite.pack(side="left")
        self.preview_toggle = ttk.Button(actions, text="Preview", command=self.toggle_preview)
        self.preview_toggle.pack(side="right")
        self.preview_toggle.state(["disabled"])
        for text, action in [("Save note", self.save),("Approve", self.approve),("Export…", self.export)]:
            b = ttk.Button(actions, text=text, command=action)
            b.pack(side="left", padx=(4,0))
            b.state(["disabled"])
            if text.startswith("Approve"): self.approval = b
            if text.startswith("Export"): self.download = b
            if text.startswith("Save"): self.commit = b
        self.review_button = ttk.Button(actions,text="Review…",command=self.review)
        self.review_button.pack(side="left",padx=(4,0))
        self.review_button.state(["disabled"])

    def _scope(self):
        return (self.case.digest, self.pinned) if self.case and self.pinned else None

    def _preview(self):
        # A large unsaved paste can exceed the casebook note limit. Only transfer
        # the preview budget plus one character from Tcl to Python for rendering.
        limit = f"1.0 + {MAX_SOURCE+1} chars"
        end = limit if self.editor.compare(limit, "<", "end-1c") else "end-1c"
        self.preview.render(self.editor.get("1.0", end), self._scope())

    def toggle_preview(self):
        self.previewing = not self.previewing
        self.preview_toggle.configure(text="Edit" if self.previewing else "Preview")
        if self.previewing:
            self.edited()
            self._preview()
            self.editor.pack_forget()
            self.preview.pack(fill="both", expand=True, pady=4)
            self.preview.focus_set()
        else:
            self.preview.pack_forget()
            self.editor.pack(fill="both", expand=True, pady=4)
            self.editor.focus_set()

    def _follow_link(self, scope, address, relative):
        if not self.previewing or not scope or scope != self._scope():
            self.notify("The note reference belongs to a different selection.")
            return
        if self.follow_address is None or relative != (self.case.image is None):
            self.notify("Use @0x for DLL RVAs or @+0x for offsets in the pinned example routine.")
            return
        try:
            self.follow_address(scope[0], scope[1][0], address, relative)
        except ValueError as error:
            self.notify(str(error))

    def allow_discard(self):
        return not self.dirty() or dialogs.confirm(self, "Unsaved note", "Discard the unsaved edit?",
                                                   "Discard edit", "Keep editing")

    def dirty(self):
        return self.editor.get("1.0","end-1c") != self.baseline

    def bind_case(self, case):
        self.case = case
        self.refresh()
        try:
            pin = self.store.note_pin(case.digest)
        except ValueError as error:
            self.load(-1, remember=False)
            self.notify(str(error))
            return
        if pin is not None:
            note, revision = pin
            match = next((i for i,n in enumerate(self.saved) if n["id"] == note), -1)
            self.load(match, revision, remember=False)
            return
        key, row = self.citation()
        match = next((i for i,n in enumerate(self.saved) if (n["routine"],n["rva"],n["raw"]) ==
                      (key,row.rva,row.raw)), -1)
        self.load(match, remember=False)

    def refresh(self):
        self.saved = self.store.notes(self.case.digest)
        self.picker["values"] = [f"Note {n['id']} · 0x{n['rva']:X}" for n in self.saved] + ["New note"]

    def load(self, index, revision=None, *, remember=True):
        self.picker.current(index if index >= 0 else len(self.saved))
        self.note = self.saved[index] if 0 <= index < len(self.saved) else None
        self.pinned = (self.note["routine"],self.note["rva"],self.note["raw"]) if self.note else None
        self.history = self.store.revisions(self.note["id"]) if self.note else []
        self.revision["values"] = [f"r{r['number']} · " + ("approved" if r["approved"] else "draft") for r in self.history]
        idx = next((i for i,row in enumerate(self.history) if row["number"]==revision), len(self.history)-1)
        self.set_revision(idx, remember=remember)

    def set_revision(self, idx, *, remember=True):
        if remember:
            self.store.pin_note(self.case.digest, self.note["id"] if self.note else None,
                                self.history[idx]["number"] if self.note else None)
        self.active = idx
        if idx >= 0: self.revision.current(idx)
        else: self.revision.set("")
        self.baseline = self.history[idx]["body"] if idx >= 0 else ""
        from .findings import prediction_only
        self.prediction = bool(self.note and prediction_only(self.store,self.note["id"],idx+1))
        self.editor.configure(state="normal")
        self.editor.delete("1.0","end")
        self.editor.insert("1.0",self.baseline)
        old = idx >= 0 and idx < len(self.history)-1
        if old: self.editor.configure(state="disabled")
        self.editor.edit_reset()
        self.editor.edit_modified(False)
        self.preview_toggle.state(["!disabled"])
        if self.previewing:
            self._preview()
        self.cursor_changed()

    def edited(self, _event=None):
        if not self.editor.edit_modified(): return
        self.editor.edit_modified(False)
        if self.dirty() and self.pinned is None and self.case:
            key,row = self.citation()
            self.pinned = key,row.rva,row.raw
        self.cursor_changed()

    def cursor_changed(self):
        current = self.citation() if self.case else None
        if not current: return
        key,row = current
        key,rva,_ = self.pinned or (key,row.rva,row.raw)
        label = f"RVA 0x{rva:X}" if self.case.image is not None else f"{key}+0x{rva:X}"
        self.cite.configure(text="↗ " + label)
        approved = bool(self.history and self.history[self.active]["approved"])
        latest = self.active == len(self.history)-1
        for b, enabled in [(self.commit,latest and self.dirty()),(self.approval,
                bool(self.history) and latest and not approved and not self.prediction and not self.dirty()),
                (self.download,approved and not self.dirty()),
                (self.review_button,bool(self.history) and not self.prediction and not self.dirty())]:
            b.state(["!disabled" if enabled else "disabled"])

    def new(self):
        if self.case and self.allow_discard():
            self.load(-1)
            if self.previewing:
                self.toggle_preview()
            self.editor.focus_set()

    def choose(self, _event):
        if self.allow_discard(): self.load(self.picker.current())
        else: self.picker.current(self.saved.index(self.note) if self.note else len(self.saved))

    def choose_revision(self, _event):
        if self.allow_discard(): self.set_revision(self.revision.current())
        else: self.revision.current(self.active)

    def follow(self):
        if self.pinned: self.navigate(*self.pinned)

    def record_prediction(self):
        if self.note or not self.case:
            self.notify("Choose New note, write your prediction, then save it before the interpretation.")
            return
        if not self.dirty():
            self.notify("Write a prediction in Analyst notes, then choose Record prediction.")
            return
        self.save(prediction=True)
        self.notify("Prediction saved as revision 1. Replace the text with your interpretation and save a new revision.")

    def save(self, *, prediction=False):
        if not self.case or not self.dirty(): return
        if self.pinned is None:
            key,row = self.citation()
            self.pinned = key,row.rva,row.raw
        key,rva,raw = self.pinned
        note_id = self.store.save_note(self.case.digest,key,rva,raw,
            self.editor.get("1.0","end-1c"), self.note["id"] if self.note else None, self.active+1,
            prediction=prediction)
        self.refresh()
        self.load(next(i for i,n in enumerate(self.saved) if n["id"] == note_id), remember=False)
        self.notify(f"Saved note {note_id} · 0x{rva:X}")

    def approve(self, tests="", limitations=""):
        if not self.note or self.dirty(): return
        from .findings import approve_revision
        approve_revision(self.store,self.case,self.note["id"],self.active+1,tests,limitations)
        self.load(self.picker.current())
        self.notify("Approved the selected revision.")

    def review(self):
        if not self.note or self.dirty():
            self.notify("Save the interpretation to review its evidence and exact revision.")
            return
        from .finding_review import review_finding
        from .findings import build_record
        record = build_record(self.store,self.case,self.note["id"],self.active+1,draft=True)
        review_finding(self,record,self.approve,self.export,self.navigate)

    def export(self):
        if not self.note or self.dirty(): return
        revision = self.history[self.active]
        if not revision["approved"]: return
        from .findings import build_record, write_record
        record = build_record(self.store,self.case,self.note["id"],revision["number"])
        name = dialogs.choose_file(self, f"insight-{record['finding_id'][:12]}-r{revision['number']}.md")
        if not name: return
        path = Path(name)
        write_record(record,path,self.case)
        self.notify("Exported " + path.name)
