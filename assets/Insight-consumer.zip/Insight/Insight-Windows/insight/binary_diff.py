"""Pair indexed PE functions and compare each build's verified listing and Ghidra lines."""

from dataclasses import dataclass
from hashlib import sha256

from .block_diff import BlockChange, compare_blocks
from .diff_alignment import Aligned, _align, _check, _unique, align_instructions
from .ghidra import Decompilation, decompile
from .pe import Instruction, MAX_FILE_SIZE, Routine


@dataclass(frozen=True)
class FunctionMatch:
    name: str
    status: str
    basis: str
    left: Routine | None
    right: Routine | None
    builds: tuple[str, ...] = ()


@dataclass(frozen=True)
class Side:
    routine: Routine
    rows: tuple[Instruction, ...]
    code: Decompilation | None
    error: str | None


@dataclass(frozen=True)
class FunctionDiff:
    left: Side | None
    right: Side | None
    instructions: tuple[Aligned, ...]
    pseudocode: tuple[Aligned, ...]
    blocks: tuple[BlockChange, ...] = ()


class _Index:
    def __init__(self, case, cancel):
        self.image = image = case.image
        if image is None:
            raise ValueError("Binary comparison requires two native x64 DLLs.")
        self.routines = {r.rva: r for r in image.routines if r.rva in image.function_entries}
        self.names = _unique((name, at) for at, names in image.export_names.items() for name in names)
        self.hashes = {}
        source = memoryview(image.data)
        budget = MAX_FILE_SIZE * 2
        for at in self.routines:
            _check(cancel)
            length = image.range_ends[at] - at
            budget -= length
            if budget < 0:
                raise ValueError("Overlapping PE function ranges exceed the comparison budget.")
            offset = image.offset(at, length)
            self.hashes[at] = sha256(source[offset:offset + length]).digest()
        self.by_hash = _unique((digest, at) for at, digest in self.hashes.items())

    def named_peer(self, at, other):
        # A group of aliases must still point to a single function in both builds.
        peers = {other.names[name] for name in self.image.export_names.get(at, ()) if name in other.names}
        return peers.pop() if len(peers) == 1 else None


def compare_builds(left, right, cancel=None):
    """Compare full file-backed indexed ranges. An RVA by itself is only a candidate."""
    _check(cancel)
    a, b = _Index(left, cancel), _Index(right, cancel)
    if not a.routines and not b.routines:
        raise ValueError("Neither DLL has an indexed export, entry point, or unwind function.")
    builds = (left.digest, right.digest)
    pairs = []
    used_left, used_right = set(), set()

    def pair(i, j, basis, candidate=False):
        before, after = a.routines[i], b.routines[j]
        status = "Unchanged" if a.hashes[i] == b.hashes[j] else "Changed"
        if candidate:
            status = "Candidate"
        if before.extent.startswith("inferred") or after.extent.startswith("inferred"):
            basis += " · inferred extent"
        if a.image.range_ends[i] > before.end or b.image.range_ends[j] > after.end:
            basis += " · full ranges compared, first 16 KiB shown"
        common = a.image.export_names.get(i, set()) & b.image.export_names.get(j, set())
        name = min(common) if common else before.name
        pairs.append(FunctionMatch(name, status, basis, before, after, builds))
        used_left.add(i)
        used_right.add(j)

    # Resolve named exports before considering implementation bytes or coordinates.
    reverse = {j: b.named_peer(j, a) for j in b.routines}
    for i in a.routines:
        _check(cancel)
        if left.digest == right.digest:
            pair(i, i, "Identical snapshot")
            continue
        j = a.named_peer(i, b)
        if j is not None and reverse.get(j) == i:
            pair(i, j, "Shared export name")

    def private_pair(i, j):
        return (i in a.routines and j in b.routines and i not in used_left and j not in used_right
                and i not in a.image.export_names and j not in b.image.export_names)

    if private_pair(a.image.entry, b.image.entry):
        pair(a.image.entry, b.image.entry, "PE entry point")
    for i, digest in a.hashes.items():
        _check(cancel)
        j = b.by_hash.get(digest)
        if a.by_hash[digest] == i and private_pair(i, j):
            pair(i, j, "Unique identical bytes")
    for i in a.routines:
        if private_pair(i, i):
            pair(i, i, "Same RVA · identity unverified", candidate=True)

    for index, other, used, side in ((a, b, used_left, "baseline"), (b, a, used_right, "comparison")):
        for at, routine in index.routines.items():
            _check(cancel)
            if at in used:
                continue
            names = index.image.export_names.get(at, ())
            if names and not any(name in other.names for name in names):
                status = "Removed" if side == "baseline" else "Added"
                basis = f"Named code export only in {side}"
            else:
                status, basis = "Unmatched", "No unique counterpart"
            if index.image.range_ends[at] > routine.end:
                basis += " · first 16 KiB shown"
            pairs.append(FunctionMatch(routine.name, status, basis, routine if index is a else None,
                                       routine if index is b else None, builds))
    order = {name: i for i, name in enumerate(("Changed", "Added", "Removed", "Candidate", "Unmatched", "Unchanged"))}
    return tuple(sorted(pairs, key=lambda m: (order[m.status], m.name, (m.left or m.right).rva)))


def _inspect(case, routine, cancel):
    if routine is None:
        return None
    _check(cancel)
    rows = tuple(case.instructions(routine, cancel))
    try:
        code = decompile(case.data, case.digest, routine, rows, cancel)
    except (OSError, ValueError) as error:
        _check(cancel)
        return Side(routine, rows, None, str(error))
    return Side(routine, rows, code, None)


def inspect_match(left, right, match, cancel=None):
    if match.builds != (left.digest, right.digest):
        raise ValueError("This function pair belongs to different DLL snapshots.")
    a = _inspect(left, match.left, cancel)
    b = a if left.digest == right.digest and match.left == match.right else _inspect(right, match.right, cancel)
    unpaired = match.status == "Unmatched"
    rows_a, rows_b = a.rows if a else (), b.rows if b else ()
    instructions = align_instructions(rows_a, rows_b, cancel, unpaired)
    a_text = [line.text for line in a.code.lines] if a and a.code else []
    b_text = [line.text for line in b.code.lines] if b and b.code else []
    missing_code = (a is not None and a.code is None) or (b is not None and b.code is None)
    pseudocode = _align(a_text, b_text, cancel, unpaired or missing_code)
    blocks = compare_blocks(a, b, cancel, candidate=match.status == "Candidate")
    return FunctionDiff(a, b, instructions, pseudocode, blocks)
