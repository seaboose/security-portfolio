"""Analyst labels and a transactional, build-scoped undo timeline."""

from contextlib import contextmanager
from dataclasses import astuple, dataclass, replace
import json
import re

STATUSES = ("Unexplored", "In Progress", "Reversed", "Library/Noise", "Malicious/Target")
CONFIDENCES = ("Unrated", "Low", "Medium", "High")

SCHEMA = """
    CREATE TABLE IF NOT EXISTS analysis_state (
        digest TEXT PRIMARY KEY REFERENCES artifacts(digest),
        version INTEGER NOT NULL, cursor INTEGER NOT NULL, tip INTEGER NOT NULL
    );
    CREATE TABLE IF NOT EXISTS analysis_values (
        digest TEXT NOT NULL REFERENCES artifacts(digest), subject TEXT NOT NULL,
        value TEXT NOT NULL, PRIMARY KEY(digest,subject)
    );
    CREATE TABLE IF NOT EXISTS analysis_history (
        digest TEXT NOT NULL REFERENCES artifacts(digest), position INTEGER NOT NULL,
        subject TEXT NOT NULL, old_value TEXT NOT NULL, new_value TEXT NOT NULL,
        created TEXT NOT NULL, PRIMARY KEY(digest,position)
    );
"""


class StaleEdit(ValueError):
    """Another editor committed a different timeline state."""


@dataclass(frozen=True)
class Subject:
    kind: str
    routine: str = ""
    offset: int = 0
    size: int = 0

    def __post_init__(self):
        if type(self.offset) is not int or type(self.size) is not int:
            raise ValueError("Symbol storage requires integer coordinates.")
        if self.kind == "global":
            if self.routine != "" or self.size != 0 or not 0 <= self.offset < 2**32:
                raise ValueError("Invalid global RVA.")
            return
        if not isinstance(self.routine, str) or not re.fullmatch(r"[A-Za-z0-9_?$@.:-]{1,256}", self.routine):
            raise ValueError("Choose a routine with an established identity.")
        if self.kind == "function" and self.offset == self.size == 0:
            return
        if (self.kind == "local" and -(2**31) <= self.offset < 2**31
                and 0 < self.size <= 2**31 and self.offset + self.size <= 2**31):
            return
        raise ValueError("Invalid symbol storage range.")

    @classmethod
    def function(cls, key):
        return cls("function", key)

    @classmethod
    def local(cls, key, offset, size):
        return cls("local", key, offset, size)

    @classmethod
    def global_(cls, rva):
        return cls("global", offset=rva)

    def key(self):
        if self.kind == "function":
            return "F:" + self.routine
        if self.kind == "global":
            return f"G:{self.offset:X}"
        return f"L:{self.routine}:{self.offset}:{self.size}"

    @classmethod
    def from_key(cls, key):
        if not isinstance(key, str) or len(key) > 300:
            raise ValueError("Invalid stored symbol identity.")
        prefix, _, value = key.partition(":")
        if prefix == "F":
            return cls.function(value)
        if prefix == "G":
            return cls.global_(int(value, 16))
        if prefix == "L":
            routine, offset, size = value.rsplit(":", 2)
            return cls.local(routine, int(offset), int(size))
        raise ValueError("Unrecognized stored symbol identity.")


@dataclass(frozen=True)
class Annotation:
    name: str = ""
    type_name: str = ""
    status: str = STATUSES[0]
    confidence: str = CONFIDENCES[0]

    def __post_init__(self):
        if not isinstance(self.name, str) or (self.name and not re.fullmatch(
                r"[A-Za-z_$?@][A-Za-z0-9_.$?@:]{0,127}", self.name)):
            raise ValueError("Enter a symbol name of up to 128 identifier characters, or leave it empty.")
        allowed = r"[A-Za-z0-9_ .:$?@,*&()\[\]<>]{1,256}"
        if (not isinstance(self.type_name, str) or self.type_name and
                (not re.fullmatch(allowed, self.type_name) or not re.search("[A-Za-z_]", self.type_name))):
            raise ValueError("Enter a one-line type label up to 256 characters, or leave it empty.")
        if self.status not in STATUSES or self.confidence not in CONFIDENCES:
            raise ValueError("Choose a listed triage status and confidence.")

    def encode(self):
        return json.dumps(astuple(self), separators=(",", ":"))

    @classmethod
    def decode(cls, data):
        if not isinstance(data, str) or len(data) > 1024:
            raise ValueError("Invalid stored annotation.")
        try:
            items = json.loads(data)
            if not isinstance(items, list) or len(items) != 4:
                raise ValueError("Invalid stored annotation.")
            return cls(*items)
        except (TypeError, RecursionError, json.JSONDecodeError) as error:
            raise ValueError("Invalid stored annotation.") from error


@dataclass(frozen=True)
class Change:
    position: int
    subject: Subject
    before: Annotation
    after: Annotation
    created: str
    applied: bool


class Knowledge:
    def __init__(self, store, digest):
        if not isinstance(digest, str) or not re.fullmatch("[a-f0-9]{64}", digest) or not store.metadata(digest):
            raise ValueError("Open the saved build before editing its analysis.")
        self.db, self.digest = store.db, digest
        self.refresh()

    def _state(self):
        row = self.db.execute("SELECT version,cursor,tip FROM analysis_state WHERE digest=?",
                              (self.digest,)).fetchone()
        if not row:
            return (0, 0, 0)
        version, cursor, tip = row
        if not (all(type(n) is int for n in row) and 0 <= cursor <= tip <= version < 2**63 - 1):
            raise ValueError("The stored analysis timeline has an invalid position.")
        return version, cursor, tip

    def refresh(self):
        self.version, self.cursor, self.tip = self._state()

    @property
    def can_undo(self):
        return self.cursor > 0

    @property
    def can_redo(self):
        return self.cursor < self.tip

    def get(self, subject):
        if not isinstance(subject, Subject):
            raise ValueError("Choose an established symbol.")
        row = self.db.execute("SELECT value FROM analysis_values WHERE digest=? AND subject=?",
                              (self.digest, subject.key())).fetchone()
        return Annotation.decode(row[0]) if row else Annotation()

    def annotations(self, subjects):
        keys = {}
        for subject in subjects:
            if not isinstance(subject, Subject):
                raise ValueError("Choose established symbols.")
            keys[subject.key()] = subject
            if len(keys) > 65536:
                raise ValueError("Too many symbol annotations to display together.")
        result = {}
        ordered = list(keys)
        for start in range(0, len(ordered), 100):
            batch = ordered[start:start + 100]
            marks = ",".join("?" for _ in batch)
            rows = self.db.execute(f"SELECT subject,value FROM analysis_values WHERE digest=? AND subject IN ({marks})",
                                   (self.digest, *batch))
            result.update((keys[key], Annotation.decode(value)) for key, value in rows)
        return result

    def functions(self):
        rows = self.db.execute("SELECT subject,value FROM analysis_values WHERE digest=? AND subject GLOB 'F:*' LIMIT 65537",
                               (self.digest,))
        result = {}
        for key, value in rows:
            if len(result) >= 65536:
                raise ValueError("Too many stored function annotations for one build.")
            result[Subject.from_key(key).routine] = Annotation.decode(value)
        return result

    @contextmanager
    def _write(self, expected):
        with self.db:
            self.db.execute("BEGIN IMMEDIATE")
            version, cursor, tip = self._state()
            if version != self.version or (expected is not None and
                                           (type(expected) is not int or expected != version)):
                raise StaleEdit("Analysis changed in another editor. Reload the current analysis before editing.")
            yield cursor, tip

    def _advance(self, cursor, tip):
        self.db.execute("""INSERT INTO analysis_state VALUES(?,?,?,?)
            ON CONFLICT(digest) DO UPDATE SET version=excluded.version,
            cursor=excluded.cursor,tip=excluded.tip""", (self.digest, self.version + 1, cursor, tip))

    def _store(self, key, value):
        if value == Annotation():
            self.db.execute("DELETE FROM analysis_values WHERE digest=? AND subject=?", (self.digest, key))
        else:
            self.db.execute("""INSERT INTO analysis_values VALUES(?,?,?) ON CONFLICT(digest,subject)
                            DO UPDATE SET value=excluded.value""", (self.digest, key, value.encode()))

    def edit(self, subject, *, expected=None, **fields):
        if (not isinstance(subject, Subject) or not fields or
                fields.keys() - {"name", "type_name", "status", "confidence"}):
            raise ValueError("Choose a symbol and an editable annotation field.")
        if subject.kind != "function" and fields.keys() & {"status", "confidence"}:
            raise ValueError("Triage applies to functions.")
        key = subject.key()
        with self._write(expected) as (cursor, tip):
            before = self.get(subject)
            after = replace(before, **fields)
            if after == before:
                return False
            if cursor < tip:
                self.db.execute("DELETE FROM analysis_history WHERE digest=? AND position>?", (self.digest, cursor))
            position = cursor + 1
            self.db.execute("""INSERT INTO analysis_history VALUES(?,?,?,?,?,
                strftime('%Y-%m-%dT%H:%M:%fZ','now'))""",
                            (self.digest, position, key, before.encode(), after.encode()))
            self._store(key, after)
            self._advance(position, position)
        self.version += 1
        self.cursor = self.tip = position
        return True

    def history(self, limit=100, before=None):
        if type(limit) is not int or not 1 <= limit <= 500:
            raise ValueError("Choose between 1 and 500 history entries.")
        if before is not None and (type(before) is not int or not 0 <= before < 2**63):
            raise ValueError("Invalid history position.")
        before = before if before is not None else 2**63 - 1
        rows = self.db.execute("""SELECT position,subject,old_value,new_value,created FROM analysis_history
            WHERE digest=? AND position<? ORDER BY position DESC LIMIT ?""", (self.digest, before, limit))
        changes = tuple(Change(p, Subject.from_key(key), Annotation.decode(old), Annotation.decode(new),
                               stamp, p <= self.cursor) for p, key, old, new, stamp in rows)
        if self._state()[0] != self.version:
            raise StaleEdit("The analysis timeline changed. Reload it to review the latest edits.")
        return changes

    def _move(self, position, backward, expected):
        with self._write(expected) as (cursor, tip):
            if type(position) is not int or not 0 <= position <= tip:
                raise ValueError("Choose an existing history position.")
            if position == cursor:
                return False
            if backward != (position < cursor):
                raise ValueError("That history position is in the opposite direction.")
            order = "DESC" if backward else "ASC"
            lo, hi = sorted((position, cursor))
            rows = self.db.execute(f"""SELECT subject,old_value,new_value FROM analysis_history
                WHERE digest=? AND position>? AND position<=? ORDER BY position {order}""", (self.digest, lo, hi))
            count = 0
            for key, old, new in rows:
                subject = Subject.from_key(key)
                before, after = Annotation.decode(old), Annotation.decode(new)
                expected_value, value = (after, before) if backward else (before, after)
                if subject.key() != key or self.get(subject) != expected_value:
                    raise ValueError("The stored analysis timeline does not agree with the active annotation.")
                self._store(key, value)
                count += 1
            if count != hi - lo:
                raise ValueError("The stored analysis timeline is incomplete.")
            self._advance(position, tip)
        self.version += 1
        self.cursor = position
        return True

    def undo_to(self, position, expected=None):
        return self._move(position, True, expected)

    def redo_to(self, position, expected=None):
        return self._move(position, False, expected)

    def undo(self, expected=None):
        return self.undo_to(max(0, self.cursor - 1), expected)

    def redo(self, expected=None):
        return self.redo_to(min(self.tip, self.cursor + 1), expected)
