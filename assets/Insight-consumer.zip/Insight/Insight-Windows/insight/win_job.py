"""Run a local tool and its descendants in one cancellable Windows Job."""

import _winapi
import ctypes as C
from ctypes import wintypes as W
import subprocess
from time import monotonic


class BasicLimits(C.Structure):
    _fields_ = [("process_time", C.c_int64), ("job_time", C.c_int64), ("flags", W.DWORD),
                ("min_working_set", C.c_size_t), ("max_working_set", C.c_size_t),
                ("process_count", W.DWORD), ("affinity", C.c_size_t),
                ("priority", W.DWORD), ("scheduling", W.DWORD)]


class Limits(C.Structure):
    _fields_ = [("basic", BasicLimits), ("io_counters", C.c_uint64 * 6),
                ("process_memory", C.c_size_t), ("job_memory", C.c_size_t),
                ("peak_process", C.c_size_t), ("peak_job", C.c_size_t)]


def run_job(command, cwd, env, cancel, seconds=90):
    kernel = C.WinDLL("kernel32", use_last_error=True)
    kernel.CreateJobObjectW.argtypes = [C.c_void_p, W.LPCWSTR]
    kernel.CreateJobObjectW.restype = W.HANDLE
    kernel.SetInformationJobObject.argtypes = [W.HANDLE, C.c_int, C.c_void_p, W.DWORD]
    kernel.AssignProcessToJobObject.argtypes = [W.HANDLE, W.HANDLE]
    kernel.ResumeThread.argtypes = [W.HANDLE]
    kernel.ResumeThread.restype = W.DWORD
    job = kernel.CreateJobObjectW(None, None)
    if not job:
        raise C.WinError(C.get_last_error())
    process = thread = None
    try:
        limits = Limits()
        # JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE | JOB_MEMORY | ACTIVE_PROCESS.
        limits.basic.flags = 0x2000 | 0x200 | 0x8
        limits.basic.process_count = 12
        limits.job_memory = 2 * 1024**3
        if not kernel.SetInformationJobObject(job, 9, C.byref(limits), C.sizeof(limits)):
            raise C.WinError(C.get_last_error())
        if cancel is not None and cancel.is_set():
            raise ValueError("Decompilation cancelled.")
        # Create the JVM suspended: even its earliest children must inherit the job.
        process, thread, _, _ = _winapi.CreateProcess(
            str(command[0]), subprocess.list2cmdline(command), None, None, False,
            subprocess.CREATE_NO_WINDOW | 0x4, env, str(cwd), subprocess.STARTUPINFO())
        if not kernel.AssignProcessToJobObject(job, process):
            code = C.get_last_error()
            _winapi.TerminateProcess(process, 1)
            raise C.WinError(code)
        if kernel.ResumeThread(thread) == 0xffffffff:
            raise C.WinError(C.get_last_error())
        deadline = monotonic() + seconds
        while _winapi.WaitForSingleObject(process, 100) == _winapi.WAIT_TIMEOUT:
            if cancel is not None and cancel.is_set():
                raise ValueError("Decompilation cancelled.")
            if monotonic() >= deadline:
                raise ValueError("Ghidra exceeded the decompilation time limit.")
        return _winapi.GetExitCodeProcess(process)
    finally:
        _winapi.CloseHandle(job)
        if thread is not None:
            _winapi.CloseHandle(thread)
        if process is not None:
            _winapi.WaitForSingleObject(process, 5000)
            _winapi.CloseHandle(process)
