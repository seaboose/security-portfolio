"""Open the local investigation or replay its saved controls."""

import argparse
import json
from pathlib import Path
import sys

from .cooldown import CASE_DIR
from .replay import replay


def summary(report):
    lines = ["Survive dash cooldown | synthetic controls | no model calls"]
    for run in report["runs"]:
        for stage in ("initial", "revised"):
            attempt = run[stage]
            if attempt is None:
                continue
            label = f"{run['build']} {stage}"
            if attempt["outcome"] != "submitted":
                lines.append(f"{label}: {attempt['outcome']}")
                continue
            lines.append(f"{label}: {attempt['passed']}/{attempt['total']}  {attempt['expression']}")
            for miss in attempt["misses"]:
                lines.append(f"  now={miss['now']:g}, deadline={miss['deadline']:g}: "
                             f"expected {miss['expected']}, returned {miss['actual']}")
    return "\n".join(lines)


def main():
    parser = argparse.ArgumentParser(prog="python -m insight")
    commands = parser.add_subparsers(dest="command", required=True)
    command = commands.add_parser("replay", help="verify evidence and rescore saved controls")
    command.add_argument("--runs", type=Path, default=CASE_DIR / "runs.json", help="local v1 run file")
    command.add_argument("--json", action="store_true", help="emit the reproducible score report")
    desktop = commands.add_parser("desktop", help="open the desktop investigation")
    desktop.add_argument("--dll", type=Path, metavar="PATH", help="inspect an x64 DLL read-only")
    args = parser.parse_args()
    if args.command == "desktop":
        from .desktop import launch

        try:
            launch(args.dll)
        except (OSError, ValueError) as error:
            print(f"Could not open the investigation: {error}", file=sys.stderr)
            return 2
        return 0
    try:
        report = replay(args.runs)
    except (ValueError, OSError) as error:
        # I/O errors can echo arbitrary path characters. Keep imported text out of diagnostics.
        reason = "could not read a required local file" if isinstance(error, OSError) else str(error)
        print(f"Replay rejected: {reason}", file=sys.stderr)
        return 2
    print(json.dumps(report, indent=2, allow_nan=False) if args.json else summary(report))
    return 0


if __name__ == "__main__":
    sys.exit(main())
