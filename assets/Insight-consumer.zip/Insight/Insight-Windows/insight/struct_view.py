"""Stack layouts, storage overlap and instruction-level access evidence."""

import tkinter as tk
from tkinter import ttk

from .appearance import AMBER, CRIMSON, INK, LINE, MONO, MUTED, RIM, SELECTION, SURFACE, TEAL, WELL, mono_font, scrollable
from .stack_view import signed_offset

PAGE = 100


class StructLayout(tk.Frame):
    def __init__(self, parent):
        super().__init__(parent, padx=6, pady=6, bg=SURFACE, borderwidth=0)
        self.on_follow = self.on_edit = self.on_reset = self.on_revisions = None
        self.current_slot = self.current_layout = self.intervals = None
        self.field_name = tk.StringVar(self)
        self.fields, self.rows = {}, {}
        self.ticks = []
        self.mono = mono_font(self)
        self.bind("<<InsightFontsChanged>>", self._fonts_changed)
        self.viewport = tk.Canvas(self, bg=SURFACE, height=1, width=1, highlightthickness=0)
        self.scroll = ttk.Scrollbar(self, command=self.viewport.yview, style="Insight.Vertical.TScrollbar")
        self.viewport.configure(yscrollcommand=self.scroll.set)
        self.rowconfigure(0, weight=1)
        self.columnconfigure(0, weight=1)
        self.viewport.grid(row=0, column=0, sticky="nsew")
        self.scroll.grid(row=0, column=1, sticky="ns")
        self.page = ttk.Frame(self.viewport)
        self.page_id = self.viewport.create_window(0, 0, window=self.page, anchor="nw")
        self.title = ttk.Label(self.page, style="DockTitle.TLabel", wraplength=240)
        self.title.pack(fill="x")
        self.body = ttk.Frame(self.page)
        self.source = ttk.Label(self.body, foreground=MUTED, wraplength=240)
        self.source.pack(fill="x")
        bar = ttk.Frame(self.body)
        bar.pack(fill="x", pady=(2, 0))
        self.edit = ttk.Button(bar, text="Edit layout…", command=lambda:self.on_edit())
        self.recover = ttk.Button(bar, text="Use recovered layout", command=lambda:self.on_reset())
        self.revisions = ttk.Button(bar, text="Revisions…", command=lambda:self.on_revisions())
        self.map = ttk.Frame(self.body)
        self.map.pack(fill="x", pady=(4, 5))
        style = ttk.Style(self)
        style.configure("Field.Toolbutton", font=MONO, anchor="center", padding=("2p", "2p"),
                        background=WELL, foreground=INK, bordercolor=RIM, lightcolor=LINE, darkcolor=LINE)
        style.map("Field.Toolbutton", relief=[("!disabled", "solid")],
                  background=[("selected", SELECTION), ("active", "#31282b")],
                  bordercolor=[("focus", AMBER), ("selected", CRIMSON), ("active", RIM)])
        self.summary = ttk.Label(self.body, style="DockTitle.TLabel", wraplength=240)
        self.summary.pack(fill="x")
        self.filters = ttk.Frame(self.body)
        self.filters.pack(fill="x", pady=(3, 0))
        self.mode = tk.StringVar(self, "Read")
        self.modes = {}
        ttk.Label(self.filters, text="Access").pack(side="left")
        for mode in ("All", "Read", "Write"):
            button = ttk.Radiobutton(self.filters, text=mode, value=mode, variable=self.mode,
                                     command=self._render, style="Insight.Switch.TRadiobutton")
            button.pack(side="left", padx=(3, 0))
            self.modes[mode] = button
        self.coverage = ttk.Label(self.body, foreground=MUTED, wraplength=240)
        self.coverage.pack(fill="x", pady=(0, 2))
        table = ttk.Frame(self.body)
        table.pack(fill="both", expand=True)
        columns = ("rva", "access", "coverage", "width", "bytes", "instruction")
        self.refs = ttk.Treeview(table, columns=columns, show="headings", selectmode="browse",
                                 style="Insight.Treeview", height=3)
        for key, label in zip(columns, ("RVA", "Access", "Field coverage", "Width", "Exact bytes", "Instruction")):
            self.refs.heading(key, text=label, anchor="w")
        scrollable(table, self.refs)
        self.pager = ttk.Frame(self.body)
        self.previous = ttk.Button(self.pager, text="Previous", command=lambda:self._access_page(self.page_number-1))
        self.next = ttk.Button(self.pager, text="Next", command=lambda:self._access_page(self.page_number+1))
        self.page_count = ttk.Label(self.pager, foreground=MUTED)
        self.page_count.pack(side="left")
        self.next.pack(side="right")
        self.previous.pack(side="right")
        self.refs.bind("<ButtonRelease-1>", lambda e: self._follow(self.refs.identify_row(e.y)))
        self.refs.bind("<Return>", lambda _: self._follow(self.refs.focus()))
        self.refs.bind("<FocusIn>", self._reveal)
        self.viewport.bind("<Configure>", self._resize)
        self.page.bind("<Configure>", self._fit)
        self.reset("Select a stack variable with a verified layout.")

    def _fonts_changed(self, _event):
        if self.strip:
            self.strip.configure(height=max(28, self.mono.metrics("linespace")*2))
        if self.current_slot:
            self._size_columns(self.current_slot)

    def _resize(self, event):
        width = max(80, event.width - 4)
        for label in (self.title, self.source, self.summary, self.coverage):
            label.configure(wraplength=width)
        self._fit()

    def _fit(self, _event=None):
        width, height = self.viewport.winfo_width(), self.viewport.winfo_height()
        needed = self.page.winfo_reqheight()
        if needed > height:
            self.scroll.grid()
        else:
            self.scroll.grid_remove()
        full = max(needed, height)
        self.viewport.itemconfigure(self.page_id, width=width, height=full)
        self.viewport.configure(scrollregion=(0, 0, width, full))

    def _reveal(self, event):
        widget = event.widget
        y = widget.winfo_rooty() - self.page.winfo_rooty()
        top = self.viewport.canvasy(0)
        height = self.viewport.winfo_height()
        if y < top or y + widget.winfo_height() > top + height:
            self.viewport.yview_moveto(y / max(1, self.page.winfo_height()))

    @property
    def current_field(self):
        return self.field_name.get() or None

    def reset(self, message):
        self.current_slot = self.current_layout = self.intervals = None
        self.strip = None
        self.accesses = ()
        self.page_number = 0
        self.pager.pack_forget()
        self.rows.clear()
        self.fields.clear()
        self.ticks.clear()
        self.field_name.set("")
        self.refs.delete(*self.refs.get_children())
        self.map.destroy()
        self.map = ttk.Frame(self.body)
        self.map.pack(before=self.summary, fill="x", pady=(4, 5))
        for button in (self.edit, self.recover, self.revisions):
            button.pack_forget()
        self.body.pack_forget()
        self.title.configure(text=message)
        self.viewport.yview_moveto(0)
        self.after_idle(self._fit)

    def populate(self, slot, rows, field="LowPart", *, layout=None, provenance="", saved=False, has_revisions=False):
        self.reset("Select a recovered stack variable.")
        if slot is None:
            return
        layout = layout or slot.layout
        self.current_layout = layout
        self.current_slot = slot
        self.rows = {row.rva: row for row in rows}
        recognized = bool(slot.layout_calls and layout == slot.layout and not saved)
        self.title.configure(text=(f"{layout.name}  ·  {layout.size}-byte {'union' if recognized else 'layout'}"
                                   if layout else f"{slot.size}-byte stack storage"))
        source = [slot.name, f"entry RSP {signed_offset(slot.offset)}"]
        if provenance:
            source.append(provenance)
        if recognized:
            calls = f"0x{slot.layout_calls[0]:X}"
            if len(slot.layout_calls)>1:
                calls += f" (+{len(slot.layout_calls)-1} more)"
            source.append(f"QueryPerformanceCounter output at {calls}")
        self.source.configure(text="  ·  ".join(source))
        for button, show in ((self.edit, self.on_edit), (self.recover, saved and self.on_reset),
                             (self.revisions, has_revisions and self.on_revisions)):
            if show:
                button.pack(side="left", padx=(0, 3))
        self.edit.configure(text="Edit layout…" if layout else "Create layout…")
        self.body.pack(fill="both", expand=True)
        self.mode.set("Read" if recognized else "All")
        if layout and recognized:
            self._byte_map(layout)
        elif layout:
            self._interval_map(layout)
        self._size_columns(slot)
        initial = field if layout and any(f.name == field for f in layout.fields) else None
        if layout and layout.fields:
            self.select_field(initial or layout.fields[0].name)
        else:
            self.summary.configure(text="No fields defined for this stack storage.")
            self.coverage.configure(text="")

    def _byte_map(self, layout):
        for offset in range(layout.size):
            self.map.columnconfigure(offset, weight=1, uniform="byte")
            tick = ttk.Label(self.map, text=f"+{offset:X}", anchor="center", font=MONO)
            tick.grid(row=0, column=offset, sticky="ew")
            self.ticks.append(tick)
        lane, end = 1, 0
        for member in layout.fields:
            if member.offset < end:
                lane += 1
            end = member.offset + member.size
            button = ttk.Radiobutton(self.map, text=member.name, value=member.name, variable=self.field_name,
                                     style="Field.Toolbutton", takefocus=True, command=self._render)
            button.grid(row=lane, column=member.offset, columnspan=member.size, sticky="ew", pady=(0, 2))
            button.bind("<Return>", self._activate_field)
            button.bind("<FocusIn>", self._reveal)
            self.fields[member.name] = button

    def _interval_map(self, layout):
        columns = ("offset", "size", "field", "type")
        self.strip = tk.Canvas(self.map, width=1, height=max(28,self.mono.metrics("linespace")*2),
                               highlightthickness=0, background=SURFACE)
        self.strip.pack(fill="x")
        self.strip.bind("<Configure>", self._draw_strip)
        box = ttk.Frame(self.map)
        box.pack(fill="both", expand=True)
        self.intervals = ttk.Treeview(box, columns=columns, show="headings", height=4,
                                      style="Insight.Treeview", selectmode="browse")
        for key, text, width in zip(columns, ("Offset", "Bytes", "Field", "Type"), (72, 53, 110, 100)):
            self.intervals.heading(key, text=text, anchor="w")
            self.intervals.column(key, width=width, minwidth=50, stretch=key in ("field","type"))
        scrollable(box, self.intervals)
        segments = [(f.offset, f.size, f.name, f.type_name or "Unknown", f"f{n}")
                    for n, f in enumerate(layout.fields)]
        segments.extend((at, size, "Unassigned", "—", f"gap{at}") for at, size in layout.gaps())
        for at, size, name, type_name, item in sorted(segments, key=lambda s:s[0]):
            self.intervals.insert("", "end", iid=item, values=(f"+0x{at:X}",size,name,type_name))
        self.intervals.bind("<<TreeviewSelect>>", self._interval_selected)
        self.intervals.bind("<FocusIn>", self._reveal)

    def _draw_strip(self, _event=None):
        if not self.strip or not self.current_layout:
            return
        strip, layout = self.strip, self.current_layout
        strip.delete("all")
        w, h = max(2, strip.winfo_width()-1), strip.winfo_height()
        upper, lower = 1, max(8, h-self.mono.metrics("linespace")-3)
        bounds = sorted({0,layout.size} | {p for f in layout.fields for p in (f.offset, f.offset+f.size)})
        for start, stop in zip(bounds,bounds[1:]):
            covering = [f for f in layout.fields if f.offset <= start < f.offset+f.size]
            color, kind = (WELL,"gap") if not covering else (AMBER,"overlap") if len(covering)>1 else (TEAL,"field")
            x1, x2 = start*w/layout.size, stop*w/layout.size
            strip.create_rectangle(x1,upper,max(x1+1,x2),lower, fill=color, outline=LINE,
                                   stipple="gray50" if kind=="gap" else "", tags=(kind,))
        # Exact offsets remain in the keyboard-accessible table even for subpixel fields.
        selected = self.intervals.selection() if self.intervals else ()
        if selected:
            offset = int(self.intervals.set(selected[0], "offset"),16)
            size = int(self.intervals.set(selected[0],"size"))
            left, right = offset*w/layout.size, (offset+size)*w/layout.size
            strip.create_line(min(w-2,left),lower+1,max(min(w-2,left)+2,right),lower+1,
                              width=3,fill=CRIMSON,tags=("selected",))
        for x, txt, anchor in ((0, "+0", "nw"), (w, f"+0x{layout.size-1:X}", "ne")):
            strip.create_text(x,lower+3,text=txt,font=MONO,fill=MUTED,anchor=anchor)

    def _interval_selected(self, _event):
        if self.intervals is None:
            return
        sel = self.intervals.selection()
        if not sel:
            return
        item = sel[0]
        if item.startswith("gap"):
            self.field_name.set("")
            self.refs.delete(*self.refs.get_children())
            self.accesses = ()
            self.pager.pack_forget()
            self._draw_strip()
            self.summary.configure(text=f"Unassigned span  ·  {self.intervals.set(item, 'offset')}  ·  "
                                        f"{self.intervals.set(item, 'size')} B")
            self.coverage.configure(text="No field covers these bytes.")
        else:
            name = self.intervals.set(item, "field")
            if self.current_field != name:
                self.select_field(name)

    def _size_columns(self, slot):
        # A stable coordinate for each column helps compare the union's interpretations.
        samples = {key: self.refs.heading(key, "text") for key in self.refs["columns"]}
        samples["coverage"] = max(samples["coverage"], "Partial read", key=len)
        for access in slot.accesses:
            row = self.rows.get(access.rva)
            if row is None:
                continue
            samples["access"] = max(samples["access"], access.kind, key=len)
            samples["rva"] = max(samples["rva"], f"0x{row.rva:X}", key=len)
            samples["width"] = max(samples["width"], f"{access.size} B", key=len)
            samples["bytes"] = max(samples["bytes"], row.raw.hex(" "), key=len)
            samples["instruction"] = max(samples["instruction"], f"{row.op} {row.args}", key=len)
        for key, sample in samples.items():
            width = self.mono.measure(sample) + self.winfo_pixels("9p")
            self.refs.column(key, width=width, minwidth=width, stretch=key == "instruction")

    @staticmethod
    def _activate_field(event):
        event.widget.invoke()
        return "break"

    def select_field(self, name):
        if self.current_layout and any(f.name == name for f in self.current_layout.fields):
            self.field_name.set(name)
            if self.intervals:
                i = next(i for i,f in enumerate(self.current_layout.fields) if f.name == name)
                key = f"f{i}"
                if self.intervals.selection() != (key,):
                    self.intervals.selection_set(key)
                    self.intervals.focus(key)
                    self.intervals.see(key)
            self._render()

    def _render(self):
        slot = self.current_slot
        if not slot or not self.current_layout or not self.current_field:
            return
        member = next(field for field in self.current_layout.fields if field.name == self.current_field)
        summary = f"{member.name}  ·  {member.type_name or 'Unknown type'}  ·  offset +0x{member.offset:X}  ·  {member.size} B"
        neighbors = [f.name for f in self.current_layout.fields if f != member and f.offset < member.offset+member.size
                     and member.offset < f.offset+f.size]
        if neighbors:
            summary += "  ·  overlaps " + ", ".join(neighbors[:3])
            if len(neighbors)>3:
                summary += f" (+{len(neighbors)-3})"
        self.summary.configure(text=summary)
        for offset, tick in enumerate(self.ticks):
            tick.configure(foreground=AMBER if member.offset <= offset < member.offset + member.size else MUTED)
        self._draw_strip()
        readings = sorted(member.accesses(slot, self.mode.get()), key=lambda match: (match[1] != "Exact span", match[0].rva))
        self.accesses = [(a, relation) for a,relation in readings if a.rva in self.rows]
        total = len(self.accesses)
        exact = sum(relation == "Exact span" for _,relation in self.accesses)
        self._access_page(0)
        scope = {"All":"accesses", "Read":"reads", "Write":"writes"}[self.mode.get()]
        self.coverage.configure(text=f"Field {scope}  ·  {exact} exact  ·  {total-exact} overlapping"
                                if total else f"No verified {scope} of these bytes.")

    @staticmethod
    def _access_id(access):
        return f"{access.rva:X}:{access.offset}:{access.size}:{access.kind}"

    def _access_page(self, page):
        total = len(self.accesses)
        self.page_number = max(0,min(page,(total-1)//PAGE))
        begin = self.page_number*PAGE
        self.refs.delete(*self.refs.get_children())
        for access, relation in self.accesses[begin:begin+PAGE]:
            row = self.rows[access.rva]
            self.refs.insert("", "end", iid=self._access_id(access), values=(f"0x{row.rva:X}", access.kind,
                             relation, f"{access.size} B", row.raw.hex(" ").upper(), f"{row.op} {row.args}".rstrip()))
        if total > PAGE:
            self.pager.pack(fill="x")
            self.page_count.configure(text=f"{begin+1}–{min(begin+PAGE,total)} of {total} accesses")
            self.previous.state(["!disabled" if begin else "disabled"])
            self.next.state(["!disabled" if begin+PAGE < total else "disabled"])
        else:
            self.pager.pack_forget()

    def _follow(self, item):
        if item and self.on_follow and self.refs.exists(item):
            self.refs.focus(item)
            self.refs.selection_set(item)
            self.on_follow(self.rows[int(self.refs.set(item, "rva"), 16)])
        return "break"

    def selection_state(self):
        selection = self.refs.selection()
        return self.current_field, selection[0] if selection else None

    def capture_state(self):
        selected = self.intervals.selection() if self.intervals else ()
        return (*self.selection_state(), self.mode.get(), self.viewport.yview()[0], self.page_number,
                selected[0] if selected else None)

    def focus_selection(self):
        if self.current_field in self.fields:
            self.fields[self.current_field].focus_set()
        elif self.intervals and self.intervals.get_children():
            self.intervals.focus_set()
        elif self.edit.winfo_ismapped():
            self.edit.focus_set()

    def restore(self, state):
        field, item = state[:2]
        if len(state)>2:
            self.mode.set(state[2])
        self.select_field(field)
        if len(state)>5 and not field and self.intervals and state[5] and self.intervals.exists(state[5]):
            self.intervals.selection_set(state[5])
            self.intervals.focus(state[5])
            self.intervals.see(state[5])
            self._interval_selected(None)
        if len(state)>4:
            self._access_page(state[4])
        if item and not self.refs.exists(item):
            for i,(access, _) in enumerate(self.accesses):
                if self._access_id(access) == item:
                    self._access_page(i//PAGE)
                    break
        if item and self.refs.exists(item):
            self.refs.selection_set(item)
            self.refs.focus(item)
            self.refs.see(item)
            self.refs.focus_set()
        else:
            self.focus_selection()
        if len(state)>3:
            self.viewport.yview_moveto(state[3])
