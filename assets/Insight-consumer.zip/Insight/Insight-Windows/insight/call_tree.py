"""Build-scoped call relationships from reachable, byte-verified x64 instructions."""

from bisect import bisect_right
from collections import defaultdict
from dataclasses import dataclass, replace
from hashlib import sha256

from .pe import Routine


@dataclass(frozen=True)
class ImportSymbol:
    module: str
    name: str
    iat_rva: int


@dataclass(frozen=True)
class CallSite:
    routine: Routine
    rva: int
    raw: bytes
    symbol: ImportSymbol | None
    kind: str
    assembly: str
    target: Routine | None = None
    destination_rva: int | None = None

    @property
    def label(self):
        if self.symbol:
            return f"{self.symbol.module}!{self.symbol.name}"
        if self.kind == "Call to interior address":
            return f"0x{self.destination_rva:X} · inside indexed function"
        if self.target:
            return self.target.name
        if self.destination_rva is not None:
            return f"0x{self.destination_rva:X} · unverified entry"
        return "Unresolved destination"


def direct_target(row):
    """Accept a relative CALL only when its encoded displacement agrees with the decoder."""
    raw = row.raw
    if len(raw) < 5 or raw[-5] != 0xe8:
        return None
    if any(p not in (0xf2, 0xf3, 0x26, 0x2e, 0x36, 0x3e) and not 0x40 <= p <= 0x4f for p in raw[:-5]):
        return None
    address = row.rva + len(raw) + int.from_bytes(raw[-4:], "little", signed=True)
    return address if address == row.target else None


def distinct_instruction(at, visited):
    """Another reachable x64 instruction must not overlap the proposed boundary."""
    size = visited.get(at, 0)
    return (size > 0 and not any(visited.get(at - n, 0) > n for n in range(1, 15))
            and not any(at + n in visited for n in range(1, size)))


def validated_calls(image, records, visited, cancel):
    starts = sorted(r.rva for r in image.routines if r.extent.startswith("x64 unwind table"))
    # Nested unwind entries still establish covered bytes after an inner one ends.
    ends = []
    for start in starts:
        ends.append(max(ends[-1] if ends else 0, image.range_ends[start]))
    for site in sorted(records, key=lambda s: s.rva):
        if cancel is not None and cancel.is_set():
            raise ValueError("Call indexing cancelled.")
        if not site.routine.rva <= site.rva < site.routine.end or not distinct_instruction(site.rva, visited):
            continue
        target = site.target
        if target:
            pos = bisect_right(starts, target.rva) - 1
            if target.rva not in image.function_entries and pos >= 0 and target.rva < ends[pos]:
                site = replace(site, target=None, kind="Call to interior address")
            if not distinct_instruction(target.rva, visited):
                # A direct destination can be known without establishing a separate function.
                site = replace(site, target=None, symbol=None, kind="Unverified direct call")
        yield site


class CallTree:
    def __init__(self, image, records, *, partial=False, omitted=0):
        self.digest = sha256(image.data).hexdigest()
        incoming, outgoing = defaultdict(list), defaultdict(list)
        self.sites = tuple(records)
        self.omitted = omitted
        for site in self.sites:
            outgoing[site.routine.rva].append(site)
            if site.target:
                incoming[site.target.rva].append(site)
        self.partial = partial or bool(self.omitted)
        self._incoming = {at: tuple(group) for at, group in incoming.items()}
        self._outgoing = {at: tuple(group) for at, group in outgoing.items()}

    def incoming(self, routine_rva):
        return self._incoming.get(routine_rva, ())

    def outgoing(self, routine_rva):
        return self._outgoing.get(routine_rva, ())
