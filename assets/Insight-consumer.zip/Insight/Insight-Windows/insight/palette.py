"""Read-only desktop search across commands, routines and file-backed strings."""

from dataclasses import dataclass
import re
import tkinter as tk
from tkinter import ttk

from .appearance import CANVAS, INK, MONO, MUTED, scrollable
from .dialogs import Prompt


SCAN_BYTES = 512 * 1024
STRINGS_PER_ENCODING = 1024
RESULTS_PER_KIND = 24
PAGE_BYTES = 32
SEARCH_CHUNK = 128 * 1024
_ASCII = re.compile(rb"[\x20-\x7e]{4,}")
_HEX = re.compile(r"\+?(?:0x)?([0-9a-f]{1,8})", re.I)


@dataclass(frozen=True)
class StringHit:
    rva: int
    size: int
    encoding: str
    text: str


def _wide(data, first, stop):
    """Recognize NUL-terminated printable UTF-16LE runs in either byte alignment."""
    for alignment in (0, 1):
        at = start = first + alignment
        length = 0
        while at+1 < stop:
            unit = data[at] | (data[at+1] << 8)
            width = 2
            if 0xd800 <= unit < 0xdc00 and at+3 < stop:
                low = data[at+2] | (data[at+3] << 8)
                if 0xdc00 <= low < 0xe000:
                    unit = 0x10000 + ((unit-0xd800) << 10) + low-0xdc00
                    width = 4
            if 32 <= unit <= 126 or (unit > 126 and chr(unit).isprintable()):
                length += 1
            else:
                if unit == 0 and length >= 4:
                    yield start, at
                start = at+width
                length = 0
            at += width


def scan_strings(image, byte_limit=SCAN_BYTES, result_limit=STRINGS_PER_ENCODING):
    data = image.data
    hits, counts, capped = [], {}, set()
    scanned = 0
    total = sum(section.backed for section in image.sections)
    # Prefer data sections when the image exceeds the scan budget.
    for section in sorted(image.sections, key=lambda s:s.executable):
        size = min(section.backed, byte_limit-scanned)
        if size <= 0:
            if scanned >= byte_limit:
                break
            continue
        first, stop = section.offset, section.offset+size
        scanned += size
        ascii_runs = ((m.start(), m.end()) for m in _ASCII.finditer(data, first, stop)
                      if m.end() < stop or size == section.backed or not 32 <= data[stop] <= 126)
        for encoding, codec, spans in (("ASCII", "ascii", ascii_runs),
                                      ("UTF-16LE", "utf-16-le", _wide(data, first, stop))):
            if encoding in capped:
                continue
            for start, end in spans:
                if counts.get(encoding, 0) == result_limit:
                    capped.add(encoding)
                    break
                hits.append(StringHit(section.rva+start-first, end-start, encoding,
                                      data[start:end].decode(codec)))
                counts[encoding] = counts.get(encoding, 0) + 1
        if len(capped) == 2:
            break
    scope = f"Printable runs of 4+ characters · {scanned:,} of {total:,} file-backed section bytes"
    if scanned < total:
        scope += " · partial scan"
    if capped:
        scope += " · result limit reached for " + ", ".join(sorted(capped))
    return tuple(hits), scope


def literal_spans(image, text):
    """Yield exact byte spans and a checkpoint after each bounded section slice."""
    if not 1 <= len(text) <= 256 or not text.isprintable():
        raise ValueError("Enter 1–256 printable characters for an exact search.")
    needles = [("UTF-16LE span", text.encode("utf-16-le"))]
    if text.isascii():
        needles.insert(0, ("ASCII span", text.encode("ascii")))
    for section in image.sections:
        end = section.offset+section.backed
        for first in range(section.offset, end, SEARCH_CHUNK):
            stop = min(end, first+SEARCH_CHUNK)
            for label, needle in needles:
                # Overlap the next slice just enough to recognize a split match.
                limit = min(end, stop+len(needle)-1)
                at = image.data.find(needle, first, limit)
                while first <= at < stop:
                    yield StringHit(section.rva+at-section.offset, len(needle), label, text)
                    at = image.data.find(needle, at+1, limit)
            yield None


class Palette(Prompt):
    def __init__(self, parent, case, commands, initial=""):
        super().__init__(parent, "Command palette")
        self.case = case
        self.commands = tuple(commands)
        self.image = case.image if case else None
        self.index = getattr(case, "_palette_strings", None)
        self.scan_job = None
        self.exact_job = self.stream = self.literal = None
        self.literal_start = 0
        self.choices = []
        self.previous_term = None
        self.page = 0
        self.body.columnconfigure(0, weight=1)
        self.query = tk.StringVar(self, initial)
        ttk.Label(self.body, text="Search commands, functions, addresses or strings").grid(sticky="w")
        self.entry = ttk.Entry(self.body, textvariable=self.query, width=42)
        self.entry.grid(row=1, column=0, sticky="ew", pady=(3, 5))
        frame = ttk.Frame(self.body)
        frame.grid(row=2, column=0, sticky="nsew")
        self.results = ttk.Treeview(frame, columns=("kind", "label", "address"), show="headings",
                                    selectmode="browse", height=6, style="Insight.Treeview")
        for key, title, width in (("kind", "Kind", 84), ("label", "Result", 248),
                                 ("address", "RVA" if self.image else "Offset", 88)):
            self.results.heading(key, text=title, anchor="w")
            self.results.column(key, width=width, minwidth=48, stretch=key=="label")
        scrollable(frame, self.results)
        self.results.bind("<<TreeviewSelect>>", lambda _:self._preview(0))
        self.results.bind("<Double-Button-1>", lambda e:self.activate() if self.results.identify_row(e.y) else None)
        for key, delta in (("Down", 1), ("Up", -1)):
            self.entry.bind("<"+key+">", lambda _,d=delta:self._step(d))
        self.actions_row = ttk.Frame(self.body)
        self.exact = ttk.Button(self.actions_row, command=self._start_exact)
        self.exact.pack(side="left")
        self.reset = ttk.Button(self.actions_row, text="All results", command=self._changed)
        self.scope = ttk.Label(self.body, foreground=MUTED, wraplength=420)
        self.scope.grid(row=4, column=0, sticky="ew", pady=(3, 0))
        self.scope.bind("<Configure>", lambda e:self.scope.configure(wraplength=max(110, e.width-4)))
        self.evidence = ttk.Frame(self.body)
        self.evidence.columnconfigure(0, weight=1)
        self.range = ttk.Label(self.evidence, font=MONO)
        self.range.grid(row=0, column=0, sticky="w")
        self.prior = ttk.Button(self.evidence, text="‹", width=3, command=lambda:self._preview(self.page-1))
        self.later = ttk.Button(self.evidence, text="›", width=3, command=lambda:self._preview(self.page+1))
        self.prior.grid(row=0, column=1)
        self.later.grid(row=0, column=2)
        self.preview = tk.Text(self.evidence, font=MONO, background=CANVAS, foreground=INK,
                               height=4, width=40, wrap="none", borderwidth=0, state="disabled")
        self.preview.grid(row=1, column=0, columnspan=3, sticky="ew", pady=2)
        self.references = ttk.Button(self.evidence, text="Find string references", command=self.activate)
        self.references.grid(row=2, column=0, columnspan=3, sticky="e")
        self.query.trace_add("write", lambda *_:self._changed())
        self.refresh()

    def finish(self, value=None):
        if self.scan_job:
            self.after_cancel(self.scan_job)
            self.scan_job = None
        self._cancel_exact()
        super().finish(value)

    def _cancel_exact(self):
        if self.exact_job:
            self.after_cancel(self.exact_job)
        self.exact_job = self.stream = self.literal = None

    def _changed(self):
        self._cancel_exact()
        self.refresh()

    def _start_exact(self):
        if self.scan_job:
            self.after_cancel(self.scan_job)
            self.scan_job = None
        if self.stream is None:
            self.stream = literal_spans(self.image, self.query.get())
            self.literal_start = 0
        else:
            self.literal_start += len(self.literal)
        self.literal = []
        self.exact.configure(text="Searching…", state="disabled")
        self.reset.configure(text="Cancel search")
        self.reset.pack(side="left", padx=(3, 0))
        self._advance()

    def _advance(self):
        self.exact_job = None
        for hit in self.stream:
            if hit is None:
                self.exact_job = self.after(1, self._advance)
                break
            self.literal.append(hit)
            if len(self.literal) == RESULTS_PER_KIND:
                break
        else:
            self.stream = None
        if not self.exact_job:
            self.exact.configure(text="Find next matches" if self.stream else "Search again", state="normal")
            self.reset.configure(text="All results")
        self.refresh()

    def _index(self):
        self.scan_job = None
        self.index = self.case._palette_strings = scan_strings(self.image)
        self.refresh()

    def selected(self):
        selected = self.results.selection()
        return self.choices[int(selected[0])] if selected else None

    def refresh(self):
        term = self.query.get().strip().casefold()
        old = self.selected() if term == self.previous_term else None
        self.previous_term = term
        if self.literal is not None:
            choices = [(hit.encoding, hit.text, hit.rva, hit) for hit in self.literal]
            count = self.literal_start + len(choices)
            note = f"Exact spans · matches {self.literal_start+1}–{count}" if choices else "No matches on this page"
            note += " · match can be part of a longer string"
            note += " · scanning…" if self.exact_job else " · all sections searched" if self.stream is None else ""
            self._results(choices, note, old)
            return
        if self.image and self.query.get():
            self.actions_row.grid(row=3, column=0, sticky="ew", pady=(3, 0))
            valid = len(self.query.get()) <= 256 and self.query.get().isprintable()
            self.exact.configure(text="Find exact text in all sections", state="normal" if valid else "disabled")
            self.reset.pack_forget()
        else:
            self.actions_row.grid_remove()
        choices = []
        limited = []
        def group(name, items):
            for i, choice in enumerate(items):
                if i == RESULTS_PER_KIND:
                    limited.append(name)
                    break
                choices.append(choice)
        number = _HEX.fullmatch(term)
        address = int(number[1], 16) if number else None
        if self.case and address is not None:
            choices.append(("Address", "Go to instruction", address, address))
        group("commands", (("Command", name, None, name) for name in self.commands
                           if term in name.casefold()))
        if self.case:
            functions = []
            for routine in self.case.routines:
                aliases = self.image.export_names.get(routine.rva, ()) if self.image else ()
                label = getattr(self.case, "display_name", lambda r: r.name)(routine)
                if term not in label.casefold() and routine.rva != address:
                    label = next((s for s in (routine.name, *sorted(aliases)) if term in s.casefold()), None)
                if label:
                    functions.append(("Function", label, routine.rva, routine))
                    if len(functions) > RESULTS_PER_KIND:
                        break
            group("functions", functions)
        note = ""
        if self.image and term:
            if self.index is None:
                if self.scan_job is None:
                    self.scan_job = self.after(80, self._index)
                note = "Indexing file-backed strings…"
            else:
                hits, note = self.index
                group("strings", ((hit.encoding, hit.text, hit.rva, hit) for hit in hits
                                  if term in hit.text.casefold() or hit.rva == address))
        if limited:
            note += ("  ·  " if note else "") + f"First {RESULTS_PER_KIND} " + "/".join(limited) + " shown"
        self._results(choices, note if choices else "No matches.  " + note, old)

    def _results(self, choices, note, old):
        self.choices = choices
        self.results.delete(*self.results.get_children())
        for i, (kind, label, addr, _) in enumerate(choices):
            short = label if len(label) <= 100 else label[:99] + "…"
            self.results.insert("", "end", iid=str(i), values=(kind, short, hex(addr) if addr is not None else ""))
        if choices:
            self._pick(choices.index(old) if old and old in choices else 0)
        else:
            self._preview(0)
        self.scope.configure(text=note)

    def _pick(self, i):
        key = str(i)
        self.results.selection_set(key)
        self.results.focus(key)
        self.results.see(key)
        self._preview(0)

    def _step(self, delta):
        if self.choices:
            selection = self.results.selection()
            index = int(selection[0]) if selection else 0
            self._pick(max(0, min(len(self.choices)-1, index+delta)))
        return "break"

    def _preview(self, page):
        choice = self.selected()
        if not choice or not isinstance(choice[3], StringHit):
            self.evidence.grid_remove()
            return
        hit = choice[3]
        self.page = max(0, min(page, (hit.size-1)//PAGE_BYTES))
        offset = self.page*PAGE_BYTES
        length = min(PAGE_BYTES, hit.size-offset)
        start = self.image.offset(hit.rva+offset, length)
        raw = self.image.data[start:start+length]
        self.range.configure(text=f"RVA 0x{hit.rva:X} · bytes {offset+1}–{offset+length} of {hit.size}")
        self.prior.state(["!disabled" if offset else "disabled"])
        self.later.state(["!disabled" if offset+length < hit.size else "disabled"])
        self.preview.configure(state="normal")
        self.preview.delete("1.0", "end")
        self.preview.insert("1.0", "\n".join(raw[i:i+8].hex(" ").upper() for i in range(0, len(raw), 8)))
        self.preview.configure(state="disabled")
        self.evidence.grid(row=5, column=0, sticky="ew", pady=(4, 0))

    def activate(self):
        choice = self.selected()
        if choice:
            kind, _, _, value = choice
            self.finish(("references", (value.rva, value.size)) if isinstance(value, StringHit)
                        else (kind.lower(), value))


def choose(parent, case, commands, initial=""):
    prompt = Palette(parent, case, commands, initial)
    prompt.entry.selection_range(0, "end")
    return prompt.show(prompt.activate, "Open selection", prompt.entry)
