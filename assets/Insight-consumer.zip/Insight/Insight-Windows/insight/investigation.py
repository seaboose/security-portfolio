"""Open a file snapshot or the packaged COFF example with the same instruction interface."""

from dataclasses import dataclass
from hashlib import sha256
from itertools import chain
from pathlib import Path

from .casebook import read_snapshot
from .desktop import case_data
from .pe import MAX_FILE_SIZE, flow_for, inspect_image, Instruction
from .records import read_local


@dataclass(frozen=True)
class ExampleRoutine:
    name: str
    rva: int
    end: int
    extent: str = "Retained whole routine"


class Investigation:
    def __init__(self, label, source, digest, data, image, routines, example=None):
        self.label, self.source, self.digest = label, source, digest
        self.data, self.image, self.routines = data, image, routines
        self.example = example
        self.keys = {self.key(routine): routine for routine in routines}
        self.function_annotations = {}

    def key(self, routine):
        return f"{routine.rva:X}" if self.image is not None else routine.name

    def display_name(self, routine):
        annotation = self.function_annotations.get(self.key(routine))
        return annotation.name if annotation and annotation.name else routine.name

    def include_callers(self, index):
        """Register discovered routine entries after binding the trace to this snapshot."""
        tree = index.call_tree
        if tree is not None and tree.digest != self.digest:
            raise ValueError("Call relationships belong to a different DLL snapshot.")
        for site in chain(index.calls, index.data, tree.sites if tree else ()):
            routine = site.routine
            self.keys.setdefault(self.key(routine), routine)
        if tree:
            for site in tree.sites:
                if site.target:
                    self.keys.setdefault(self.key(site.target), site.target)
        self.routines = sorted(self.keys.values(), key=lambda r: r.rva)

    def instructions(self, routine, cancel=None):
        if self.image is not None:
            return self.image.instructions(routine, cancel)
        rows = []
        for entry in self.example["build"]["functions"][routine.name]:
            op, args = entry["op"], entry["args"]
            flow, target = flow_for(op, args)
            rows.append(Instruction(rva=entry["at"], raw=bytes.fromhex(entry["bytes"]), op=op,
                                    args=args, target=target, flow=flow))
        return rows


def open_example(build="encoded"):
    payload = case_data()
    obj = payload["builds"][build]
    routines = [ExampleRoutine(name, 0, sum(len(bytes.fromhex(row["bytes"])) for row in rows))
                for name, rows in obj["functions"].items()]
    return Investigation(obj["object"], "example:" + build, obj["sha256"], None, None, routines,
                         {"build": obj, "report": payload["report"], "name": build})


def open_bytes(label, source, data):
    image = inspect_image(data)
    return Investigation(label, source, sha256(data).hexdigest(), data, image, image.routines)


def open_dll(path):
    path = Path(path).absolute()
    data = read_local(path, MAX_FILE_SIZE)
    return open_bytes(path.name, str(path), data)


def reopen_case(database, record):
    if record["source"] in ("example:plain", "example:encoded"):
        case = open_example(record["source"].split(":")[1])
        if case.digest != record["digest"]:
            raise ValueError("The bundled example changed. Reopen it as a new case.")
        return case
    return open_bytes(record["label"], record["source"], read_snapshot(database, record["digest"]))
