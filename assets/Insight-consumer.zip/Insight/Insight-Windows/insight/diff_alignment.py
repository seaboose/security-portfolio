"""Bounded sequence alignment for verified machine rows and decompiler text."""

from bisect import bisect_left
from dataclasses import dataclass
from difflib import SequenceMatcher
from itertools import zip_longest
import re


@dataclass(frozen=True)
class Aligned:
    left: int | None
    right: int | None
    status: str


def _check(cancel):
    if cancel is not None and cancel.is_set():
        raise ValueError("Binary comparison cancelled.")


def _unique(pairs):
    """Keep a key usable only while it identifies one address (or row) in this build."""
    found = {}
    for key, value in pairs:
        if found.setdefault(key, value) != value:
            found[key] = None
    return found


def _anchors(a, b):
    """Longest ordered chain of rows that occur exactly once on each side."""
    left, right = _unique((k, i) for i, k in enumerate(a)), _unique((k, i) for i, k in enumerate(b))
    chain, tips, stops = [], [], []
    for key, i in left.items():
        j = right.get(key)
        if i is None or j is None:
            continue
        pos = bisect_left(stops, j)
        chain.append((i, j, tips[pos-1] if pos else -1))
        node = len(chain)-1
        if pos == len(stops):
            stops.append(j)
            tips.append(node)
        else:
            stops[pos], tips[pos] = j, node
    ordered = []
    node = tips[-1] if tips else -1
    while node >= 0:
        i, j, node = chain[node]
        ordered.append((i, j))
    return reversed(ordered)


def _align(a, b, cancel, unpaired=False, shapes=None):
    """Use exact anchors; pair replacement runs in display order without inventing an address link."""
    aligned = []
    limit = 512 * 512

    def emit(i, end_a, j, end_b, replace=False):
        if replace and shapes and i < end_a and j < end_b:
            # Exact bytes bracket this run. Use operand shapes to align changed
            # immediates or displacements. Leave unrelated instructions one-sided.
            old, new = shapes
            for row in _align(old[i:end_a], new[j:end_b], cancel):
                x = i + row.left if row.left is not None else None
                y = j + row.right if row.right is not None else None
                if row.status == "Equal":
                    aligned.append(Aligned(x, y, "Equal" if a[x] == b[y] else "Changed"))
                else:
                    if x is not None:
                        aligned.append(Aligned(x, None, "Removed"))
                    if y is not None:
                        aligned.append(Aligned(None, y, "Added"))
            return
        for x, y in zip_longest(range(i, end_a), range(j, end_b)):
            if x is None:
                status = "Uncompared" if unpaired else "Added"
            elif y is None:
                status = "Uncompared" if unpaired else "Removed"
            else:
                status = "Equal" if a[x] == b[y] else "Changed"
            aligned.append(Aligned(x, y, status))

    def gap(i, end_a, j, end_b):
        _check(cancel)
        while i < end_a and j < end_b and a[i] == b[j]:
            aligned.append(Aligned(i, j, "Equal"))
            i += 1
            j += 1
        suffix = 0
        while i < end_a-suffix and j < end_b-suffix and a[end_a-suffix-1] == b[end_b-suffix-1]:
            suffix += 1
        x, y = end_a-suffix, end_b-suffix
        if (x-i) * (y-j) <= limit and i < x and j < y:
            matcher = SequenceMatcher(None, a[i:x], b[j:y], autojunk=False)
            for tag, p, q, r, s in matcher.get_opcodes():
                emit(i+p, i+q, j+r, j+s, replace=tag == "replace")
        else:
            # Unanchored, highly repetitive regions stay in display order, with bounded cost.
            emit(i, x, j, y, replace=True)
        emit(x, end_a, y, end_b)

    i = j = 0
    if len(a) * len(b) > limit:
        for x, y in _anchors(a, b):
            gap(i, x, j, y)
            aligned.append(Aligned(x, y, "Equal"))
            i, j = x+1, y+1
    gap(i, len(a), j, len(b))
    return tuple(aligned)


def instruction_shape(row):
    return row.op, re.sub(r"\b(?:0x[0-9a-f]+|[0-9][0-9a-f]*h?)\b", "#", row.args, flags=re.I)


def align_instructions(left, right, cancel=None, unpaired=False):
    shapes = [[instruction_shape(row) for row in rows] for rows in (left, right)]
    return _align([row.raw for row in left], [row.raw for row in right], cancel, unpaired, shapes)


def reindex(alignment, left, right):
    """Translate per-slice positions back into the original listing or pseudocode."""
    return tuple(Aligned(left[row.left] if row.left is not None else None,
                         right[row.right] if row.right is not None else None, row.status)
                 for row in alignment)
