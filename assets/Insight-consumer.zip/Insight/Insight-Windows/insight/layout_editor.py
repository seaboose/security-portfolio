"""Edit project fields inside the fixed byte extent of a recovered stack slot."""

from tkinter import ttk

from .appearance import AMBER, MONO, MUTED, scrollable
from .dialogs import Prompt
from .stack_view import signed_offset
from .struct_layout import Field, Layout


class LayoutEditor(Prompt):
    def __init__(self, parent, slot, initial=None):
        if initial and initial.size != slot.size:
            raise ValueError("This layout belongs to a different storage extent.")
        super().__init__(parent, "Edit stack layout")
        self.slot = slot
        self.members = list(initial.fields if initial else ())
        self.active = None
        head = ttk.Frame(self.body)
        head.pack(fill="x")
        ttk.Label(head, text="Layout name").pack(side="left", padx=(0, 5))
        self.layout_name = ttk.Entry(head, font=MONO)
        self.layout_name.insert(0, initial.name if initial else "Stack_layout")
        self.layout_name.pack(side="left", fill="x", expand=True)
        ttk.Label(self.body, text=f"{slot.name}  ·  entry RSP {signed_offset(slot.offset)}  ·  {slot.size} bytes",
                  foreground=MUTED, wraplength=420).pack(anchor="w", pady=(3, 4))
        frame = ttk.Frame(self.body)
        frame.pack(fill="both", expand=True)
        columns = ("offset","size","name","type_name")
        self.table = ttk.Treeview(frame, columns=columns, show="headings", height=6, selectmode="browse",
                                  style="Insight.Treeview")
        for key, title, width in zip(columns, ("Offset","Bytes","Field","Type"), (76,55,126,135)):
            self.table.heading(key, text=title, anchor="w")
            self.table.column(key, width=width, minwidth=44, stretch=key in ("name","type_name"))
        scrollable(frame, self.table)
        self.table.bind("<<TreeviewSelect>>", self._selected)
        self.entries = {}
        form = ttk.Frame(self.body)
        form.pack(fill="x", pady=(4, 0))
        form.columnconfigure((0, 1), weight=1, uniform="input")
        for i,(key,title) in enumerate((("name","Field name"),("type_name","Type (optional)"),
                                         ("offset","Byte offset"),("size","Byte size"))):
            pos, col = (i//2)*2, i%2
            ttk.Label(form, text=title).grid(row=pos,column=col,sticky="w")
            self.entries[key] = ttk.Entry(form, width=14, font=MONO)
            self.entries[key].grid(row=pos+1,column=col,sticky="ew",padx=(0,3))
        actions = ttk.Frame(self.body)
        actions.pack(fill="x", pady=(4, 0))
        self.add = ttk.Button(actions, text="Add field", command=lambda:self._change("add"))
        self.replace = ttk.Button(actions, text="Update selected", command=lambda:self._change("replace"))
        self.remove = ttk.Button(actions, text="Remove selected", command=lambda:self._change("remove"))
        self.revert = ttk.Button(actions, text="Discard field edits", command=self._discard)
        for button in (self.add,self.replace,self.remove):
            button.pack(side="left", padx=(0, 3))
        self.feedback = ttk.Label(self.body, foreground=AMBER, wraplength=420)
        self.feedback.pack(fill="x")
        self._refresh(0 if self.members else None)

    def _show(self, index):
        self.active = index
        field = self.members[index] if index is not None else None
        values = (field.name, field.type_name, hex(field.offset), str(field.size)) if field else ("","","","")
        for entry, value in zip(self.entries.values(), values):
            entry.delete(0, "end")
            entry.insert(0, value)
        self.original = values
        for button in (self.replace, self.remove):
            button.state(["!disabled" if field else "disabled"])

    def _selected(self, _event):
        selected = self.table.selection()
        if selected and int(selected[0]) != self.active:
            if self._dirty():
                self.revert.pack(side="left")
                self.feedback.configure(text="Add or update these field edits, or discard them before switching rows.")
                if self.active is not None:
                    self.table.selection_set(str(self.active))
                    self.table.focus(str(self.active))
                else:
                    self.table.selection_remove(*selected)
                return
            self._show(int(selected[0]))

    def _dirty(self):
        return tuple(entry.get() for entry in self.entries.values()) != self.original

    def _discard(self):
        self._show(self.active)
        self.revert.pack_forget()
        self.feedback.configure(text="")

    def _refresh(self, index):
        self.table.delete(*self.table.get_children())
        for i, field in enumerate(self.members):
            self.table.insert("", "end", iid=str(i), values=(hex(field.offset),field.size,
                                                            field.name,field.type_name or "Unknown"))
        self._show(index)
        if index is not None:
            self.table.selection_set(str(index))
            self.table.focus(str(index))
            self.table.see(str(index))

    def _change(self, action):
        index = self.active
        if index is None and action != "add":
            return
        updated = self.members.copy()
        try:
            if action == "remove":
                updated.pop(index)
                index = min(index,len(updated)-1) if updated else None
            else:
                def number(key):
                    value = self.entries[key].get().strip()
                    try:
                        return int(value, 16 if value.lower().startswith("0x") else 10)
                    except ValueError:
                        raise ValueError(f"Enter a decimal or 0x hexadecimal {key}.") from None
                field = Field(self.entries["name"].get().strip(), self.entries["type_name"].get().strip(),
                              number("offset"), number("size"))
                if action == "add":
                    index = len(updated)
                    updated.append(field)
                else:
                    updated[index] = field
            Layout("Draft", self.slot.size, tuple(updated))
        except ValueError as error:
            self.feedback.configure(text=str(error))
            return
        self.members = updated
        self._refresh(index)
        self.revert.pack_forget()
        self.feedback.configure(text="")

    def save(self):
        if self._dirty():
            self.revert.pack(side="left")
            self.feedback.configure(text="Add the new field or update the selected field before saving.")
            return
        try:
            layout = Layout(self.layout_name.get().strip(), self.slot.size, tuple(self.members))
        except ValueError as error:
            self.feedback.configure(text=str(error))
            return
        self.finish(layout)


def edit_layout(parent, slot, initial=None):
    editor = LayoutEditor(parent, slot, initial)
    return editor.show(editor.save, "Save layout", editor.layout_name)
