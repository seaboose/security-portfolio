"""Apply build-scoped analyst metadata to native views without changing decoded evidence."""

import tkinter as tk
from tkinter import ttk

from . import knowledge_view
from .ghidra import FunctionToken, GlobalToken
from .knowledge import Annotation, StaleEdit, Subject


class AnalystEdits:
    def __init__(self, app):
        self.app = app
        self.knowledge = None
        self.functions = {}

    def bind(self, case, knowledge, functions):
        self.knowledge, self.functions = knowledge, functions
        case.function_annotations = self.functions

    def function_name(self, routine):
        case = self.app.case
        return case.display_name(routine) if case else routine.name

    def _subject(self, token):
        if isinstance(token, FunctionToken):
            return Subject.function(f"{token.rva:X}")
        if isinstance(token, GlobalToken):
            return Subject.global_(token.rva)
        return Subject.local(self.app.case.key(self.app.routine), token.offset, token.size)

    def symbol_overlays(self, result):
        if self.knowledge is None:
            return {}
        subjects = {token: self._subject(token) for line in result.lines
                    for field in ("globals", "stack", "functions") for token in getattr(line, field, ())}
        values = self.knowledge.annotations(subjects.values())
        return {token: values[key] for token, key in subjects.items() if key in values}

    def refresh(self):
        app, views = self.app, self.app.views
        self.knowledge.refresh()
        self.functions = self.knowledge.functions()
        app.case.function_annotations = self.functions
        app.routine_box["values"] = [app.routine_label(r) for r in app.case.routines]
        app.sync_routine()
        self.function_labels()
        if views.pseudo.result:
            pane, line = views.pseudo, views.pseudo.line
            target = pane.focus_snapshot()
            top, left = pane.code.yview()[0], pane.code.xview()[0]
            pane.populate(pane.result, app.rows)
            if line is not None:
                pane.choose_line(line, follow=False)
            else:
                pane.cursor(app.rows[app.index].rva)
            pane.restore_focus(target)
            pane.code.yview_moveto(top)
            pane.code.xview_moveto(left)
            self.stack_names()
        app.breadcrumbs.refresh(app.case, app.trail, app.step)
        app.xrefs.context.key = None
        if app.xrefs.index is not None and app.xrefs.visible:
            app.xrefs.matrix.set_index(app.xrefs.index)
        app.xrefs.update_context()

    def function_labels(self):
        app = self.app
        annotation = self.functions.get(app.case.key(app.routine), Annotation())
        title = annotation.name or app.views.name
        app.views.heading.configure(text=f"{title}   ·   {len(app.rows):,} instructions")
        scope = app.routine.extent
        if annotation.type_name:
            scope += "  ·  Analyst type " + annotation.type_name
        app.scope.configure(text=scope)

    def stack_names(self):
        app, stack = self.app, self.app.views.stack
        key = app.case.key(app.routine)
        subjects = {item: Subject.local(key, slot.offset, slot.size) for item, slot in stack.by_slot.items()}
        values = self.knowledge.annotations(subjects.values())
        regions = {(s.offset, s.size) for s in stack.regions}
        for item, subject in subjects.items():
            annotation = values.get(subject, Annotation())
            name = annotation.name or stack.by_slot[item].name
            if annotation.name and (subject.offset, subject.size) in regions:
                name += "  ·  Analyst range"
            if annotation.type_name:
                name += "  ·  " + annotation.type_name
            stack.slots.set(item, stack.slots["columns"][-1], name)

    def triage(self):
        if self.knowledge:
            case = self.app.case
            routine = knowledge_view.triage(self.app.root, case, self.knowledge, self.app.routine)
            if self.app.case is case:
                self.refresh()
                if routine is not None:
                    self.app.navigate(routine, routine.rva)

    def history(self):
        if self.knowledge:
            case = self.app.case
            knowledge_view.history(self.app.root, case, self.knowledge)
            if self.app.case is case:
                self.refresh()

    def shortcut(self, event, field):
        if event.state & 0x0C or event.widget.winfo_toplevel() != self.app.root:
            return
        if isinstance(event.widget, (tk.Entry, ttk.Entry, ttk.Combobox, tk.Spinbox)):
            return
        if isinstance(event.widget, tk.Text) and event.widget.cget("state") == "normal":
            return
        self.edit(field)
        return "break"

    def edit(self, field):
        app, views = self.app, self.app.views
        if self.knowledge is None:
            return
        case = app.case
        key = case.key(app.routine)
        subject = Subject.function(key)
        original, scope = app.routine.name, f"Function  ·  {app.routine.name}"
        reader = "" if app.xrefs.context_open or app.xrefs.visible else views.reader.select()
        if reader == str(views.pseudo) and (selected := views.pseudo.selected_symbol()):
            token, original = selected
            subject = self._subject(token)
            if subject.kind == "local":
                scope = f"Local in {app.routine.name}  ·  entry RSP {token.offset:+#x}  ·  {token.size} bytes"
            else:
                scope = f"{subject.kind.title()}  ·  RVA 0x{token.rva:X}"
        elif reader in (str(views.stack), str(views.struct)) and views.stack.current_slot:
            slot = views.stack.current_slot
            subject = Subject.local(key, slot.offset, slot.size)
            original = slot.name
            kind = "Analyst range" if slot in views.stack.regions else "Local"
            scope = f"{kind} in {app.routine.name}  ·  entry RSP {slot.offset:+#x}  ·  {slot.size} bytes"
        version = self.knowledge.version
        annotation = self.knowledge.get(subject)
        attr = "name" if field == "name" else "type_name"
        value = knowledge_view.edit_symbol(app.root, case, scope, original, getattr(annotation, attr), field)
        if value is not None and app.case is case:
            try:
                self.knowledge.edit(subject, expected=version, **{attr: value})
            except StaleEdit:
                app.status.set("Another editor changed this build. Review the refreshed value and retry your edit.")
            self.refresh()
