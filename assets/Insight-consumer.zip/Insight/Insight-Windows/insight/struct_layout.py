"""Bounded interpretations of stack storage and the physical spans of verified accesses."""

from dataclasses import dataclass
import re


MAX_FIELDS = 64
MAX_LAYOUT_BYTES = 2**31
_NAME = re.compile(r"[A-Za-z_][A-Za-z0-9_]{0,127}")
_TYPE = re.compile(r"[A-Za-z0-9_ .:$?@,*&()\[\]<>]{1,256}")
_KINDS = {"Read": ("Read", "Read via call"),
          "Write": ("Write", "Write via call")}
_KINDS["All"] = _KINDS["Read"] + _KINDS["Write"]


def _name(name):
    if not isinstance(name, str) or not _NAME.fullmatch(name):
        raise ValueError("Use an identifier of 1 to 128 letters, digits or underscores, starting with a letter or underscore.")


def _size(size):
    if type(size) is not int or not 1 <= size <= MAX_LAYOUT_BYTES:
        raise ValueError("Invalid stack layout size.")


@dataclass(frozen=True)
class Field:
    name: str
    type_name: str
    offset: int
    size: int

    def __post_init__(self):
        _name(self.name)
        _size(self.size)
        if type(self.offset) is not int or self.offset < 0 or self.offset + self.size > MAX_LAYOUT_BYTES:
            raise ValueError("Invalid field byte range.")
        if (not isinstance(self.type_name, str) or (self.type_name and
                (not _TYPE.fullmatch(self.type_name) or not re.search(r"[A-Za-z_]", self.type_name)))):
            raise ValueError("Enter a one-line type label up to 256 characters, or leave it empty.")

    def accesses(self, slot, mode="All"):
        """Compare a field with each recorded operand, retaining the original access width."""
        if mode not in _KINDS or self.offset + self.size > slot.size:
            raise ValueError("Invalid access filter or field outside selected stack storage.")
        start = slot.offset + self.offset
        end = start + self.size
        matches = []
        for access in slot.accesses:
            first, stop = access.offset, access.offset + access.size
            if access.kind not in _KINDS[mode] or access.size <= 0 or first >= end or stop <= start:
                continue
            kind = "read" if access.kind in _KINDS["Read"] else "write"
            if first == start and stop == end:
                relation = "Exact span"
            elif first <= start and end <= stop:
                relation = "Wider " + kind
            elif start <= first and stop <= end:
                relation = "Partial " + kind
            else:
                relation = "Overlap"
            matches.append((access, relation))
        return tuple(matches)

    def reads(self, slot):
        """Legacy Windows union view accepts only fields of the verified type."""
        if slot.layout is None or self not in slot.layout.fields:
            return ()
        return tuple((access, relation) for access, relation in self.accesses(slot, "Read")
                     if access.kind == "Read")


@dataclass(frozen=True)
class Layout:
    name: str
    size: int
    fields: tuple[Field, ...]

    def __post_init__(self):
        _name(self.name)
        _size(self.size)
        if not isinstance(self.fields, tuple) or len(self.fields) > MAX_FIELDS:
            raise ValueError(f"A layout supports up to {MAX_FIELDS} fields.")
        names = set()
        for field in self.fields:
            if not isinstance(field, Field) or field.offset + field.size > self.size:
                raise ValueError("A field exceeds the selected layout.")
            if field.name in names:
                raise ValueError("Use a distinct name for each field.")
            names.add(field.name)

    def gaps(self):
        """Return unassigned byte ranges as (offset, size), including trailing bytes."""
        gaps, stop = [], 0
        for field in sorted(self.fields, key=lambda f: f.offset):
            if field.offset > stop:
                gaps.append((stop, field.offset - stop))
            stop = max(stop, field.offset + field.size)
        if stop < self.size:
            gaps.append((stop, self.size - stop))
        return tuple(gaps)


def candidate_layout(slot):
    """Describe intersecting observed spans. A byte range alone cannot prove a member type."""
    _size(slot.size)
    spans = set()
    limited = False
    for access in slot.accesses:
        if access.kind not in _KINDS["All"]:
            continue
        first = max(0, access.offset - slot.offset)
        stop = min(slot.size, access.offset + access.size - slot.offset)
        if first < stop:
            span = first, stop - first
            if len(spans) == MAX_FIELDS and span not in spans:
                limited = True
                break
            spans.add(span)
    fields = tuple(Field(f"span_{offset:X}_{size:X}", "", offset, size) for offset, size in sorted(spans))
    return Layout("Observed_spans", slot.size, fields), limited


# winnt.h places the two 32-bit members in the same storage as the signed 64-bit value.
LARGE_INTEGER = Layout("LARGE_INTEGER", 8, (
    Field("LowPart", "DWORD", 0, 4),
    Field("HighPart", "LONG", 4, 4),
    Field("QuadPart", "LONGLONG", 0, 8),
))
