"""Compare basic blocks inside two indexed routines, preserving uncertain correspondence."""

from collections import Counter
from dataclasses import dataclass
import re

from .diff_alignment import Aligned, _align, _check, _unique, align_instructions, instruction_shape, reindex
from .flow_graph import Block, build_graph


@dataclass(frozen=True)
class ImmediateChange:
    left: int
    right: int
    before: int
    after: int


@dataclass(frozen=True)
class BlockChange:
    left: Block | None
    right: Block | None
    status: str
    basis: str
    instructions: tuple[Aligned, ...]
    constants: tuple[ImmediateChange, ...]


class _Blocks:
    def __init__(self, side, cancel):
        self.rows = side.rows if side else ()
        self.blocks = build_graph(self.rows).blocks
        self.exact = []
        self.shapes = []
        neighbors = [[] for _ in self.blocks]
        for i, block in enumerate(self.blocks):
            _check(cancel)
            rows = self.rows[block.first:block.stop]
            self.exact.append(tuple(r.raw for r in rows))
            exits = tuple((e.kind, e.reason) for e in block.edges)
            self.shapes.append((tuple(instruction_shape(r) for r in rows), exits))
            for edge in block.edges:
                if edge.block is not None:
                    neighbors[i].append((("out", edge.kind), edge.block))
                    neighbors[edge.block].append((("in", edge.kind), i))
        self.neighbors = [_unique(items) for items in neighbors]


def _matches(a, b, entry, cancel):
    pairs = {}
    used = set()

    def pair(i, j, basis):
        pairs[i] = j, basis
        used.add(j)

    if entry:
        pair(0, 0, "Routine entry")
    for old, new, basis in ((a.exact, b.exact, "Unique identical instruction bytes"),
                            (a.shapes, b.shapes, "Inferred · unique instruction shapes and exits")):
        left = _unique((key, i) for i, key in enumerate(old))
        right = _unique((key, j) for j, key in enumerate(new))
        for key, i in left.items():
            _check(cancel)
            j = right.get(key)
            if i is None or j is None or i in pairs or j in used:
                continue
            if old is a.exact or not any(edge.kind == "invalid" for edge in a.blocks[i].edges):
                pair(i, j, basis)

    # Follow at most four CFG hops. Conflicting anchors or repeated incoming arms
    # cannot select a counterpart. This also bounds work on long chains and cycles.
    for _ in range(4):
        old_votes, new_votes = [], []
        for i, (j, _) in pairs.items():
            _check(cancel)
            for arm, x in a.neighbors[i].items():
                y = b.neighbors[j].get(arm)
                if x is None or y is None or x in pairs or y in used:
                    continue
                if (a.shapes[x][1] == b.shapes[y][1] and
                        not any(edge.kind == "invalid" for edge in a.blocks[x].edges)):
                    old_votes.append((x, y))
                    new_votes.append((y, x))
        old, new = _unique(old_votes), _unique(new_votes)
        added = [(i, j) for i, j in old.items() if j is not None and new.get(j) == i]
        if not added:
            break
        for i, j in added:
            pair(i, j, "Inferred · corresponding CFG arm and exit kinds")
    return pairs


_LITERAL = re.compile(r"-?(?:[0-9][0-9a-f]{0,16}h|0x[0-9a-f]{1,16}|[0-9]{1,20})", re.I)


def _literal(operand):
    token = operand.strip().lower()
    if not _LITERAL.fullmatch(token):
        return None
    if token.endswith("h"):
        return int(token[:-1], 16)
    return int(token, 16 if token.lstrip("-").startswith("0x") else 10)


def _constants(left, right, aligned):
    # Report standalone numeric operands in unambiguous instruction pairs.
    # Bracketed displacements, register scales and control-flow destinations
    # are visible in the listing but do not establish a changed literal.
    old_counts = Counter(instruction_shape(left[r.left]) for r in aligned if r.left is not None)
    new_counts = Counter(instruction_shape(right[r.right]) for r in aligned if r.right is not None)
    changes = []
    for row in aligned:
        if row.status != "Changed" or row.left is None or row.right is None:
            continue
        a, b = left[row.left], right[row.right]
        shape = instruction_shape(a)
        if (a.flow not in ("next", "return") or b.flow != a.flow
                or instruction_shape(b) != shape or old_counts[shape] != 1 or new_counts[shape] != 1):
            continue
        for old, new in zip(a.args.split(","), b.args.split(",")):
            before, after = _literal(old), _literal(new)
            if before is not None and after is not None and before != after:
                changes.append(ImmediateChange(row.left, row.right, before, after))
    return tuple(changes)


def compare_blocks(left, right, cancel=None, *, candidate=False):
    _check(cancel)
    a = _Blocks(left, cancel)
    b = a if left is right else _Blocks(right, cancel)
    entry = all(side and side.rows and side.rows[0].rva == side.routine.rva for side in (left, right))
    if left is right:
        pairs = {i: (i, "Identical snapshot and block range") for i in range(len(a.blocks))}
    else:
        pairs = _matches(a, b, entry, cancel)
    seen = {j for j, _ in pairs.values()}
    records = [(i, *pairs.get(i, (None, "No unique counterpart"))) for i in range(len(a.blocks))]
    records.extend((None, j, "No unique counterpart") for j in range(len(b.blocks)) if j not in seen)
    scope = ["Function identity unverified"] if candidate else []
    for name, side in (("A", left), ("B", right)):
        if side and ("inferred" in side.routine.extent or "first 16 KiB" in side.routine.extent):
            scope.append(f"{name}: {side.routine.extent}")
    result = []
    for i, j, basis in records:
        _check(cancel)
        old = a.blocks[i] if i is not None else None
        new = b.blocks[j] if j is not None else None
        indices_a = range(old.first, old.stop) if old else range(0)
        indices_b = range(new.first, new.stop) if new else range(0)
        rows_a = a.rows[indices_a.start:indices_a.stop]
        rows_b = b.rows[indices_b.start:indices_b.stop]
        aligned = reindex(align_instructions(rows_a, rows_b, cancel, not (old and new)), indices_a, indices_b)
        if old and new:
            status = "Same bytes" if a.exact[i] == b.exact[j] else "Changed"
            exits = {edge.kind: edge.block for edge in new.edges}
            if any(e.block in pairs and e.kind in exits and exits[e.kind] is not None and
                   pairs[e.block][0] != exits[e.kind] for e in old.edges):
                status = "Changed"
                basis += " · different matched successor"
        else:
            status = "Baseline only" if old else "Comparison only"
        result.append(BlockChange(old, new, status, " · ".join((basis, *scope)), aligned,
                                  _constants(a.rows, b.rows, aligned) if old and new else ()))
    return tuple(result)


def align_block_code(left, right, block, cancel=None):
    """Only display lines Ghidra mapped to this block in their own build."""
    indices, texts = [], []
    for side, span in ((left, block.left), (right, block.right)):
        addresses = {r.rva for r in side.rows[span.first:span.stop]} if side and span else set()
        lines = side.code.lines if side and side.code else ()
        keep = [n for n, line in enumerate(lines) if not addresses.isdisjoint(line.rvas)]
        indices.append(keep)
        texts.append([lines[n].text for n in keep])
    return reindex(_align(*texts, cancel, unpaired=True), *indices)
