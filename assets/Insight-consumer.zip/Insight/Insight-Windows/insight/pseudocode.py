"""Native Ghidra listing and its exact line-to-instruction relation."""

from collections import defaultdict
import tkinter as tk
from tkinter import ttk

from .appearance import AMBER, CANVAS, INK, LINE, MONO, apply_theme, mono_font, scrollable


class GhidraPane(ttk.Frame):
    def __init__(self, parent, run, on_line, on_instruction):
        super().__init__(parent, padding=5)
        self.on_line, self.on_instruction = on_line, on_instruction
        self.on_global = self.on_local = self.on_function = None
        self.focused_global = self.focused_local = self.focused_function = None
        self.global_links = defaultdict(list)
        self.stack_links = defaultdict(list)
        self.function_links = defaultdict(list)
        self.result = None
        self.line = None
        self.view_target = None
        self.reveal_pending = None
        self.by_rva = {}
        self.reverse = defaultdict(list)
        self.mono = mono_font(self)
        self.bind("<<InsightFontsChanged>>", self._fonts_changed)
        apply_theme(self)

        header = ttk.Frame(self)
        header.pack(fill="x")
        self.run = ttk.Button(header, text="Decompile", command=run)
        self.run.pack(side="right", padx=(4,0))
        self.status = ttk.Label(header, wraplength=290)
        self.status.pack(side="left", fill="x", expand=True)
        header.bind("<Configure>", lambda e: self.status.configure(wraplength=max(80,e.width-90)))

        panes = tk.PanedWindow(self, orient="vertical", sashwidth=5, bg=LINE, borderwidth=0)
        panes.pack(fill="both", expand=True, pady=(4,0))
        top, bottom = ttk.Frame(panes), ttk.Frame(panes)
        panes.add(top, minsize=66, stretch="always")
        panes.add(bottom, minsize=68, stretch="never")
        self.code = tk.Text(top, font=MONO, bg=CANVAS, fg=INK,
                            wrap="none", relief="flat", width=16, height=8,
                            padx=6, pady=4, takefocus=True, state="disabled", borderwidth=0,
                            highlightthickness=1, highlightcolor=AMBER, highlightbackground=LINE)
        self.code.tag_configure("number", foreground="#a79ba2")
        self.code.tag_configure("linked", background="#16433e", foreground="#f3fffc")
        self.code.tag_configure("chosen", background="#59272f", foreground="#fff2f3")
        self.code.tag_configure("global", underline=True, foreground="#f9c25d")
        self.code.tag_configure("current_global", background="#66502c", foreground="#fff2d3")
        self.code.tag_configure("local", underline=True, foreground="#98d6cd")
        self.code.tag_configure("current_local", background="#26554e", foreground="#edfffa")
        self.code.tag_configure("function", underline=True, foreground=INK)
        self.code.tag_configure("current_function", background="#54323c", foreground="#fff2f3")
        for tag in ("global", "local", "function"):
            self.code.tag_bind(tag, "<Enter>", lambda _: self.code.configure(cursor="hand2"))
            self.code.tag_bind(tag, "<Leave>", lambda _: self.code.configure(cursor="xterm"))
        self.code.bind("<ButtonRelease-1>", self._click_line)
        self.code.bind("<Alt-g>", lambda _: self._next_symbol(self.global_links))
        self.code.bind("<Alt-l>", lambda _: self._next_symbol(self.stack_links))
        self.code.bind("<Alt-f>", lambda _: self._next_symbol(self.function_links))
        self.code.bind("<Return>", self._open_symbol)
        for event in ("<Map>", "<Configure>"):
            self.code.bind(event, self._layout_changed)
        for event in ("<MouseWheel>", "<Button-4>", "<Button-5>", "<Prior>", "<Next>", "<Home>", "<End>"):
            self.code.bind(event, self._free_scroll, add="+")
        for key, delta in (("Up",-1),("Down",1)):
            self.code.bind(f"<{key}>", lambda _e,d=delta:self._step_line(d))
        vertical = scrollable(top, self.code)
        vertical.configure(command=self._scroll)

        self.caption = ttk.Label(bottom, text="Mapped instructions", style="DockTitle.TLabel")
        self.caption.pack(fill="x")
        bottom.bind("<Configure>", lambda e:self.caption.configure(wraplength=max(75,e.width-8)))
        table = ttk.Frame(bottom)
        table.pack(fill="both", expand=True)
        self.evidence = ttk.Treeview(table, columns=("rva","bytes","instruction"), show="headings",
                                     style="Insight.Treeview", selectmode="browse", height=3)
        for key,title,width in (("rva","RVA",90),("bytes","Exact bytes",160),("instruction","Instruction",250)):
            self.evidence.heading(key,text=title,anchor="w")
            self.evidence.column(key,width=width,minwidth=55,stretch=(key=="instruction"))
        scrollable(table, self.evidence)
        self.evidence.bind("<ButtonRelease-1>",lambda e:self._follow(self.evidence.identify_row(e.y)))
        self.evidence.bind("<Return>",lambda _e:self._follow(self.evidence.focus()))

    def reset(self, message, busy=False):
        self._free_scroll()
        self.result, self.line = None, None
        self.focused_global = self.focused_local = self.focused_function = None
        self.global_links.clear()
        self.stack_links.clear()
        self.function_links.clear()
        self.by_rva.clear()
        self.reverse.clear()
        self.code.configure(state="normal")
        self.code.delete("1.0","end")
        self.code.configure(state="disabled")
        self.evidence.delete(*self.evidence.get_children())
        self.status.configure(text=message)
        self.caption.configure(text="Mapped instructions")
        self.run.configure(text="Cancel" if busy else "Decompile")
        self.run.pack(side="right",padx=(4,0))

    def populate(self, result, rows):
        focus = self.focus_snapshot() if self.result is result else None
        self.reset("Ghidra " + result.version)
        self.run.pack_forget()
        self.result = result
        self.by_rva = {row.rva:row for row in rows}
        self.code.configure(state="normal")
        width = len(str(len(result.lines)))
        overlays = self.symbol_overlays(result) if getattr(self, "symbol_overlays", None) else {}
        for i,line in enumerate(result.lines):
            self.code.insert("end",f"{i+1:>{width}}  ","number")
            tokens = [(t, "global", self.global_links) for t in getattr(line, "globals", ())]
            tokens.extend((t, "local", self.stack_links) for t in getattr(line, "stack", ()))
            tokens.extend((t, "function", self.function_links) for t in getattr(line, "functions", ()))
            column = 0
            for token, tag, links in sorted(tokens, key=lambda item: item[0].start):
                if token.start < column:
                    continue
                self.code.insert("end", line.text[column:token.start])
                start = self.code.index("end-1c")
                metadata = overlays.get(token)
                name = metadata.name if metadata else ""
                self.code.insert("end", name or line.text[token.start:token.end], tag)
                end = self.code.index("end-1c")
                links[i+1].append((start, end, token))
                if metadata and metadata.type_name:
                    self.code.insert("end", f" /* analyst: {metadata.type_name} */", "number")
                column = token.end
            self.code.insert("end", line.text[column:] + ("\n" if i+1<len(result.lines) else ""))
            for rva in line.rvas:
                self.reverse[rva].append(i)
        self.code.configure(state="disabled")
        signals = [f"Ghidra {result.version}"]
        if overlays:
            signals.append("Analyst symbol overlays")
        if self.function_links:
            signals.append("Alt+F selects a function")
        elif self.global_links or self.stack_links:
            signals.append("Click an underlined variable to inspect it")
        self.status.configure(text=" · ".join(signals))
        self.restore_focus(focus)

    def focus_snapshot(self):
        """Return the source line and original token independently of projected text columns."""
        for index, links in ((self.focused_global, self.global_links), (self.focused_local, self.stack_links),
                             (self.focused_function, self.function_links)):
            if index and (span := self._link_at(index, links)):
                return int(index.split(".")[0])-1, span[2]
        return None

    def restore_focus(self, snapshot):
        if snapshot is not None and self.result is not None:
            line_index, token = snapshot
            for links in (self.global_links, self.stack_links, self.function_links):
                for start, _, candidate in links.get(line_index+1, ()):
                    if candidate == token:
                        self._focus_symbol(start, links)
                        return True
        return False

    def selected_symbol(self):
        if focus := self.focus_snapshot():
            index, token = focus
            return token, self.result.lines[index].text[token.start:token.end]

    def _link_at(self, index, links):
        line = int(index.split(".")[0])
        for start, end, token in links.get(line, ()):
            if self.code.compare(start, "<=", index) and self.code.compare(index, "<", end):
                return start, end, token

    def focus_global(self, index):
        self._focus_symbol(index, self.global_links)

    def focus_local(self, index):
        self._focus_symbol(index, self.stack_links)

    def _focus_symbol(self, index, links):
        for tag in ("current_global", "current_local", "current_function"):
            self.code.tag_remove(tag, "1.0", "end")
        self.focused_global = self.focused_local = self.focused_function = None
        link = self._link_at(index, links) if index else None
        if link:
            start, end, _ = link
            if links is self.global_links:
                self.focused_global = start
                self.code.tag_add("current_global", start, end)
            elif links is self.stack_links:
                self.focused_local = start
                self.code.tag_add("current_local", start, end)
            else:
                self.focused_function = start
                self.code.tag_add("current_function", start, end)
            self.code.mark_set("insert", start)
            self._reveal(start)

    def _free_scroll(self, _event=None):
        self.view_target = None
        if self.reveal_pending:
            self.after_cancel(self.reveal_pending)
            self.reveal_pending = None

    def _scroll(self, *args):
        self._free_scroll()
        self.code.yview(*args)

    def _reveal(self, index):
        self.view_target = index
        self.code.see(index)
        self._layout_changed()

    def _layout_changed(self, _event=None):
        if self.view_target and self.reveal_pending is None:
            self.reveal_pending = self.after_idle(self._settle_line)

    def _settle_line(self):
        self.reveal_pending = None
        if self.view_target and self.code.winfo_ismapped() and not self.code.bbox(self.view_target):
            self.code.see(self.view_target)

    def restore_scroll(self, fraction):
        self._free_scroll()
        self.code.yview_moveto(fraction)

    def _next_symbol(self, links):
        if links:
            current = self.focused_global or self.focused_local or self.focused_function or self.code.index("insert")
            starts = [start for spans in links.values() for start, _, _ in spans]
            next_index = next((i for i in starts if self.code.compare(i, ">", current)), starts[0])
            self._focus_symbol(next_index, links)
        return "break"

    def _open_symbol(self, _event=None):
        for index, links, action in ((self.focused_global, self.global_links, self.on_global),
                                     (self.focused_local, self.stack_links, self.on_local),
                                     (self.focused_function, self.function_links, self.on_function)):
            if not index or not action:
                continue
            start, _, token = self._link_at(index, links)
            self.choose_line(int(start.split(".")[0]) - 1, follow=False)
            self._focus_symbol(start, links)
            if links is self.function_links:
                action(token.rva)
            else:
                action(token.rva if links is self.global_links else token.offset, token.size)
            break
        return "break"

    def _highlight(self, tag, indices):
        self.code.tag_remove(tag,"1.0","end")
        for i in indices:
            self.code.tag_add(tag,f"{i+1}.0",f"{i+1}.end+1c")

    def _click_line(self, event):
        if self.result and not self.code.tag_ranges("sel"):
            index = self.code.index(f"@{event.x},{event.y}")
            self.code.focus_set()
            # Text maps clicks past the margin onto the last character of a line.
            box = self.code.bbox(index)
            if box and box[0] <= event.x < box[0] + box[2]:
                if self._link_at(index, self.function_links):
                    self.choose_line(int(index.split(".")[0])-1)
                    self._focus_symbol(index, self.function_links)
                    return "break"
                for links, action in ((self.global_links, self.on_global), (self.stack_links, self.on_local)):
                    if action and self._link_at(index, links):
                        self._focus_symbol(index, links)
                        return self._open_symbol()
            self.choose_line(int(index.split(".")[0])-1)

    def _step_line(self, delta):
        if self.result and self.result.lines:
            first = self.line if self.line is not None else int(self.code.index("insert").split(".")[0])-1
            self.choose_line(max(0,min(len(self.result.lines)-1,first+delta)))
        return "break"

    def choose_line(self, index, *, follow=True):
        if not self.result or not 0 <= index < len(self.result.lines):
            return
        self.focus_global(None)
        line = self.result.lines[index]
        self.line = index
        self._highlight("linked",())
        self._highlight("chosen",(index,))
        self.code.mark_set("insert",f"{index+1}.0")
        self._reveal(f"{index+1}.0")
        n = len(line.rvas)
        text = f"Line {index+1} · " + (f"{n} mapped instruction" + ("" if n==1 else "s")
                                        if n else "No verified instruction mapping")
        self.caption.configure(text=text)
        self._evidence(line.rvas,line.unmatched)
        self.on_line(line.rvas, follow)

    def cursor(self, rva):
        """Reverse lookup never manufactures a counterpart for an unmapped instruction."""
        if not self.result:
            return
        self.focus_global(None)
        self.line = None
        lines = self.reverse.get(rva,())
        self._highlight("chosen",())
        self._highlight("linked",lines)
        if lines:
            self.code.mark_set("insert",f"{lines[0]+1}.0")
            self._reveal(f"{lines[0]+1}.0")
        else:
            self._free_scroll()
        where = ", ".join(str(i+1) for i in lines[:8])
        if len(lines)>8:
            where += f" … ({len(lines)} lines)"
        self.caption.configure(text=f"RVA 0x{rva:08X} · " +
                               ("Ghidra line" + ("s " if len(lines)>1 else " ") + where
                                if lines else "No mapped pseudocode line"))
        self._evidence((rva,),())

    def _evidence(self, rvas, unmatched):
        self.evidence.delete(*self.evidence.get_children())
        byte_width, instruction_width = 80, 100
        for rva in rvas:
            row = self.by_rva[rva]
            raw = row.raw.hex(" ").upper()
            assembly = f"{row.op} {row.args}".rstrip()
            self.evidence.insert("","end",iid=str(rva),values=(
                f"0x{rva:08X}",raw,assembly))
            byte_width = max(byte_width,self.mono.measure(raw)+12)
            instruction_width = max(instruction_width,self.mono.measure(assembly)+12)
        for rva in unmatched:
            self.evidence.insert("","end",values=(f"0x{rva:08X}","—","Outside verified listing"))
        if unmatched:
            instruction_width = max(instruction_width,self.mono.measure("Outside verified listing")+12)
        self.evidence.column("bytes",width=byte_width)
        self.evidence.column("instruction",minwidth=instruction_width,width=instruction_width)

    def _fonts_changed(self, _event):
        for col in ("rva", "bytes", "instruction"):
            items = self.evidence.get_children()
            width = max((self.mono.measure(self.evidence.set(i, col))+12 for i in items), default=80)
            self.evidence.column(col, width=width, minwidth=width)

    def _follow(self, item):
        if item and item.isdecimal():
            self.on_instruction(int(item))
        return "break"
