"""Index file-backed AMD64 PE code and disassemble one limited RVA range as data."""

from bisect import bisect_right
from dataclasses import dataclass
from functools import lru_cache
import os
from pathlib import Path
import re
import struct
import subprocess
import tempfile
from time import monotonic


MAX_FILE_SIZE = 64 * 1024 * 1024
MAX_ROUTINE_BYTES = 16 * 1024
MAX_DECODER_OUTPUT = 4 * 1024 * 1024
DECODER_SECONDS = 4
MAX_ENTRIES = 65_536
EXECUTE = 0x20000000


@dataclass(frozen=True)
class Section:
    rva: int
    size: int
    offset: int
    backed: int
    executable: bool


@dataclass(frozen=True)
class Routine:
    rva: int
    end: int
    name: str
    extent: str


@dataclass(frozen=True)
class Instruction:
    rva: int
    raw: bytes
    op: str
    args: str
    target: int | None
    flow: str


def unpack(data, offset, fmt):
    if offset < 0 or offset + struct.calcsize(fmt) > len(data):
        raise ValueError("Truncated PE header or table.")
    return struct.unpack_from(fmt, data, offset)


class Image:
    def __init__(self, data, sections, header_size, entry):
        self.data = data
        self.sections = sorted(sections, key=lambda section: section.rva)
        self.starts = [section.rva for section in self.sections]
        self.header_size = header_size
        self.entry = entry
        self.routines = []
        self.export_names = {}
        self.range_ends = {}

    def section_at(self, rva):
        i = bisect_right(self.starts, rva) - 1
        if i >= 0:
            section = self.sections[i]
            if rva < section.rva + section.backed:
                return section
        return None

    def offset(self, rva, size):
        if 0 <= rva < self.header_size and rva + size <= self.header_size:
            return rva
        section = self.section_at(rva)
        if section is None or rva + size > section.rva + section.backed:
            raise ValueError("PE table or code range extends beyond the file-backed section.")
        return section.offset + rva - section.rva

    def instructions(self, routine, cancel=None):
        length = routine.end - routine.rva
        section = self.section_at(routine.rva)
        if not section or not section.executable or not 0 < length <= MAX_ROUTINE_BYTES:
            raise ValueError("Select a bounded executable range.")
        start = self.offset(routine.rva, length)
        return disassemble(self.data[start:start + length], routine.rva, cancel)


def read_exports(image, rva, size):
    exports = {}
    if not rva:
        return exports
    at = image.offset(rva, size)
    if size < 40:
        raise ValueError("Truncated export directory.")
    base, count, named, eat, names, ordinals = unpack(image.data, at + 16, "<6I")
    if max(count, named) > MAX_ENTRIES:
        raise ValueError("Export table exceeds the supported entry limit.")
    if not count:
        if named:
            raise ValueError("Export names without address entries.")
        return exports
    if not eat or (named and (not names or not ordinals)):
        raise ValueError("Missing export table.")
    addrs = image.offset(eat, count * 4)
    aliases = {}
    if named:
        name_table = image.offset(names, named * 4)
        ordinal_table = image.offset(ordinals, named * 2)
        for i in range(named):
            index, = unpack(image.data, ordinal_table + i * 2, "<H")
            if index >= count:
                raise ValueError("Export ordinal is outside its address table.")
            ptr, = unpack(image.data, name_table + i * 4, "<I")
            if not ptr:
                raise ValueError("Missing export name address.")
            start = image.offset(ptr, 1)
            section = image.section_at(ptr)
            end = section.offset + section.backed if section else image.header_size
            name, terminator, _ = image.data[start:min(end, start + 257)].partition(b"\0")
            # Names are untrusted labels. Keep controls and long mangled names out of widgets.
            if name and all(32 <= b < 127 for b in name):
                label = name[:256].decode("ascii") + ("" if terminator else "…")
                aliases.setdefault(index, []).append(label)
    for index in range(count):
        target, = unpack(image.data, addrs + index * 4, "<I")
        section = image.section_at(target)
        if section and section.executable and not rva <= target < rva + size:
            labels = aliases.get(index, ())
            exports.setdefault(target, labels[0] if labels else f"ordinal_{base + index}")
            # A truncated display label cannot identify a function across builds.
            image.export_names.setdefault(target, set()).update(name for name in labels if name.isascii())
    return exports


def inspect_image(data: bytes) -> Image:
    if len(data) > MAX_FILE_SIZE:
        raise ValueError("DLL exceeds the 64 MiB read limit.")
    if data[:2] != b"MZ":
        raise ValueError("Expected a Windows PE DLL.")
    pe, = unpack(data, 0x3c, "<I")
    if pe < 64 or data[pe:pe + 4] != b"PE\0\0":
        raise ValueError("Invalid PE signature.")
    machine, count, _, _, _, optional_size, flags = unpack(data, pe + 4, "<HHIIIHH")
    opt = pe + 24
    magic, = unpack(data, opt, "<H")
    if machine != 0x8664 or magic != 0x20b or not flags & 0x2000:
        raise ValueError("Open a native x64 (AMD64 PE32+) DLL.")
    if not 1 <= count <= 96 or optional_size < 112:
        raise ValueError("Invalid PE section count or optional header.")
    entry, = unpack(data, opt + 16, "<I")
    image_size, header_size = unpack(data, opt + 56, "<II")
    directories, = unpack(data, opt + 108, "<I")
    table = opt + optional_size
    if not table + count * 40 <= header_size <= min(len(data), image_size):
        raise ValueError("Invalid PE header extent.")
    if 112 + directories * 8 > optional_size:
        raise ValueError("Truncated data directory table.")

    def directory(index):
        if index >= directories:
            return 0, 0
        rva, size = unpack(data, opt + 112 + index * 8, "<II")
        if bool(rva) != bool(size):
            raise ValueError("Invalid data directory extent.")
        return rva, size

    if directory(14) != (0, 0):
        raise ValueError("Managed or mixed-mode DLLs are outside the native x64 view.")
    sections = []
    file_ranges = []
    for i in range(count):
        at = table + i * 40
        size, rva, raw_size, raw = unpack(data, at + 8, "<4I")
        attrs, = unpack(data, at + 36, "<I")
        size = size or raw_size
        if size and (rva < header_size or rva + size > image_size):
            raise ValueError("Invalid virtual section range.")
        if raw_size:
            if raw < header_size or raw + raw_size > len(data):
                raise ValueError("Invalid section file range.")
            file_ranges.append((raw, raw + raw_size))
        if size:
            sections.append(Section(rva, size, raw, min(size, raw_size), bool(attrs & EXECUTE)))
    for ranges in (sorted(file_ranges), sorted((s.rva, s.rva + s.size) for s in sections)):
        if any(end > start for (_, end), (start, _) in zip(ranges, ranges[1:])):
            raise ValueError("Overlapping PE sections are ambiguous.")
    image = Image(data, sections, header_size, entry)
    image.base, = unpack(data, opt + 24, "<Q")
    # Import and delay-import tables are validated on demand for the XREF matrix.
    image.imports = tuple(unpack(data, opt + 112 + index * 8, "<II")
                          if index < directories else (0, 0) for index in (1, 13))
    names = read_exports(image, *directory(0))
    ends = {}
    unwind, size = directory(3)
    if unwind:
        if size % 12 or size // 12 > MAX_ENTRIES:
            raise ValueError("Unsupported size of x64 exception directory.")
        table = image.offset(unwind, size)
        for at in range(table, table + size, 12):
            begin, end, info = unpack(data, at, "<III")
            if (begin, end, info) == (0, 0, 0):
                continue
            section = image.section_at(begin)
            if not section or not section.executable or not begin < end <= section.rva + section.backed:
                raise ValueError("Invalid file-backed x64 runtime function range.")
            if begin in ends and ends[begin] != end:
                raise ValueError("Conflicting runtime function boundaries.")
            ends[begin] = end
    if entry:
        section = image.section_at(entry)
        if not section or not section.executable:
            raise ValueError("The DLL entry point has no file-backed executable code.")
        names.setdefault(entry, "Entry point")
    starts = sorted(ends.keys() | names.keys())
    image.function_entries = frozenset(starts)
    if len(starts) > MAX_ENTRIES:
        raise ValueError("Routine index exceeds the supported entry limit.")
    if not starts:
        starts = [s.rva for s in image.sections if s.executable and s.backed]
        names.update((rva, f"Executable section {rva:08X}") for rva in starts)
    if not starts:
        raise ValueError("This DLL contains no file-backed executable code.")
    for i, begin in enumerate(starts):
        section = image.section_at(begin)
        end = ends.get(begin)
        extent = "x64 unwind table"
        if end is None:
            end = section.rva + section.backed
            if i + 1 < len(starts):
                end = min(end, starts[i + 1])
            extent = "inferred range to next known start or section end"
        image.range_ends[begin] = end
        if end - begin > MAX_ROUTINE_BYTES:
            end = begin + MAX_ROUTINE_BYTES
            extent += " · first 16 KiB shown"
        image.routines.append(Routine(begin, end, names.get(begin, f"sub_{begin:08X}"), extent))
    return image


@lru_cache(maxsize=1)
def decoder_path():
    # Only search tools in the system installation directories. The input directory,
    # caller's current directory and PATH must never choose a decoder.
    import winreg
    with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Microsoft\Windows\CurrentVersion",
                        0, winreg.KEY_READ | winreg.KEY_WOW64_64KEY) as key:
        roots = [winreg.QueryValueEx(key, value)[0] for value in ("ProgramFilesDir", "ProgramFilesDir (x86)")]
    for root in roots:
        tools = (Path(root) / "Microsoft Visual Studio").glob("*/*/VC/Tools/MSVC/*/bin/Hostx64/x64/link.exe")
        for tool in sorted(tools, reverse=True):
            if tool.is_file():
                return tool
    raise ValueError("The Microsoft Visual C++ x64 build tools are required to decode DLL instructions.")


def disassemble(code, rva, cancel=None):
    if cancel is not None and cancel.is_set():
        raise ValueError("Instruction decoding cancelled.")
    if not code or len(code) > MAX_ROUTINE_BYTES:
        raise ValueError("Instruction range exceeds the decoder limit.")
    tool = decoder_path()
    # Preserve the RVA so relative branches and RIP-relative memory operands resolve
    # in module coordinates. Never expose user-controlled headers or PDB paths to MSVC.
    header = struct.pack("<HHIIIHH", 0x8664, 1, 0, 0, 0, 0, 0)
    section = struct.pack("<8sIIIIIIHHI", b".text", 0, rva, len(code), 60, 0, 0, 0, 0, 0x60500020)
    with tempfile.TemporaryDirectory(prefix="insight-code-") as directory:
        obj = Path(directory) / "code.obj"
        obj.write_bytes(header + section + code)
        system = os.environ["SystemRoot"]
        env = {"SystemRoot": system, "PATH": str(Path(system) / "System32"), "VSLANG": "1033"}
        with tempfile.TemporaryFile(dir=directory) as output:
            command = [str(tool), "/dump", "/nologo", "/disasm:bytes", str(obj)]
            with subprocess.Popen(command, cwd=tool.parent, env=env, stdin=subprocess.DEVNULL,
                                  stdout=output, stderr=subprocess.DEVNULL,
                                  creationflags=subprocess.CREATE_NO_WINDOW) as child:
                deadline = monotonic() + DECODER_SECONDS
                try:
                    while child.poll() is None:
                        if cancel is not None and cancel.is_set():
                            raise ValueError("Instruction decoding cancelled.")
                        if os.fstat(output.fileno()).st_size > MAX_DECODER_OUTPUT:
                            raise ValueError("The decoder exceeded its output limit.")
                        remaining = deadline - monotonic()
                        if remaining <= 0:
                            raise ValueError("The instruction decoder exceeded its four-second limit.")
                        try:
                            child.wait(timeout=min(.05, remaining))
                        except subprocess.TimeoutExpired:
                            pass
                finally:
                    if child.poll() is None:
                        child.kill()
                    child.wait()
            if cancel is not None and cancel.is_set():
                raise ValueError("Instruction decoding cancelled.")
            if child.returncode or os.fstat(output.fileno()).st_size > MAX_DECODER_OUTPUT:
                raise ValueError("The instruction decoder rejected this byte range.")
            output.seek(0)
            return parse_listing(output.read().decode("ascii", errors="replace"), code, rva)


def flow_for(op, args):
    # MSVC prints legacy control-flow prefixes as the first word (e.g. BND JMP).
    if op in ("bnd", "rep", "repe", "repne", "notrack") and args:
        mnemonic = args.split(maxsplit=1)
        op = mnemonic[0]
        args = mnemonic[1] if len(mnemonic) > 1 else ""
    if op == "call":
        flow = "call"
    elif op == "jmp":
        flow = "jump"
    elif op.startswith(("j", "loop")) or op == "xbegin":
        flow = "conditional"
    elif op.startswith(("ret", "iret", "sysret", "sysexit")):
        return "return", None
    elif op in ("syscall", "sysenter"):
        return "call", None
    elif op in ("(undecoded)", "???", "db"):
        return "invalid", None
    elif op in ("int", "int3", "ud2", "hlt", "xabort"):
        return "stop", None
    else:
        return "next", None
    if re.fullmatch("[0-9A-Fa-f]{16}", args):
        target = int(args, 16)
        return flow, target if target <= 0xffffffff else None
    return ("indirect" if flow == "jump" else flow), None


def parse_listing(listing, code, rva):
    rows = []
    instruction = re.compile(r"^\s*([0-9A-Fa-f]{16}): (.*)$")
    continuation = re.compile(r"^\s{20,}((?:[0-9A-F]{2} ?)+)$")
    for line in listing.splitlines():
        match = instruction.match(line)
        if match:
            address, text = match.groups()
            parts = re.split(r" {2,}", text.strip(), maxsplit=1)
            raw = bytes.fromhex(parts[0])
            mnemonic = parts[1].split(maxsplit=1) if len(parts) == 2 else ["(undecoded)"]
            op = mnemonic[0].lower()
            args = mnemonic[1] if len(mnemonic) > 1 else ""
            flow, target = flow_for(op, args)
            rows.append(Instruction(int(address, 16), raw, op, args, target, flow))
        elif rows and (match := continuation.match(line)):
            row = rows[-1]
            rows[-1] = Instruction(row.rva, row.raw + bytes.fromhex(match[1]), row.op,
                                    row.args, row.target, row.flow)
    cursor = 0
    for row in rows:
        if row.rva != rva + cursor or not 1 <= len(row.raw) <= 15 or not code.startswith(row.raw, cursor):
            raise ValueError("Disassembly addresses or bytes disagree with the snapshot.")
        cursor += len(row.raw)
    if cursor != len(code):
        raise ValueError("The decoder did not account for every byte in the selected range.")
    return rows
