"""A finite read-only query language over frozen evidence. No general-purpose evaluator."""

from bisect import bisect_left
from dataclasses import dataclass
from hashlib import sha256
import re
from time import monotonic

from .pe import MAX_ROUTINE_BYTES
from .records import read_local


MAX_SOURCE = 8192
MAX_COMMANDS = 64
MAX_OUTPUT = 32768
MAX_RESULTS = 128
SECONDS = 2
SIGNATURES = {"info": "info()", "read": "read(cursor, 16)", "instructions": "instructions(cursor, 8)",
              "calls": "calls()", "find_bytes": 'find_bytes("FF 15")', "pseudocode": "pseudocode(cursor)"}
_CALL = re.compile(r"([a-z_]{1,16})\s*\(([^()]*)\)")
_NUMBER = re.compile(r"0x[0-9A-Fa-f]{1,8}|[0-9]{1,10}")
_PATTERN = re.compile(r'"([0-9A-Fa-f]{2}(?: [0-9A-Fa-f]{2}){0,31})"')


def validate_source(text):
    if (not isinstance(text,str) or not 0 < len(text) <= MAX_SOURCE or not text.isascii()
            or any(ord(c)<32 and c not in "\t\n\r" or ord(c)==127 for c in text)):
        raise ValueError("Use 1–8192 bytes of printable ASCII script text, tabs and newlines.")
    return text


def read_source(path):
    """Only an explicit editor Open reads a local regular file, to a bounded source copy."""
    return validate_source(read_local(path, MAX_SOURCE).decode("ascii"))


def review(text):
    commands = []
    for line_no, line in enumerate(validate_source(text).splitlines(),1):
        code = line.partition("#")[0].strip()
        if not code:
            continue
        match = _CALL.fullmatch(code)
        if not match or match[1] not in SIGNATURES:
            raise ValueError(f"Line {line_no}: enter one supported evidence call per line.")
        name, body = match[1], match[2].strip()
        args = []
        if name == "find_bytes":
            pattern = _PATTERN.fullmatch(body)
            if not pattern:
                raise ValueError(f'Line {line_no}: use 1–32 quoted hex bytes, such as "FF 15".')
            args.append(bytes.fromhex(pattern[1]))
        else:
            for value in body.split(",") if body else ():
                token = value.strip()
                if token == "cursor":
                    args.append(token)
                elif _NUMBER.fullmatch(token):
                    number = int(token,16 if token.startswith("0x") else 10)
                    if number > 0xFFFFFFFF:
                        raise ValueError(f"Line {line_no}: address exceeds 32-bit RVA limits.")
                    args.append(number)
                else:
                    raise ValueError(f"Line {line_no}: use an unsigned address, count or cursor.")
            arity = {"info":0, "calls":0, "pseudocode":1, "read":2, "instructions":2}[name]
            if len(args) != arity:
                raise ValueError(f"Line {line_no}: expected {SIGNATURES[name]}.")
            if arity == 2:
                limit = 256 if name=="read" else MAX_RESULTS
                if type(args[1]) is not int or not 1 <= args[1] <= limit:
                    raise ValueError(f"Line {line_no}: count must be from 1 to {limit}.")
        commands.append((line_no,name,tuple(args)))
        if len(commands)>MAX_COMMANDS:
            raise ValueError("A script supports at most 64 calls.")
    if not commands:
        raise ValueError("Enter a read-only evidence call before reviewing.")
    return tuple(commands)


@dataclass(frozen=True)
class Snapshot:
    digest: str
    label: str
    routine: str
    cursor: int
    rows: tuple
    image: object
    decompiled: object

    @classmethod
    def capture(cls, app):
        if not app.case or not app.rows:
            raise ValueError("Open an investigation and select an instruction first.")
        case, (key,row) = app.case, app.citation()
        if len(app.rows) > MAX_ROUTINE_BYTES:
            raise ValueError("The selected routine exceeds the query limit.")
        result = app.views.pseudo.result
        verified = app.decompiled.get((case.digest, app.routine.rva, app.routine.end))
        return cls(case.digest, case.label, key, row.rva, tuple(app.rows), case.image,
                   result if result is verified else None)

    @property
    def scope(self):
        return self.digest, self.routine, self.cursor


def execute(text, snapshot, cancel, clock=monotonic):
    """The only inputs visible to commands are validated scalars and evidence values."""
    commands = review(text)
    deadline = clock()+SECONDS
    output, length = [], 0
    rows = snapshot.rows
    if not rows or len(rows)>MAX_ROUTINE_BYTES:
        raise ValueError("No bounded instruction listing is available.")
    label = "RVA" if snapshot.image is not None else "Offset"

    def check():
        if cancel.is_set():
            raise ValueError("Script cancelled.")
        if clock() >= deadline:
            raise ValueError("Script exceeded its two-second execution limit.")

    def emit(value):
        nonlocal length
        check()
        # Convert untrusted control characters from target-derived display text to spaces.
        value = "".join(c if c.isprintable() else " " for c in value)
        length += len(value.encode("utf-8"))+1
        if length > MAX_OUTPUT:
            raise ValueError("Script output exceeded 32 KiB. Narrow the request.")
        output.append(value)

    def assembly(row):
        emit(f"{label} 0x{row.rva:X}  {row.raw.hex(' ').upper()}  {row.op[:20]} {row.args[:256]}")

    def index(at):
        return bisect_left(rows,at,key=lambda r:r.rva)

    for line, name, args in commands:
        check()
        a = [snapshot.cursor if value=="cursor" else value for value in args]
        emit(f"[{line}] {name}")
        if name == "info":
            emit(f"{snapshot.label[:160]}  SHA-256 {snapshot.digest}")
            emit(f"Routine {snapshot.routine[:160]}  {label} 0x{snapshot.cursor:X}  {len(rows)} decoded rows")
        elif name == "read":
            at, count = a
            if snapshot.image is not None:
                offset = snapshot.image.offset(at,count)
                raw = snapshot.image.data[offset:offset+count]
            else:
                start = max(0,index(at)-1)
                raw = bytearray()
                for row in rows[start:start+count+1]:
                    here = at+len(raw)
                    if row.rva>here or len(raw)==count:
                        break
                    if row.rva <= here < row.rva+len(row.raw):
                        raw.extend(row.raw[here-row.rva:here-row.rva+count-len(raw)])
            if len(raw)!=count:
                raise ValueError(f"Line {line}: requested bytes are outside the backed evidence.")
            emit(f"{label} 0x{at:X}  {raw.hex(' ').upper()}")
        elif name == "instructions":
            i = index(a[0])
            if i==len(rows) or rows[i].rva!=a[0]:
                raise ValueError(f"Line {line}: address is not an instruction start in this routine.")
            for row in rows[i:i+a[1]]:
                assembly(row)
        elif name == "pseudocode":
            result = snapshot.decompiled
            if result is None:
                emit("No Ghidra decompilation was available when reviewed.")
                continue
            found = 0
            for i, source in enumerate(result.lines):
                check()
                if a[0] in source.rvas:
                    if found==MAX_RESULTS:
                        emit("Showing the first 128 mapped lines.")
                        break
                    emit(f"Ghidra {result.version} · line {i+1}  {source.text[:512]}")
                    found += 1
            if not found:
                emit("No verified Ghidra line maps to this address.")
        elif name == "calls":
            found = 0
            for row in rows:
                check()
                if row.flow=="call":
                    if found==MAX_RESULTS:
                        emit("Showing the first 128 call sites.")
                        break
                    assembly(row)
                    found += 1
            if not found:
                emit("No decoded call sites in this routine.")
        elif name == "find_bytes":
            pattern, = a
            # Instructions can join within a backed run. A gap resets the match.
            tail, end, found = b"", None, 0
            for row in rows:
                check()
                if row.rva != end:
                    tail = b""
                piece = tail+row.raw
                pos = piece.find(pattern)
                while pos >= 0:
                    if found==MAX_RESULTS:
                        break
                    emit(f"{label} 0x{row.rva-len(tail)+pos:X}  {pattern.hex(' ').upper()}")
                    found += 1
                    pos = piece.find(pattern,pos+1)
                if found==MAX_RESULTS:
                    emit("Stopped at 128 matches.")
                    break
                tail = piece[-(len(pattern)-1):] if len(pattern)>1 else b""
                end = row.rva+len(row.raw)
            if not found:
                emit("No matches in this decoded routine.")
    check()
    return "\n".join(output)


class Favorites:
    """Store source content locally. A favorite is independent of its original filename."""
    def __init__(self, casebook):
        self.db = casebook.db
        self.db.execute("""CREATE TABLE IF NOT EXISTS script_favorites
            (digest TEXT PRIMARY KEY, label TEXT NOT NULL, source BLOB NOT NULL)""")

    def entries(self):
        rows = self.db.execute("""SELECT substr(digest,1,65), substr(label,1,49)
            FROM script_favorites ORDER BY rowid DESC LIMIT 17""").fetchall()
        if len(rows)>16 or any(not isinstance(d,str) or not re.fullmatch("[0-9a-f]{64}", d) or not isinstance(n,str)
                               or not 0<len(n)<=48 or not n.isprintable() for d,n in rows):
            raise ValueError("Invalid saved script favorites.")
        return [(d,n) for d,n in rows]

    def save(self, label, text):
        source = validate_source(text).encode("ascii")
        if not isinstance(label,str) or not 0<len(label)<=48 or not label.isprintable():
            raise ValueError("Use a favorite name of 1–48 visible characters.")
        digest = sha256(source).hexdigest()
        with self.db:
            self.db.execute("BEGIN IMMEDIATE")
            current = self.entries()
            if len(current)==16 and digest not in dict(current):
                raise ValueError("Remove a favorite before saving another (limit 16).")
            self.db.execute("""INSERT INTO script_favorites VALUES(?,?,?)
                ON CONFLICT(digest) DO UPDATE SET label=excluded.label""", (digest,label,source))
        return digest

    def load(self, digest):
        row = self.db.execute("""SELECT CASE WHEN typeof(source)='blob' AND length(source) BETWEEN 1 AND 8192
            THEN source END FROM script_favorites WHERE digest=?""",(digest,)).fetchone()
        if not row or not row[0] or sha256(row[0]).hexdigest()!=digest:
            raise ValueError("The saved script content does not match its fingerprint.")
        return validate_source(row[0].decode("ascii"))

    def remove(self, digest):
        with self.db:
            self.db.execute("DELETE FROM script_favorites WHERE digest=?",(digest,))
