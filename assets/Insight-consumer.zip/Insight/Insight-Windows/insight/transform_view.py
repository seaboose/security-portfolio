"""Nonmodal, snapshot-scoped byte transforms with paged evidence and derived offsets."""

import re
import tkinter as tk
from tkinter import ttk

from .appearance import AMBER, INK, MONO, MUTED, RIM, SELECTION, SURFACE, WELL, apply_theme, scrollable
from .byte_transforms import MAX_INPUT, MAX_KEY, OPERATIONS, read_range, transform
from .workspace_settings import capture_geometry, restore_geometry


PAGE = 256


def _rows(data, start, page, prefix=""):
    lines = []
    for index in range(page*PAGE, min((page+1)*PAGE,len(data)), 8):
        chunk = data[index:index+8]
        ascii_text = "".join(chr(n) if 32 <= n < 127 else "." for n in chunk)
        lines.append(f"{prefix}{start+index:08X}  {chunk.hex(' ').upper():23}  {ascii_text}")
    return "\n".join(lines)


def open_transforms(app, address=None, size=None, *, operation=None):
    if app.case is None or not app.rows:
        app.status.set("Select an instruction to preview its bytes.")
        return None
    case, rows = app.case, tuple(app.rows)
    key, instruction = app.citation()
    try:
        if operation is not None and operation not in OPERATIONS:
            raise ValueError("Choose a supported byte operation.")
        current = read_range(case,key,rows,instruction.rva,len(instruction.raw))
        if current.data != instruction.raw:
            raise ValueError("The selected instruction does not match the immutable snapshot.")
        initial = current if address is None and size is None else read_range(case,key,rows,address,size)
    except ValueError as error:
        app.status.set(str(error))
        return None
    window = getattr(app,"transform_window",None)
    if window is None or not window.winfo_exists():
        window = app.transform_window = TransformWindow(app)
    window.bind_source(case,key,rows,initial,operation or OPERATIONS[0])
    window.deiconify()
    window.lift()
    window.method.focus_set()
    return window


class TransformWindow(tk.Toplevel):
    def __init__(self, app):
        super().__init__(app.root, background=SURFACE)
        self.withdraw()
        self.app = app
        apply_theme(self)
        self.title("Byte transforms — Insight")
        self.protocol("WM_DELETE_WINDOW", self.destroy)
        self.bind("<Escape>", lambda _:self.destroy())
        self.columnconfigure(0,weight=1)
        self.rowconfigure(0,weight=1)
        body = ttk.Frame(self,padding=8)
        body.grid(row=0,column=0,sticky="nsew")
        body.columnconfigure(0,weight=1)
        body.rowconfigure(6,weight=1)
        self.source = ttk.Label(body,style="DockTitle.TLabel",anchor="w",wraplength=500)
        self.source.grid(row=0,column=0,sticky="ew")
        self.source.bind("<Configure>",lambda e:self.source.configure(wraplength=max(100,e.width-4)))
        self.digest = tk.StringVar(self)
        ttk.Entry(body,textvariable=self.digest,state="readonly",font=MONO).grid(row=1,column=0,sticky="ew",pady=(2,5))

        bounds = ttk.Frame(body)
        bounds.grid(row=2,column=0,sticky="ew")
        self.coordinate = ttk.Label(bounds)
        self.coordinate.grid(row=0,column=0,sticky="w")
        ttk.Label(bounds,text="Length in bytes").grid(row=0,column=1,sticky="w")
        self.start, self.length = tk.StringVar(self), tk.StringVar(self)
        for i,var in enumerate((self.start,self.length)):
            bounds.columnconfigure(i,weight=1)
            entry = ttk.Entry(bounds,textvariable=var,font=MONO,width=8,validate="key",
                              validatecommand=(self.register(lambda text:len(text)<=16),"%P"))
            entry.grid(row=1,column=i,sticky="ew",padx=(0,4))
            entry.bind("<Return>",lambda _:self.load_range())
        ttk.Button(bounds,text="Load range",command=self.load_range).grid(row=1,column=2)
        ttk.Button(bounds,text="Selected bytes",command=self.selected).grid(row=1,column=3,padx=(4,0))

        controls = ttk.Frame(body)
        controls.grid(row=3,column=0,sticky="ew",pady=(5,0))
        controls.columnconfigure(1,weight=1)
        self.operation, self.argument = tk.StringVar(self,value=OPERATIONS[0]), tk.StringVar(self)
        ttk.Label(controls,text="Operation").grid(row=0,column=0,sticky="w")
        self.method = ttk.Combobox(controls,textvariable=self.operation,values=OPERATIONS,state="readonly",width=16)
        self.method.grid(row=1,column=0,sticky="ew",padx=(0,5))
        self.parameter_title = ttk.Label(controls)
        self.parameter_title.grid(row=0,column=1,sticky="w")
        def valid_parameter(text):
            limit = 3*MAX_INPUT if self.operation.get()=="Patch proposal" else 3*MAX_KEY
            return len(text) <= limit
        self.parameter = ttk.Entry(controls,textvariable=self.argument,font=MONO,width=6,validate="key",
                                   validatecommand=(self.register(valid_parameter),"%P"))
        self.parameter.grid(row=1,column=1,sticky="ew")
        self.parameter.bind("<Return>",lambda _:self.preview())
        self.method.bind("<<ComboboxSelected>>",lambda _:self._method_changed())
        ttk.Button(controls,text="Preview",command=self.preview).grid(row=1,column=2,padx=(5,0))
        ttk.Button(controls,text="Clear preview",command=self.clear).grid(row=1,column=3,padx=(4,0))
        self.feedback = tk.StringVar(self)
        message = ttk.Label(body,textvariable=self.feedback,foreground=AMBER,wraplength=500)
        message.grid(row=4,column=0,sticky="ew",pady=(4,0))
        message.bind("<Configure>",lambda e:message.configure(wraplength=max(100,e.width-4)))

        self.panes = ttk.Frame(body)
        self.panes.grid(row=6,column=0,sticky="nsew",pady=4)
        self.cards, self.labels, self.displays = [], [], []
        for i in range(2):
            card = ttk.Frame(self.panes)
            self.cards.append(card)
            self.labels.append(ttk.Label(card,style="DockTitle.TLabel",anchor="w"))
            self.labels[i].pack(fill="x")
            frame = ttk.Frame(card)
            frame.pack(fill="both",expand=True)
            text = tk.Text(frame,width=1,height=3,font=MONO,wrap="none",background=WELL,foreground=INK,
                           selectbackground=SELECTION,highlightbackground=RIM,highlightcolor=AMBER,
                           borderwidth=0,highlightthickness=1,state="disabled")
            text.tag_configure("changed",foreground=AMBER)
            scrollable(frame,text)
            self.displays.append(text)
        self.stacked = None
        self.panes.bind("<Configure>",self._fit)
        footer = ttk.Frame(body)
        footer.grid(row=7,column=0,sticky="ew")
        self.pages = ttk.Label(footer,foreground=MUTED)
        self.pages.pack(side="left")
        self.forward = ttk.Button(footer,text="Next",command=lambda:self._page(1))
        self.back = ttk.Button(footer,text="Previous",command=lambda:self._page(-1))
        self.forward.pack(side="right")
        self.back.pack(side="right",padx=(0,4))
        self.result = None
        self.preview_job = None
        self.loading = False
        for var in (self.start,self.length,self.argument):
            var.trace_add("write",self._changed)
        width = min(930,max(350,app.root.winfo_width()-32))
        height = min(680,max(330,app.root.winfo_height()-42))
        self.geometry(f"{width}x{height}")
        self.minsize(340,310)
        owner = capture_geometry(app.root)
        if owner:
            restore_geometry(self,dict(owner, x=owner["x"]+16, y=owner["y"]+18,
                                       width=width, height=height),app.root)

    def destroy(self):
        self._cancel_preview()
        if getattr(self.app,"transform_window",None) is self:
            self.app.transform_window = None
        super().destroy()

    def _fit(self, event):
        stacked = event.width < self.winfo_pixels("485p")
        if stacked == self.stacked:
            return
        self.stacked = stacked
        for i,card in enumerate(self.cards):
            self.panes.columnconfigure(i,weight=int(i==0 or not stacked),uniform="" if stacked else "bytes")
            self.panes.rowconfigure(i,weight=int(i==0 or stacked),uniform="rows" if stacked else "")
            card.grid(row=i if stacked else 0,column=0 if stacked else i,sticky="nsew",
                      padx=(0,4 if not stacked and i==0 else 0),pady=(0,3 if stacked and i==0 else 0))

    def bind_source(self, case, key, rows, initial, operation):
        self.current = None
        self.case, self.key, self.rows, self.initial = case,key,rows,initial
        self.coordinate.configure(text="Module RVA (hex)" if case.image is not None else "Routine offset (hex)")
        self.digest.set(f"SHA-256  {case.digest}")
        self.selected()
        self.operation.set(operation)
        self._method_changed()

    def selected(self):
        self.loading = True
        self.start.set(f"0x{self.initial.start:X}")
        self.length.set(str(len(self.initial.data)))
        self.loading = False
        self._show_source(self.initial)

    def _read(self):
        at = self.start.get().strip()
        count = self.length.get().strip()
        if not re.fullmatch(r"(?:0[xX])?[0-9a-fA-F]{1,8}",at) or not re.fullmatch(r"[0-9]{1,5}",count):
            raise ValueError(f"Enter a hex address and a decimal length of 1–{MAX_INPUT:,} bytes.")
        return read_range(self.case,self.key,self.rows,int(at,16),int(count))

    def load_range(self):
        try:
            self._show_source(self._read())
        except ValueError as error:
            self.feedback.set(str(error))

    def _method_changed(self):
        title = {"XOR":"Repeating key (hex)", "Patch proposal":"Replacement bytes (hex)",
                 "Shift left":"Bits per byte (0–7)", "Shift right":"Bits per byte (0–7)"}.get(self.operation.get(),"")
        self.loading = True
        self.argument.set("1" if self.operation.get().startswith("Shift") else "")
        self.loading = False
        self.parameter_title.configure(text=title)
        self.parameter.state(["!disabled" if title else "disabled"])
        if getattr(self,"current",None) is not None:
            self._changed()

    def _changed(self, *_):
        if self.loading:
            return
        self._cancel_preview()
        if self.result is not None:
            self.clear()
        if not self.parameter.instate(["disabled"]) and not self.argument.get():
            return
        self.preview_job = self.after(180,self.preview)

    def _cancel_preview(self):
        if self.preview_job is not None:
            self.after_cancel(self.preview_job)
            self.preview_job = None

    def _show_source(self, current):
        self.current = current
        coordinate = "RVA" if self.case.image is not None else "offset"
        file_pos = f" · file +0x{current.file_offset:X}" if current.file_offset is not None else ""
        self.source.configure(text=f"{self.case.label} · {current.origin} · {coordinate} 0x{current.start:X}{file_pos}")
        self.clear()

    def clear(self):
        self._cancel_preview()
        self.result = None
        self.page = 0
        self.feedback.set("")
        self._render()

    def preview(self):
        self._cancel_preview()
        try:
            current = self._read()
            self._show_source(current)
            self.result = transform(current.data,self.operation.get(),self.argument.get())
        except ValueError as error:
            self.clear()
            self.feedback.set(str(error))
            return
        self._render()

    def _page(self, delta):
        self.page = max(0,min(self.page+delta,self.count-1))
        self._render()

    def _render(self):
        source, result = self.current.data, self.result
        self.count = (max(len(source),len(result) if result is not None else 0)+PAGE-1)//PAGE
        operation = self.operation.get()
        self.labels[0].configure(text=f"Original · {len(source):,} bytes")
        if result is None:
            title = "Preview"
        elif operation=="Patch proposal":
            changed = sum(a!=b for a,b in zip(source,result))
            title = f"Proposed replacement · {changed:,} of {len(result):,} bytes changed"
        else:
            title = f"{operation} · {len(result):,} output bytes"
        self.labels[1].configure(text=title)
        for i,data in enumerate((source,result)):
            text = self.displays[i]
            text.configure(state="normal")
            text.delete("1.0","end")
            if data is not None:
                absolute = i==0 or operation=="Patch proposal"
                text.insert("1.0",_rows(data,self.current.start if absolute else 0,self.page,"" if absolute else "+"))
                if i==1 and operation=="Patch proposal":
                    for index in range(self.page*PAGE,min((self.page+1)*PAGE,len(source))):
                        if data[index] != source[index]:
                            line = (index%PAGE)//8+1
                            column = 10+(index%8)*3
                            text.tag_add("changed",f"{line}.{column}",f"{line}.{column+2}")
            text.configure(state="disabled")
        self.pages.configure(text=f"Page {self.page+1} of {self.count}")
        self.back.state(["!disabled" if self.page else "disabled"])
        self.forward.state(["!disabled" if self.page+1<self.count else "disabled"])
