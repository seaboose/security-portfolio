"""File-backed byte previews, entropy windows and string-reference locations."""

from bisect import bisect_right
from collections import Counter
from math import log2
import re

from .data_access import direct_access


WINDOW = 64


def entropy(data):
    size = len(data)
    return -sum(n / size * log2(n / size) for n in Counter(data).values()) if size else 0.0


def _file_sample(image, at):
    section = image.section_at(at)
    if section is None or not section.rva <= at < section.rva + section.backed:
        return at, b""
    relative = (at - section.rva) // WINDOW * WINDOW
    offset = section.offset + relative
    return section.rva + relative, image.data[offset:offset + min(WINDOW, section.backed - relative)]


def file_window(image, at):
    return _file_sample(image, at)[1]


def entropy_windows(image, start, stop, *, base=0, data=b""):
    """Map visible byte addresses to their exact sample's entropy and backed length."""
    if not 0 <= stop-start <= WINDOW:
        raise ValueError("Heatmap previews cover at most 64 displayed bytes.")
    values = {}
    if image is None:
        start, stop = max(start, base), min(stop, base+len(data))
    at = start
    while at < stop:
        if image is not None:
            first, sample = _file_sample(image, at)
        else:
            first = base + (at-base)//WINDOW*WINDOW
            offset = first-base
            sample = data[offset:offset+WINDOW] if offset >= 0 else b""
        if not sample:
            at += 1
            continue
        end = min(stop, first+len(sample))
        value = entropy(sample), len(sample)
        for address in range(at, end):
            values[address] = value
        at = end
    return values


def string_sites(rows, hits):
    """Mark supported direct memory operands and verified RIP-relative string addresses."""
    spans = sorted((h.rva, h.rva+h.size) for h in hits)
    if not spans:
        return set()
    starts, ends = [], []
    for start, stop in spans:
        starts.append(start)
        ends.append(max(stop, ends[-1]) if ends else stop)
    sites = set()
    for row in rows:
        access = direct_access(row)
        if access:
            at, size, _ = access
        elif row.op == "lea":
            raw = row.raw
            i = int(bool(raw) and 0x40 <= raw[0] <= 0x4F)
            if len(raw) != i+6 or raw[i] != 0x8D or raw[i+1] & 0xC7 != 5:
                continue
            operand = re.fullmatch(r"\w+,\s*(?:(?:byte|word|dword|qword) ptr )?\[([0-9a-f]+)h\]", row.args, re.I)
            at = row.rva + len(raw) + int.from_bytes(raw[-4:], "little", signed=True)
            if operand is None or int(operand[1], 16) != at:
                continue
            size = 1
        else:
            continue
        n = bisect_right(starts, at + size - 1) - 1
        if n >= 0 and ends[n] > at:
            sites.add(row.rva)
    return sites
