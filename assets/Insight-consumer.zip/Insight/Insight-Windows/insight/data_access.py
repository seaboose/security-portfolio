"""Direct x64 integer memory accesses in a verified MSVC instruction listing."""

import re


_MEMORY = re.compile(r"(?:^|,)(byte|word|dword|qword) ptr \[([0-9a-fA-F]+)h\](?=,|$)")
_WIDTH = {"byte": 1, "word": 2, "dword": 4, "qword": 8}
_READ = frozenset("cmp test movzx movsx movsxd imul mul idiv div push".split())
_STORE = frozenset("mov movnti pop".split())
_UPDATE = frozenset("add adc sub sbb and or xor inc dec neg not shl shr sar sal rol ror rcl rcr shld shrd xadd cmpxchg".split())


def direct_access(row):
    """Return (target RVA, operand width, access) for a proven RIP-relative operand."""
    op, args = row.op, row.args
    if " ptr [" not in args:
        return None
    if op == "lock":
        op, _, args = args.partition(" ")
        args = args.lstrip()
    operand = _MEMORY.search(args)
    if operand is None:
        return None
    if op in _READ or op.startswith("cmov"):
        kind = "Read"
    elif op in _STORE or op.startswith("set"):
        kind = "Write" if operand.start() == 0 else "Read"
    elif op in _UPDATE:
        kind = "Read/Write" if operand.start() == 0 else "Read"
    elif op == "xchg":
        kind = "Read/Write"
    else:
        return None

    # Long mode ModR/M 00xxx101 addresses RIP+disp32. Verify both the encoding
    # and the address rendered by MSVC; FS/GS, address overrides and SIB are excluded.
    raw = row.raw
    p = 0
    while p < len(raw) and (raw[p] in (0x66, 0xf0) or 0x40 <= raw[p] <= 0x4f):
        p += 1
    if p >= len(raw) or raw[p] in (0x26, 0x2e, 0x36, 0x3e, 0x64, 0x65, 0x67, 0xf2, 0xf3):
        return None
    modrm = p + (2 if raw[p] == 0x0f else 1)
    if modrm + 5 > len(raw) or raw[modrm] & 0xc7 != 0x05:
        return None
    target = row.rva + len(raw) + int.from_bytes(raw[modrm + 1:modrm + 5], "little", signed=True)
    if target == int(operand[2], 16):
        return target, _WIDTH[operand[1]], kind
    return None
