"""Side-by-side, read-only function comparison in the desktop investigation."""

import tkinter as tk
from tkinter import ttk

from .appearance import AMBER, CANVAS, INK, LINE, MONO, MUTED, UI_HEADING, apply_theme
from .block_diff import align_block_code


PAGE_SIZE = 150


def _pair(aligned):
    return aligned.left, aligned.right


class _ScopePicker(ttk.Frame):
    """Page long block or operand lists without materializing every native menu item."""

    def __init__(self, parent, title, choose):
        super().__init__(parent)
        self.choose = choose
        self.columnconfigure(1, weight=1)
        ttk.Label(self, text=title).grid(row=0, column=0, padx=(0, 5))
        self.box = ttk.Combobox(self, width=8, state="readonly", font=MONO)
        self.box.grid(row=0, column=1, sticky="ew")
        self.box.bind("<<ComboboxSelected>>", self._choose)
        self.previous = ttk.Button(self, text="‹", width=3, command=lambda:self._page(self.page-1, True))
        self.next = ttk.Button(self, text="›", width=3, command=lambda:self._page(self.page+1, True))

    def load(self, items, prompt, label):
        self.items, self.prompt, self.label = items, prompt, label
        self._page(0)
        if items:
            self.grid()
        else:
            self.grid_remove()

    def _page(self, page, activate=False):
        self.page = page
        start = page*PAGE_SIZE
        labels = [self.label(item) for item in self.items[start:start+PAGE_SIZE]]
        self.box.configure(values=(self.prompt, *labels))
        self.box.current(int(activate and bool(labels)))
        for column, (button, enabled) in enumerate(((self.previous, start > 0),
                (self.next, start+PAGE_SIZE < len(self.items))), 2):
            if len(self.items) > PAGE_SIZE:
                button.grid(row=0, column=column)
                button.state(["!disabled" if enabled else "disabled"])
            else:
                button.grid_remove()
        if activate:
            self._choose()

    def _choose(self, _event=None):
        index = self.box.current()
        if index >= 0:
            self.choose(self.items[self.page*PAGE_SIZE + index-1] if index else None)


class _AlignedRows(ttk.Frame):
    """Keep the two builds on the same vertical coordinate, with independent horizontal scroll."""

    def __init__(self, parent, title, choose):
        super().__init__(parent)
        self.choose = choose
        self.title = title
        self.texts = []
        self.active = None
        self.alignment = ()
        self.columnconfigure((0, 1), weight=1, uniform="side")
        self.rowconfigure(1, weight=1)
        self.caption = ttk.Label(self, text=title, style="DockTitle.TLabel")
        self.caption.grid(row=0, column=0, columnspan=3, sticky="ew", pady=(2, 1))
        self.scroll = ttk.Scrollbar(self, orient="vertical", style="Insight.Vertical.TScrollbar",
                                    command=lambda *args: self.texts[0].yview(*args))
        self.scroll.grid(row=1, column=2, sticky="ns")
        for side in range(2):
            text = tk.Text(self, bg=CANVAS, fg=INK, font=MONO, width=1, height=2, wrap="none",
                           borderwidth=0, padx=4, pady=2, takefocus=True, state="disabled",
                           highlightthickness=1, highlightbackground=LINE, highlightcolor=AMBER,
                           exportselection=False)
            self.texts.append(text)
            text.grid(row=1, column=side, sticky="nsew")
            horizontal = ttk.Scrollbar(self, orient="horizontal", style="Insight.Horizontal.TScrollbar",
                                       command=text.xview)
            horizontal.grid(row=2, column=side, sticky="ew")
            text.configure(xscrollcommand=horizontal.set, yscrollcommand=lambda a,b,s=side:self._sync(s,a,b))
            text.tag_configure("changed", background=("#392226", "#3d3221")[side],
                               foreground=("#fac2ca", "#f6d89d")[side])
            text.tag_configure("linked", background="#25463f", foreground="#e7fff7")
            text.tag_configure("chosen", background="#59272f", foreground="#fff2f3")
            text.tag_configure("delta", underline=True)
            for key, step in (("Up", -1), ("Down", 1), ("Return", 0)):
                text.bind(f"<{key}>", lambda _,s=side,d=step: self._step(s,d))
            text.bind("<ButtonRelease-1>", lambda event,s=side:self._click(s,event))

    def _sync(self, side, first, last):
        self.scroll.set(first, last)
        other = self.texts[1-side]
        if abs(other.yview()[0] - float(first)) > 0.000001:
            other.yview_moveto(first)

    def _click(self, side, event):
        text = self.texts[side]
        if not text.tag_ranges("sel"):
            row = int(text.index(f"@{event.x},{event.y}").split(".")[0]) - 1
            if 0 <= row < len(self.alignment) and _pair(self.alignment[row])[side] is not None:
                text.focus_set()
                self.choose(self, side, row)

    def _step(self, side, step):
        row = self.active if self.active is not None else 0
        if self.active is not None:
            row += step
        while 0 <= row < len(self.alignment):
            if _pair(self.alignment[row])[side] is not None:
                self.choose(self, side, row)
                break
            row += step or 1
        return "break"

    def populate(self, alignment, format_row, byte_deltas=None):
        self.alignment = alignment
        self.active = None
        self.caption.configure(text=self.title)
        for side, text in enumerate(self.texts):
            lines, changed, deltas = [], [], []
            for n, aligned in enumerate(alignment, 1):
                index = _pair(aligned)[side]
                highlight = aligned.status in ("Changed", "Added", "Removed")
                prefix = ("− " if side == 0 else "+ ") if highlight else "  "
                lines.append(prefix + format_row(side, index) if index is not None else "")
                if highlight and index is not None:
                    changed.extend((f"{n}.0", f"{n}.end"))
                    if byte_deltas and aligned.status == "Changed":
                        for start, stop in byte_deltas(aligned, side):
                            deltas.extend((f"{n}.{start}", f"{n}.{stop}"))
            text.configure(state="normal")
            text.delete("1.0", "end")
            text.insert("1.0", "\n".join(lines))
            if changed:
                text.tag_add("changed", *changed)
            if deltas:
                text.tag_add("delta", *deltas)
            text.configure(state="disabled")
            text.yview_moveto(0)
            text.xview_moveto(0)

    def mark(self, groups, tag, focus_side):
        for side, text in enumerate(self.texts):
            for old in ("chosen", "linked"):
                text.tag_remove(old, "1.0", "end")
            positions = [pos for row in groups[side] for pos in (f"{row+1}.0", f"{row+1}.end")]
            if positions:
                text.tag_add(tag, *positions)
        target = groups[focus_side] or groups[1-focus_side]
        self.active = min(target) if target else None
        if self.active is not None:
            index = f"{self.active+1}.0"
            if self.texts[0].dlineinfo(index) is None:
                self.texts[0].yview(index)


class DiffView(ttk.Frame):
    def __init__(self, parent, on_select, on_back, on_identity=None, on_private=None, can_private=None):
        super().__init__(parent, padding=(8, 5))
        apply_theme(self)
        self.on_select = on_select
        self.on_private, self.can_private = on_private, can_private
        self.matches = self.visible = ()
        self.current_match = self.detail = None
        self.page = 0
        self.status = tk.StringVar(self)
        self.build_labels = ("", "")
        header = ttk.Frame(self)
        header.pack(fill="x")
        ttk.Label(header, text="Binary diff", font=UI_HEADING).pack(side="left")
        self.back = ttk.Button(header, text="Return to investigation", command=on_back)
        self.back.pack(side="right")
        find = ttk.Frame(header)
        find.pack(side="left", padx=10, fill="x", expand=True)
        self.search = ttk.Entry(find, width=10)
        self.search.pack(side="left", fill="x", expand=True)
        self.find = ttk.Button(find, text="Find function", command=self._filter)
        self.find.pack(side="right", padx=(3, 0))
        self.search.bind("<Return>", self._filter)
        selectors = ttk.Frame(self)
        selectors.pack(fill="x", pady=(3, 2))
        selectors.columnconfigure(3, weight=1)
        ttk.Label(selectors, text="Show").grid(row=0, column=0, padx=(0, 4))
        self.filter = ttk.Combobox(selectors, width=12, state="readonly", takefocus=True)
        self.filter.grid(row=0, column=1)
        self.filter.bind("<<ComboboxSelected>>", self._filter)
        ttk.Label(selectors, text="Function").grid(row=0, column=2, padx=(8, 4))
        self.functions = ttk.Combobox(selectors, width=10, state="readonly", font=MONO)
        self.functions.grid(row=0, column=3, sticky="ew")
        self.functions.bind("<<ComboboxSelected>>", self._choose_match)
        self.pages = ttk.Frame(selectors)
        self.previous = ttk.Button(self.pages, text="‹", width=3, command=lambda:self._show_page(self.page-1))
        self.next = ttk.Button(self.pages, text="›", width=3, command=lambda:self._show_page(self.page+1))
        self.previous.pack(side="left")
        self.next.pack(side="left")
        statusbar = ttk.Frame(self)
        statusbar.pack(fill="x", pady=(0, 3))
        self.identity = ttk.Button(statusbar, text="Build details…", command=on_identity)
        self.identity.state(["disabled"])
        if on_identity:
            self.identity.pack(side="right", padx=(4, 0))
        self.status_label = ttk.Label(statusbar, textvariable=self.status, foreground=MUTED)
        self.status_label.pack(fill="x", expand=True, side="left")
        self.status_label.bind("<Configure>", lambda e:self.status_label.configure(wraplength=max(80,e.width-4)))
        self.private = ttk.Button(statusbar, text="Find private matches…",
                                  command=lambda:self.on_private(self.current_match))
        self.scope = ttk.Frame(self)
        self.scope.columnconfigure(0, weight=1)
        self.scope.pack(fill="x")
        self.candidate_bar = ttk.Frame(self.scope)
        self.candidate_bar.columnconfigure(1, weight=1)
        ttk.Label(self.candidate_bar, text="Proposed match").grid(row=0, column=0, padx=(0, 5))
        self.candidate_choice = ttk.Combobox(self.candidate_bar, width=10, state="readonly", font=MONO)
        self.candidate_choice.grid(row=0, column=1, sticky="ew")
        self.candidate_choice.bind("<<ComboboxSelected>>", self._propose)
        self.compare_candidate = ttk.Button(self.candidate_bar, text="Compare candidate", command=self._compare_candidate)
        self.compare_candidate.grid(row=0, column=2)
        self.unpaired = ttk.Button(self.candidate_bar, text="Return to unpaired", command=self._choose_match)
        self.candidate_source = None
        self.candidates = ()
        self.block_picker = _ScopePicker(self.scope, "Block", self._show_block)
        self.block_picker.grid(row=1, column=0, sticky="ew")
        self.block_picker.grid_remove()
        self.blocks = self.block_picker.box
        self.operand_picker = _ScopePicker(self.scope, "Immediate", self._show_constant)
        self.operand_picker.grid(row=2, column=0, sticky="ew")
        self.operand_picker.grid_remove()
        self.constants = self.operand_picker.box
        builds = ttk.Frame(self)
        builds.pack(fill="x")
        builds.columnconfigure((0, 1), weight=1, uniform="side")
        self.titles = []
        for side in range(2):
            title = ttk.Label(builds, style="DockTitle.TLabel", foreground=("#f1bdc2", "#f5d397")[side])
            title.grid(row=0, column=side, sticky="ew", padx=3)
            title.bind("<Configure>", lambda e,w=title:w.configure(wraplength=max(80,e.width)))
            self.titles.append(title)
        self.split = tk.PanedWindow(self, orient="vertical", sashwidth=5, bg=LINE, borderwidth=0)
        self.split.pack(fill="both", expand=True)
        self.code = _AlignedRows(self.split, "Ghidra pseudocode", self._select)
        self.machine = _AlignedRows(self.split, "RVA · Exact instruction bytes · Assembly", self._select)
        builds.columnconfigure(2, minsize=self.code.scroll.winfo_reqwidth())
        for panel in (self.code, self.machine):
            self.split.add(panel, minsize=62, stretch="always")

    def clear(self):
        self.matches = self.visible = ()
        self.current_match = None
        self._clear_candidates()
        for control in (self.filter, self.functions):
            control.set("")
            control.configure(values=())
        self.search.delete(0, "end")
        self.pages.grid_remove()
        self.identity.state(["disabled"])
        self.build_labels = ("", "")
        for title in self.titles:
            title.configure(text="")
        self.set_status("")

    def set_status(self, message):
        self.detail = None
        self.current_block = None
        self.block_picker.grid_remove()
        self.operand_picker.grid_remove()
        self.lookups = ()
        self.code.populate((), None)
        self.machine.populate((), None)
        self.status.set(message)

    def _clear_candidates(self):
        self.candidate_source, self.candidates = None, ()
        self.candidate_bar.grid_remove()
        self.unpaired.grid_remove()
        self.private.pack_forget()

    def set_candidates(self, source_match, candidates, summary):
        if self.current_match != source_match:
            return
        self.candidate_source = source_match
        self.candidates = tuple(candidates)
        self.candidate_choice.configure(values=[f"0x{m.left.rva:X} → 0x{m.right.rva:X}"
                                                for m in self.candidates])
        self.candidate_choice.set("Choose an advisory match…")
        self.compare_candidate.state(["disabled"])
        self.status.set(summary)
        if self.candidates:
            self.candidate_bar.grid(row=0, column=0, sticky="ew", pady=(0, 2))
        else:
            self.candidate_bar.grid_remove()

    def _propose(self, _event=None):
        index = self.candidate_choice.current()
        if 0 <= index < len(self.candidates):
            self.status.set(f"Proposed {self.candidate_choice.get()}  ·  {self.candidates[index].basis}")
            self.compare_candidate.state(["!disabled"])

    def _compare_candidate(self):
        index = self.candidate_choice.current()
        if not 0 <= index < len(self.candidates):
            return
        self.current_match = self.candidates[index]
        self.private.pack_forget()
        self.unpaired.grid(row=0, column=3)
        self._titles()
        self.set_status(self.current_match.basis)
        self.on_select(self.current_match)

    def _titles(self):
        for side, title in enumerate(self.titles):
            label = ("Baseline", "Comparison")[side] + "  ·  " + self.build_labels[side]
            if self.candidate_source is not None and self.current_match != self.candidate_source:
                label += f"  ·  0x{_pair(self.current_match)[side].rva:X}"
            title.configure(text=label)

    def set_index(self, matches, left_label, right_label, preferred_rva=None):
        self.clear()
        self.matches = matches
        self.build_labels = (left_label, right_label)
        self.identity.state(["!disabled"])
        self._titles()
        statuses = {match.status for match in matches}
        options = [s for s in ("Changed", "Candidate", "Added", "Removed", "Unmatched", "Partial",
                                "Unchanged") if s in statuses]
        self.filter.configure(values=(*options, "All functions"))
        preferred = next((m for m in matches if m.left and m.left.rva == preferred_rva), None)
        self.filter.set(preferred.status if preferred else self.filter["values"][0])
        self._filter(preferred=preferred)

    def _filter(self, _event=None, *, preferred=None):
        mode = self.filter.get()
        term = self.search.get().strip().casefold()
        self.visible = [m for m in self.matches if (mode == "All functions" or m.status == mode)
                        and (not term or term in m.name.casefold()
                             or any(r and term == f"0x{r.rva:x}" for r in (m.left, m.right)))]
        index = self.visible.index(preferred) if preferred else 0
        self._show_page(index // PAGE_SIZE, index % PAGE_SIZE)
        return "break"

    def _show_page(self, page, index=0):
        self.page = page
        first = page * PAGE_SIZE
        if len(self.visible) > PAGE_SIZE:
            self.pages.grid(row=0, column=4, padx=(3, 0))
            self.previous.state(["disabled" if first == 0 else "!disabled"])
            self.next.state(["disabled" if first+PAGE_SIZE >= len(self.visible) else "!disabled"])
        else:
            self.pages.grid_remove()
        options = []
        for m in self.visible[first:first+PAGE_SIZE]:
            addresses = [f"0x{r.rva:X}" if r else "—" for r in (m.left, m.right)]
            options.append(f"{m.name}   {addresses[0]} → {addresses[1]}" +
                           (f"   {m.status}" if self.filter.get() == "All functions" else ""))
        self.functions.configure(values=options)
        if self.visible:
            self.functions.current(index)
            self._choose_match()
        else:
            self.functions.set("")
            self.current_match = None
            self._clear_candidates()
            self.on_select(None)
            self.set_status("No matching functions. Clear the search or change the status filter.")

    def _choose_match(self, _event=None):
        if self.functions.current() >= 0:
            index = self.page*PAGE_SIZE + self.functions.current()
            self.current_match = self.visible[index]
            self._clear_candidates()
            self._titles()
            if self.can_private and self.on_private and self.can_private(self.current_match):
                self.private.pack(side="right", before=self.status_label, padx=(3, 0))
            self.set_status(f"{self.current_match.basis} · Comparing function…")
            self.on_select(self.current_match)

    def set_detail(self, detail):
        self.detail = detail
        def block_label(block):
            addresses = [f"0x{side.rows[b.first].rva:X}" if b else "—"
                         for side, b in zip((detail.left, detail.right), _pair(block))]
            return f"{block.status}   {addresses[0]} → {addresses[1]}"
        priority = {"Changed": 0, "Baseline only": 1, "Comparison only": 2, "Same bytes": 3}
        blocks = sorted(detail.blocks, key=lambda b:priority.get(b.status, 4))
        self.block_picker.load(blocks, "Whole function", block_label)
        self._show_block(None)

    def _show_constant(self, change):
        if change is None:
            return
        rva = self.detail.left.rows[change.left].rva
        row = self.lookups[0][0].get(rva)
        if row is not None and _pair(self.machine.alignment[row]) == (change.left, change.right):
            self._select(self.machine, 0, row)

    def _show_block(self, block):
        detail = self.detail
        if detail is None:
            return
        self.current_block = block
        sides = (detail.left, detail.right)
        instructions = block.instructions if block else detail.instructions
        pseudocode = align_block_code(*sides, block) if block else detail.pseudocode
        def operand_label(change):
            a, b = sides[0].rows[change.left], sides[1].rows[change.right]
            return f"{change.before:#x} → {change.after:#x}   (0x{a.rva:X} → 0x{b.rva:X})"
        changes = block.constants if block else ()
        self.operand_picker.load(changes, f"{len(changes)} changed · select an operand", operand_label)
        self.lookups = []
        max_bytes = max((len(r.raw) for side in sides if side for r in side.rows), default=0)
        def machine(side, index):
            r = sides[side].rows[index]
            return f"{r.rva:08X}  {r.raw.hex(' ').upper():<{max_bytes*3-1}}  {r.op} {r.args}".rstrip()
        def byte_deltas(aligned, side):
            left, right = _pair(aligned)
            a, b = sides[0].rows[left].raw, sides[1].rows[right].raw
            # The change marker, eight-digit RVA and two spaces precede the byte string.
            for i in range(len((a, b)[side])):
                if i >= min(len(a), len(b)) or a[i] != b[i]:
                    yield 12+i*3, 14+i*3
        def code(side, index):
            return f"{index+1:>3}  {sides[side].code.lines[index].text}"
        self.code.populate(pseudocode, code)
        self.machine.populate(instructions, machine, byte_deltas)
        messages = [self.current_match.basis] if self.current_match else []
        if block:
            messages.append(block.basis)
        for s, side in enumerate(sides):
            # Keep scalar routine indexes separate from aligned display indexes.
            rows = {side.rows[i].rva:n for n,a in enumerate(instructions)
                    if (i := _pair(a)[s]) is not None}
            lines = {}
            for n, a in enumerate(pseudocode):
                i = _pair(a)[s]
                if i is not None:
                    for rva in side.code.lines[i].rvas:
                        lines.setdefault(rva, []).append(n)
            self.lookups.append((rows, lines))
            if side and side.error:
                messages.append(("Baseline" if s == 0 else "Comparison") + " · " + side.error)
            elif side is None:
                messages.append(("Baseline" if s == 0 else "Comparison") + " · No paired function")
            elif block and _pair(block)[s] is not None and not lines:
                messages.append(("Baseline" if s == 0 else "Comparison") + " · No mapped pseudocode in block")
        self.status.set("  ·  ".join(messages))
        # Open on a real mapped change when one exists, even after a long unchanged prologue.
        for n, a in enumerate(pseudocode):
            if a.status not in ("Changed", "Removed", "Added"):
                continue
            for s, i in enumerate(_pair(a)):
                if i is not None and sides[s].code.lines[i].rvas:
                    self._select(self.code, s, n)
                    return
        for n, a in enumerate(instructions):
            if a.status in ("Changed", "Removed", "Added"):
                self._select(self.machine, int(a.left is None), n)
                return
        if block and instructions:
            self._select(self.machine, int(instructions[0].left is None), 0)

    def _select(self, panel, focus_side, row):
        if self.detail is None:
            return
        pair = _pair(panel.alignment[row])
        chosen = [() if i is None else (row,) for i in pair]
        linked = [set(), set()]
        for s, side in enumerate((self.detail.left, self.detail.right)):
            if pair[s] is None:
                continue
            rows, lines = self.lookups[s]
            if panel is self.code:
                for rva in side.code.lines[pair[s]].rvas:
                    if rva in rows:
                        linked[s].add(rows[rva])
            else:
                linked[s].update(lines.get(side.rows[pair[s]].rva, ()))
        other = self.machine if panel is self.code else self.code
        panel.mark(chosen, "chosen", focus_side)
        other.mark(linked, "linked", focus_side)
        units = ("instruction", "instructions") if panel is self.code else ("line", "lines")
        counts = [f"{len(items)} mapped {units[len(items) != 1]}" for items in linked]
        if self.current_block and panel is self.code:
            for s, i in enumerate(pair):
                if i is not None:
                    side = (self.detail.left, self.detail.right)[s]
                    outside = sum(rva not in self.lookups[s][0] for rva in side.code.lines[i].rvas)
                    if outside:
                        counts[s] += f" here (+{outside} outside block)"
        other.caption.configure(text=f"{other.title}   ·   {counts[0]} / {counts[1]}")
        panel.caption.configure(text=panel.title)

