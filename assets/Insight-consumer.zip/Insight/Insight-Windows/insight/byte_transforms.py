"""Bounded byte previews. All operations consume immutable snapshot bytes."""

import base64
from dataclasses import dataclass
import zlib


MAX_INPUT = 16 * 1024
MAX_OUTPUT = 64 * 1024
MAX_KEY = 256
OPERATIONS = ("XOR", "Base64 decode", "Base64 encode", "From hex", "zlib decompress",
              "zlib compress", "Shift left", "Shift right", "Patch proposal")


@dataclass(frozen=True)
class ByteRange:
    start: int
    data: bytes
    origin: str
    file_offset: int | None = None


def read_range(case, routine, rows, start, length):
    if type(start) is not int or not 0 <= start < 2**32:
        raise ValueError("Enter a hexadecimal address from 0 to FFFFFFFF.")
    if type(length) is not int or not 1 <= length <= MAX_INPUT or start+length > 2**32:
        raise ValueError(f"Select 1–{MAX_INPUT:,} bytes inside a single backed range.")
    end = start+length
    if case.image is not None:
        image = case.image
        section = image.section_at(start)
        if section is None or end > section.rva+section.backed:
            raise ValueError("The range must fit completely inside one file-backed PE section.")
        offset = image.offset(start, length)
        data = image.data[offset:offset+length]
        if len(data) != length:
            raise ValueError("The snapshot does not contain all requested bytes.")
        return ByteRange(start, data, f"PE section at RVA 0x{section.rva:X}", offset)
    data = bytearray()
    at = start
    for row in rows:
        row_end = row.rva+len(row.raw)
        if row_end <= at:
            continue
        if row.rva > at:
            break
        at_end = min(row_end, end)
        data.extend(row.raw[at-row.rva:at_end-row.rva])
        at = at_end
        if at == end:
            return ByteRange(start, bytes(data), f"{routine} · retained instruction bytes")
    raise ValueError("The requested offsets cross a gap or extend beyond this example routine.")


def _hex(text, maximum):
    if not isinstance(text, str) or len(text) > 3*maximum or not text.isascii():
        raise ValueError(f"Enter complete hexadecimal byte pairs, up to {maximum:,} bytes.")
    try:
        data = bytes.fromhex(text)
    except ValueError as error:
        raise ValueError("Enter complete hexadecimal byte pairs, such as 4D 5A.") from error
    if not 1 <= len(data) <= maximum:
        raise ValueError(f"Enter 1–{maximum:,} bytes in hexadecimal.")
    return data


def transform(data, operation, argument=""):
    if type(data) is not bytes or not 1 <= len(data) <= MAX_INPUT:
        raise ValueError(f"Transform inputs must contain 1–{MAX_INPUT:,} immutable bytes.")
    if operation == "XOR":
        key = _hex(argument, MAX_KEY)
        return bytes(value ^ key[i % len(key)] for i, value in enumerate(data))
    if operation == "Patch proposal":
        proposal = _hex(argument, len(data))
        if len(proposal) != len(data):
            raise ValueError(f"Supply exactly {len(data):,} replacement bytes for this range.")
        return proposal
    if operation in ("Shift left", "Shift right"):
        if not isinstance(argument, str) or len(argument) != 1 or argument not in "01234567":
            raise ValueError("Shift each unsigned byte by 0–7 bits.")
        n = int(argument)
        if operation == "Shift left":
            return bytes((value << n) & 255 for value in data)
        return bytes(value >> n for value in data)
    if operation == "Base64 encode":
        return base64.b64encode(data)
    if operation == "Base64 decode":
        try:
            encoded = b"".join(data.split())
            decoded = base64.b64decode(encoded, validate=True)
            if not encoded or base64.b64encode(decoded) != encoded:
                raise ValueError
            return decoded
        except ValueError as error:
            raise ValueError("Select canonical Base64, including required padding.") from error
    if operation == "From hex":
        if not data.isascii():
            raise ValueError("Select ASCII hexadecimal byte pairs in the source.")
        return _hex(data.decode("ascii"), MAX_INPUT)
    if operation == "zlib compress":
        return zlib.compress(data)
    if operation == "zlib decompress":
        inflater = zlib.decompressobj()
        try:
            result = inflater.decompress(data, MAX_OUTPUT+1)
        except zlib.error as error:
            raise ValueError("The bytes are not a valid zlib stream.") from error
        if len(result) > MAX_OUTPUT or inflater.unconsumed_tail:
            raise ValueError(f"Expanded output exceeds the {MAX_OUTPUT:,}-byte preview limit.")
        if not inflater.eof or inflater.unused_data:
            raise ValueError("Select one complete zlib stream, without trailing bytes.")
        return result
    raise ValueError("Choose a supported byte operation.")
