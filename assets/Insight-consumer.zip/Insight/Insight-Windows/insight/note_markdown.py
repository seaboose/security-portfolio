"""A bounded, native text preview. Only explicit local address references are actionable."""

import re
import tkinter as tk

from .appearance import AMBER, INK, MONO, MUTED, RIM, SELECTION, UI, UI_BOLD, UI_HEADING, UI_ITALIC, WELL


MAX_SOURCE = 16_000
ADDRESS = re.compile(r"(?<![\w@/])@(?P<relative>\+)?0[xX](?P<hex>[0-9a-fA-F]{1,8})(?![\w])")
PREFIX = re.compile(r"^(?:(#{1,6})\s+|([-*+]|\d{1,4}[.)])\s+)")
HTML_BLOCK = re.compile(r"^<(script|style|pre|code|iframe|object|template|textarea|div|table)\b", re.I)
INLINE = re.compile(
    r"(?P<code>`[^`\n]+`)|(?P<bold>\*\*[^*\n]+\*\*|__[^_\n]+__)|"
    r"(?P<em>\*[^*\n]+\*|(?<!\w)_[^_\n]+_(?!\w))|"
    r"(?P<literal>!?\[[^\[\]\n]*\]\([^\(\)\n]*\)|\b[A-Za-z][\w+.-]*:[^\s]+)")


def _references(text, tags):
    start = 0
    for match in ADDRESS.finditer(text):
        if start < match.start():
            yield text[start:match.start()], tags
        yield match[0], (*tags, "address")
        start = match.end()
    if start < len(text):
        yield text[start:], tags


def markdown(source):
    """Yield plain text and presentation tags, without interpreting HTML or destinations."""
    fence = ""
    html_end = ""
    for line in source[:MAX_SOURCE].splitlines(keepends=True):
        text = line.removesuffix("\n")
        marker = text.lstrip()
        if not fence:
            html = HTML_BLOCK.match(marker)
            if not html_end and marker.startswith("<!--"):
                html_end = "-->"
            elif not html_end and html and "/>" not in marker:
                html_end = f"</{html[1].lower()}>"
            if html_end:
                yield line, ()
                if html_end in marker.lower():
                    html_end = ""
                continue
        if marker.startswith(("```", "~~~")) and (not fence or marker.startswith(fence)):
            fence = "" if fence else marker[:3]
            continue
        if fence or text.startswith(("    ", "\t")):
            yield line, ("code",)
            continue
        if "<" in text and ">" in text:
            yield line, ()
            continue
        base = ()
        heading = PREFIX.match(text)
        if heading:
            text = text[heading.end():]
            if heading[1]:
                base = ("heading",)
            else:
                yield ("•" if heading[2] in ("*", "-", "+") else heading[2]) + "  ", ("list",)
                base = ("list",)
        pos = 0
        for match in INLINE.finditer(text):
            yield from _references(text[pos:match.start()], base)
            kind = match.lastgroup
            if kind == "literal":
                yield match[0], base
            elif kind == "code":
                yield match[0][1:-1], (*base, "code")
            else:
                cut = 2 if kind == "bold" else 1
                yield from _references(match[0][cut:-cut], (*base, kind))
            pos = match.end()
        yield from _references(text[pos:], base)
        if line.endswith("\n"):
            yield "\n", base


class MarkdownPreview(tk.Text):
    def __init__(self, parent, follow):
        super().__init__(parent, height=3, wrap="word", background=WELL, foreground=INK,
                         relief="flat", borderwidth=0, padx=6, pady=4, takefocus=True,
                         selectbackground=SELECTION, highlightthickness=1, highlightbackground=RIM,
                         highlightcolor=AMBER, font=UI, state="disabled")
        self.follow = follow
        self.scope = None
        self.links = []
        self.current = -1
        self.tag_configure("heading", font=UI_HEADING, spacing1=2)
        self.tag_configure("bold", font=UI_BOLD)
        self.tag_configure("em", font=UI_ITALIC)
        self.tag_configure("code", font=MONO, background="#211f20")
        self.tag_configure("list", lmargin2=13)
        self.tag_configure("address", foreground=AMBER, underline=True)
        self.tag_configure("active", background=SELECTION)
        self.tag_configure("limit", foreground=MUTED)
        self.tag_bind("address", "<ButtonRelease-1>", self._click)
        self.tag_bind("address", "<Enter>", lambda _: self.configure(cursor="hand2"))
        self.tag_bind("address", "<Leave>", lambda _: self.configure(cursor=""))
        self.bind("<Tab>", lambda _: self._step(1))
        self.bind("<Shift-Tab>", lambda _: self._step(-1))
        if self.tk.call("tk", "windowingsystem") == "x11":
            self.bind("<ISO_Left_Tab>", lambda _: self._step(-1))
        self.bind("<Return>", self._activate)

    def render(self, source, scope):
        self.configure(state="normal")
        self.delete("1.0", "end")
        self.links.clear()
        self.current, self.scope = -1, scope
        for text, tags in markdown(source):
            # Preserve the authoring source while making bidi controls and other
            # invisible formatting visible beside interactive address references.
            if not text.isprintable():
                text = "".join(c if c.isprintable() or c in "\n\t" else f"\\u{ord(c):04X}" for c in text)
            start = self.index("end-1c") if "address" in tags else None
            self.insert("end", text, tags)
            if start is not None:
                self.links.append((start, self.index("end-1c"), text))
        if len(source) > MAX_SOURCE:
            self.insert("end", "\nPreview ends at 16,000 characters.", "limit")
        self.configure(state="disabled")

    def _step(self, delta):
        n = self.current + delta if self.current >= 0 else (0 if delta == 1 else len(self.links)-1)
        if 0 <= n < len(self.links):
            self._select(n)
        else:
            self.current = -1
            self.tag_remove("active", "1.0", "end")
            (self.tk_focusNext() if delta == 1 else self.tk_focusPrev()).focus_set()
        return "break"

    def _select(self, n):
        self.current = n
        start, end, _ = self.links[n]
        self.tag_remove("active", "1.0", "end")
        self.tag_add("active", start, end)
        self.see(start)

    def _click(self, event):
        at = self.index(f"@{event.x},{event.y}")
        for n, (start, end, _) in enumerate(self.links):
            if self.compare(start, "<=", at) and self.compare(at, "<", end):
                self._select(n)
                self._activate()
                break
        return "break"

    def _activate(self, _=None):
        if 0 <= self.current < len(self.links):
            match = ADDRESS.fullmatch(self.links[self.current][2])
            self.follow(self.scope, int(match["hex"], 16), bool(match["relative"]))
        return "break"
