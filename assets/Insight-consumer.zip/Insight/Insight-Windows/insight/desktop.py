"""Open the native workbench and verify the packaged cooldown evidence."""

from hashlib import sha256
import os
import re

from .cooldown import ASSET_DIR, CASE_DIR, OBJECT_FILES
from .records import read_document, snapshot
from .replay import replay


LISTINGS = {
    "plain": ("listing0.txt",
              "902f6728232af9d3e5b5e772ab14650e46ec9ba5773eb45cda17b1b969c324b0",
              "4e698047e100cc4ec08ffeec52507a5b56a6f5378f1938bb6da2df0ecec7cad4"),
    "encoded": ("listing1.txt",
                "a85c1f82779503c09f84ba7c31994fc67a8684f1878ffaec37cece96cc4d9b11",
                "7771e96762bb2d47a8dbb91a7c1ef0e6a50da670716d50a1d7ea667d8d07a6b0"),
}
INSTRUCTION = re.compile(r"([0-9A-F]{16}): ([0-9A-F ]+?) {2,}([a-z][a-z0-9]*)\s*(.*)")


def functions_for(build, object_hash):
    filename, fingerprint, original_object = LISTINGS[build]
    if object_hash != original_object:
        raise ValueError(f"{build} listing targets a different object")
    data = snapshot(ASSET_DIR / filename)
    if sha256(data).hexdigest() != fingerprint:
        raise ValueError(f"{build} listing fingerprint mismatch")
    functions = {}
    rows = None
    for line in data.decode("ascii").splitlines():
        line = line.strip()
        if line in ("main:", "ready:"):
            rows = functions[line[:-1]] = []
        elif line == "Summary":
            break
        elif rows is not None and line:
            match = INSTRUCTION.fullmatch(line)
            if match:
                at, raw, op, args = match.groups()
                rows.append({"at": int(at, 16), "bytes": raw, "op": op, "args": args})
            else:
                # dumpbin wraps the final bytes of long instructions onto a second line.
                bytes.fromhex(line)
                rows[-1]["bytes"] += " " + line
    return functions


def case_data():
    report = replay(CASE_DIR / "runs.json")
    manifest = snapshot(CASE_DIR / "case.json")
    if sha256(manifest).hexdigest() != report["case_sha256"]:
        raise ValueError("case changed during replay")
    bindings = read_document(manifest)["builds"]
    builds = {}
    for build, object_name in OBJECT_FILES.items():
        binding = bindings[build]
        functions = functions_for(build, binding["object_sha256"])
        hashes = {}
        for name, rows in functions.items():
            code = bytes.fromhex(" ".join(row["bytes"] for row in rows))
            hashes[name] = sha256(code).hexdigest()
        if hashes["ready"] != binding["range_sha256"]:
            raise ValueError(f"{build} listing differs from the verified routine")
        builds[build] = {"object": object_name, "sha256": binding["object_sha256"],
                         "rangeSha256": binding["range_sha256"], "functionHashes": hashes,
                         "functions": functions}
    return {"report": report, "builds": builds}


def launch(initial=None):
    from .native import launch as open_window

    if os.name != "nt":
        raise ValueError("The desktop application requires Windows.")
    open_window(initial)
