"""Match a single, explicit Windows process observation to the current file evidence."""

from dataclasses import dataclass
import json
import os
from pathlib import Path
import subprocess
import sys
from time import monotonic

from .pe import MAX_ROUTINE_BYTES


@dataclass(frozen=True)
class ThreadObservation:
    tid: int
    captured_at: str
    registers: dict
    pointers: dict
    rva: int | None
    raw: bytes
    status: str
    memory: bytes
    file_raw: bytes
    memory_at: str


@dataclass(frozen=True)
class Observation:
    digest: str
    pid: int
    process_start: int
    module_base: int
    module_path: str
    captured_at: str
    debugger_attached: bool
    threads: tuple
    provider: str = "Windows Process Snapshotting"


def _cancelled(cancel):
    if cancel is not None and cancel.is_set():
        raise ValueError("Runtime capture cancelled.")


def _sample(source, digest, pid, cancel):
    worker = Path(__file__).with_name("runtime_win32.py").resolve()
    command = [sys.executable, "-I", "-S", "-B", str(worker), str(pid), digest, source]
    with subprocess.Popen(command, cwd=worker.parent, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE,
                          stderr=subprocess.DEVNULL, creationflags=subprocess.CREATE_NO_WINDOW) as process:
        deadline = monotonic() + 8
        try:
            while True:
                _cancelled(cancel)
                if monotonic() >= deadline:
                    raise ValueError("The runtime capture exceeded eight seconds. The observation was discarded.")
                try:
                    raw, _ = process.communicate(timeout=.08)
                    break
                except subprocess.TimeoutExpired:
                    pass
        finally:
            if process.poll() is None:
                process.kill()
                process.communicate()
    if process.returncode or not raw or len(raw) > 512 * 1024:
        raise ValueError("The isolated Windows capture did not return a complete observation.")
    result = json.loads(raw)
    if "error" in result:
        raise ValueError(result["error"])
    return result


def capture(case, pid, rows, cancel=None, *, previous=None):
    """Capture registers once. Only byte-identical, decoded instruction starts become links."""
    _cancelled(cancel)
    if type(pid) is not int or not 0 < pid < 2**32:
        raise ValueError("Enter the numeric process ID of the Windows x64 target.")
    if os.name != "nt" or case is None or case.image is None:
        raise ValueError("Open a native x64 DLL on Windows first.")
    if previous and (previous.digest != case.digest or previous.pid != pid):
        raise ValueError("This observation belongs to another build or process. Reconnect explicitly.")
    if len(rows) > MAX_ROUTINE_BYTES:
        raise ValueError("The instruction listing exceeds the capture limit.")
    starts = {row.rva: row for row in rows}
    sample = _sample(str(case.source), case.digest, pid, cancel)
    _cancelled(cancel)
    base, size = sample["base"], sample["size"]
    if previous and (previous.process_start != sample["created"] or previous.module_base != base):
        raise ValueError("The process instance or module base changed. Reconnect explicitly.")
    threads = []
    for item in sample["threads"]:
        registers = item["registers"]
        ip = registers.get("RIP", 0)
        rva = ip-base if base <= ip < base+size else None
        pointers = {k: v-base for k, v in registers.items() if k != "EFLAGS" and base <= v < base+size}
        raw, file_raw, status = b"", b"", item["status"]
        row = starts.get(rva)
        memory = bytes.fromhex(item["memory"])
        if row and 0 < len(row.raw) <= 15:
            try:
                offset = case.image.offset(rva, len(row.raw))
                file_raw = case.data[offset:offset+len(row.raw)]
            except ValueError:
                pass
            memory = memory[:len(row.raw)]
        if not status and row is None:
            status = ("Outside the verified module." if rva is None else
                      "The captured RIP is outside the displayed instruction starts.")
        elif not status:
            if file_raw and row.raw == file_raw == memory and row.flow != "invalid":
                raw, status = row.raw, "Captured RIP and observed memory match the file instruction."
            else:
                status = "Live bytes differ, are unavailable, or the listing has no verified instruction."
        threads.append(ThreadObservation(item["tid"], item["time"], registers, pointers, rva, raw,
                                         status, memory, file_raw, item["memory_at"]))
    return Observation(case.digest, pid, sample["created"], base, sample["path"], sample["time"],
                       sample["debugger"], tuple(threads))
