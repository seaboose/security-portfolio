"""Connect saved workspace choices to the live investigation and its evidence."""

from tkinter import ttk

from . import dialogs
from .appearance import MONO, MUTED
from .palette import scan_strings
from .triage_overview import TriageOverview
from .workspace_evidence import string_sites
from .workspace_settings import DEFAULTS, PRESETS
from .xrefs import read_imports


class PersonalWorkspace:
    def __init__(self, app):
        self.app = app
        self.saved = app.preferences.load()
        self.preset = self.saved["preset"]
        self.snapshot_job = None
        self.index_timer = None
        self.dock_baseline = {}
        self.overview = TriageOverview(app.views.reader, self.references)
        self.mini = ttk.Frame(app.views.graph)
        self.mini.columnconfigure(0, weight=1)
        self.instruction = ttk.Label(self.mini, font=MONO)
        self.instruction.grid(row=0, column=0, sticky="ew")
        self.detail = ttk.Label(self.mini, foreground=MUTED)
        self.detail.grid(row=1, column=0, sticky="ew")
        self.detail.bind("<Configure>", lambda e:self.detail.configure(wraplength=max(100,e.width-4)))
        ttk.Button(self.mini, text="Inspector", command=app.xrefs.open_context).grid(row=0,column=1,rowspan=2)
        self.restore_view = True

    def bind(self, case):
        app = self.app
        self.overview.clear(case)
        app.views.image, app.views.strings = case.image, ()
        self.cancel_index()
        if case.image:
            self.snapshot_job = app.pool.submit(self._index, case)
            self.index_timer = app.root.after(45, self._finish_index, case, self.snapshot_job)

    def cancel_index(self):
        if self.index_timer is not None:
            self.app.root.after_cancel(self.index_timer)
            self.index_timer = None
        if self.snapshot_job is not None:
            self.snapshot_job.cancel()
            self.snapshot_job = None

    @staticmethod
    def _index(case):
        strings, coverage = getattr(case, "_palette_strings", None) or scan_strings(case.image)
        try:
            imports, missing = read_imports(case.image)
            message = f"{len(imports)} named import slots"
            if missing:
                message += f" · {missing} unavailable"
        except ValueError as error:
            imports, message = {}, str(error)
        return strings, coverage, tuple(imports.values()), message

    def _finish_index(self, case, future):
        app = self.app
        self.index_timer = None
        if future is not self.snapshot_job or app.case is not case:
            return
        if not future.done():
            self.index_timer = app.root.after(50, self._finish_index, case, future)
            return
        self.snapshot_job = None
        try:
            strings, scope, imports, import_scope = future.result()
        except (OSError, ValueError) as error:
            self.overview.load(case, (), (), f"Index unavailable · {error}")
            return
        case._palette_strings = strings, scope
        app.views.strings = strings
        app.views.string_refs = string_sites(app.rows, strings)
        app.views._iris_ticks()
        self.overview.load(case, strings, imports, f"{scope} · {import_scope}")

    def references(self, case, kind, entry):
        app = self.app
        if app.case is not case or not case.image or self.overview.selected() is not entry:
            return
        if kind == "Strings":
            case.image.offset(entry.rva, entry.size)
            app.xrefs.open_global(entry.rva, entry.size)
        else:
            case.image.offset(entry.iat_rva, 8)
            app.xrefs.matrix.for_import(entry)
            app.xrefs.open()

    def apply(self, preset, *, store=True, recover=True):
        if preset not in PRESETS:
            return
        app, views = self.app, self.app.views
        if store:
            app.preferences.update(preset=preset)
        self.preset = preset
        app.preset_name.set(preset)
        app.xrefs.hide_context()
        if app.xrefs.visible:
            app.xrefs.hide()
        app.docks.graph(preset=="Graph")
        app.docks.deep(preset=="Deep decompilation")
        if preset=="Graph":
            views.reader.select(views.graph)
            self.mini.grid(row=5,column=0,columnspan=2,sticky="ew")
            self.cursor()
        else:
            self.mini.grid_remove()
        if preset=="Triage":
            views.reader.add(self.overview, text="Triage overview")
            if views.compact:
                views._layout(1)
            views.reader.select(self.overview)
        elif str(self.overview) in views.reader.tabs():
            views.reader.hide(self.overview)
        if preset=="Deep decompilation" and app.case and app.case.image:
            if recover:
                app.decompile_current()
            else:
                views.show_pseudocode()
        elif preset=="Investigation":
            views.reader.select(views.reading)

    def opened(self):
        if self.restore_view:
            self.restore_view = False
            self.apply(self.preset, store=False, recover=False)
            self.restore_reader(self.saved)
        else:
            self.apply(self.preset, store=False)

    def restore_reader(self, settings):
        app, views = self.app, self.app.views
        reader = views.reader
        title = settings["reader_tab"]
        inspect = settings["inspector_open"] and self.preset in ("Investigation", "Triage")
        needs_analysis = (title in ("Ghidra pseudocode", "Stack Frame", "Struct Layout")
                          or self.preset == "Deep decompilation")
        want_structure = title == "Struct Layout" and str(views.struct) not in reader.tabs()
        if want_structure:
            title = "Stack Frame"
        for tab in reader.tabs():
            if reader.tab(tab, "state") == "normal" and reader.tab(tab, "text") == title:
                reader.select(tab)
                break
        selected = reader.select()
        def finish():
            if reader.select() != selected:
                return
            if want_structure and str(views.struct) in reader.tabs():
                reader.select(views.struct)
            if inspect:
                app.xrefs.open_context()
        if needs_analysis and app.case and app.case.image:
            app.decompile_current(reveal=False, after=finish)
        else:
            finish()

    def cursor(self):
        app = self.app
        if self.preset == "Graph" and app.rows:
            row = app.rows[app.index]
            self.instruction.configure(text=f"{app.views._address(row.rva)}   {row.raw.hex(' ').upper()}")
            graph = app.views.flow_graph
            block = graph.blocks[graph.block_at(app.index)]
            start = app.rows[block.first].rva
            self.detail.configure(text=f"{row.op} {row.args}  ·  block {app.views._address(start)}  ·  "
                                       f"{block.stop-block.first} instructions  ·  {app.routine.extent}")

    def save(self):
        current = self.app.docks.capture()
        changes = {k:v for k,v in current.items() if k in DEFAULTS and self.dock_baseline.get(k)!=v}
        if changes:
            self.app.preferences.update(**changes)
        self.dock_baseline = current

    def save_named(self):
        app = self.app
        name = dialogs.input_value(app.root, "Save workspace layout", "Layout name", "Save layout")
        if not name:
            return
        if app.preferences.layout_exists(name) and not dialogs.confirm(app.root, "Replace saved layout",
                f"Replace the saved pane positions for {name}?", "Replace layout", "Keep existing"):
            return
        app.preferences.save_layout(name, dict(app.docks.capture(), preset=self.preset))
        app.status.set(f"Workspace layout saved · {name}")

    def restore_named(self, name):
        app = self.app
        layout = app.preferences.get_layout(name)
        settings = app.preferences.update(**layout)
        self.apply(settings["preset"], store=False, recover=False)
        app.docks.apply(settings, restore_main=True, restore_inspector=False)
        self.restore_reader(settings)
        self.dock_baseline = app.docks.capture()
        app.status.set(f"Workspace layout restored · {name}")

    def forget_named(self, name):
        app = self.app
        if dialogs.confirm(app.root, "Forget saved layout", f"Remove {name} from saved workspace layouts?",
                           "Forget layout", "Keep layout"):
            app.preferences.delete_layout(name)
