"""Review analyst-authored reasoning beside verified evidence before approval."""

import tkinter as tk
from tkinter import ttk

from .appearance import AMBER, INK, MONO, SELECTION, UI, WELL, scrollable
from .dialogs import Prompt
from .findings import serialize_record


def _text(parent, value, *, readonly=True, height=4, code=False):
    frame = ttk.Frame(parent)
    widget = tk.Text(frame, height=height,width=25,font=MONO if code else UI,wrap="word",
                     background=WELL,foreground=INK,insertbackground=AMBER,selectbackground=SELECTION)
    scrollable(frame,widget)
    widget.insert("1.0",value)
    if readonly:
        widget.configure(state="disabled")
    return frame,widget


def review_finding(parent, record, approve, export, navigate):
    revision = record["revision"]
    frozen = bool(revision["approved"])
    view = Prompt(parent,"Review finding")
    view.resizable(True,True)
    view.body.columnconfigure(0, weight=1)
    view.body.rowconfigure(1, weight=1)
    heading = ttk.Label(view.body, text=f"{record['artifact']} · revision {revision['number']} · "
                        f"{'approved' if frozen else 'awaiting approval'}\nSHA-256 {record['sha256']}",font=MONO)
    heading.grid(row=0,column=0,sticky="ew",pady=(0,5))
    heading.bind("<Configure>",lambda e:heading.configure(wraplength=max(100,e.width-4)))
    book = ttk.Notebook(view.body, style="Insight.TNotebook")
    book.grid(row=1,column=0,sticky="nsew")
    book.enable_traversal()
    text = revision["body"]
    prediction = record["prediction"]
    reasoning, _ = _text(book, "Recorded prediction\n"+
                         (f"{prediction['recorded']}\n{prediction['body']}" if prediction else "Unrecorded.")+
                         "\n\nAnalyst interpretation\n"+text)
    book.add(reasoning,text="Finding")
    evidence = ttk.Frame(book,padding=3)
    book.add(evidence,text="Citations")
    ttk.Label(evidence,text="Verified bytes · "+record["coordinate"],font=MONO).pack(anchor="w")
    evidence_view = ttk.Frame(evidence)
    evidence_view.pack(fill="both",expand=True)
    table = ttk.Treeview(evidence_view,columns=("at","raw","key"),show="headings",height=5,style="Insight.Treeview")
    for key,label,width in (("at","Address",92),("raw","Exact bytes",240),("key","Routine",100)):
        table.heading(key,text=label,anchor="w")
        table.column(key,width=width,minwidth=65,stretch=key=="raw")
    for i,item in enumerate(record["citations"]):
        table.insert("","end",iid=str(i),values=(f"0x{item['address']:X}",item["bytes"],item["routine"]))
    scrollable(evidence_view,table)
    table.selection_set("0")
    def follow():
        if table.selection():
            item = record["citations"][int(table.selection()[0])]
            view.finish()
            navigate(item["routine"],item["address"],bytes.fromhex(item["bytes"]))
    ttk.Button(evidence,text="Go to cited instruction",command=follow).pack(anchor="e")
    table.bind("<Return>",lambda _:follow())
    support = ttk.Frame(book,padding=4)
    support.columnconfigure(0, weight=1)
    book.add(support,text="Tests and limits")
    entries = []
    for i,(key,label) in enumerate((("tests","Analyst-reported tests"),("limitations","Limitations and open questions"))):
        ttk.Label(support,text=label).grid(row=i*2,column=0,sticky="w")
        frame, entry = _text(support,record[key],readonly=frozen,height=2)
        frame.grid(row=i*2+1,column=0,sticky="nsew")
        support.rowconfigure(i*2+1,weight=1)
        entries.append(entry)
    history = "\n".join(f"Revision {r['number']} · saved {r['created']} · "
                        f"{'approved '+r['approved'] if r['approved'] else 'unapproved'}"
                        for r in record["history"])
    log,_ = _text(book,history,code=True)
    book.add(log,text="History")
    if frozen:
        for format in ("md","json"):
            page,_ = _text(book,serialize_record(record,format),code=True)
            book.add(page,text="Markdown" if format=="md" else "JSON")
    feedback = ttk.Label(view.body,foreground=AMBER)
    feedback.grid(row=2,column=0,sticky="ew")
    def finish():
        if frozen:
            export()
        else:
            try:
                approve(*(e.get("1.0","end-1c") for e in entries))
            except ValueError as error:
                feedback.configure(text=str(error))
                return
        view.finish()
    view.geometry(f"{min(760,max(360,parent.winfo_screenwidth()-85))}x"
                  f"{min(500,max(280,parent.winfo_screenheight()-110))}")
    return view.show(finish,"Export…" if frozen else "Approve revision",focus=book,cancel="Close")
