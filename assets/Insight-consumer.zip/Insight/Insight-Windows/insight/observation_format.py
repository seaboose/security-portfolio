"""Portable validation for a normalized Surge range attached to an Insight finding."""

from datetime import datetime
import re


SCHEMAS = ("native-code-range-v1", "surge-native-integrity-v1")

FIELDS = {"schema","module_sha256","rva","size","reference_hex","observed_hex","read_mask","memory_status",
          "captured_at","session_id","pid","range_name","phase","source_sha256"}


def _hash(value):
    return isinstance(value, str) and re.fullmatch(r"[0-9a-f]{64}", value) is not None


def _text(value):
    return isinstance(value, str) and 0 < len(value) <= 128 and value.isprintable()


def validate_saved_observation(record):
    if not isinstance(record, dict) or set(record) != FIELDS or record["schema"] not in SCHEMAS:
        raise ValueError("Unsupported Surge observation format.")
    size, rva, pid = record["size"], record["rva"], record["pid"]
    if (type(size) is not int or not 1 <= size <= 64 or type(rva) is not int or not 0 < rva < 512*1024**2
            or type(pid) is not int or not 0 < pid < 2**32 or not _hash(record["module_sha256"])
            or not _hash(record["source_sha256"]) or
            any(not _text(record[k]) for k in ("captured_at","session_id","phase","range_name"))):
        raise ValueError("Invalid Surge observation identity, range or timestamp.")
    try:
        captured = datetime.fromisoformat(record["captured_at"])
    except ValueError as error:
        raise ValueError("The observation needs an ISO timestamp with a time zone.") from error
    if captured.utcoffset() is None:
        raise ValueError("The observation needs an ISO timestamp with a time zone.")
    def exact_hex(value):
        return isinstance(value,str) and len(value) == size*2 and re.fullmatch("[0-9a-f]+", value)
    if not exact_hex(record["reference_hex"]):
        raise ValueError("The reference bytes do not match the stated range.")
    complete = record["memory_status"] == "complete"
    if (record["memory_status"] not in ("complete","failed","not_loaded") or
            record["read_mask"] != ("1" if complete else "0")*size or
            (not exact_hex(record["observed_hex"]) if complete else record["observed_hex"] != "")):
        raise ValueError("Surge read coverage and reported capture bytes disagree.")
    return record
