"""Portable finding schema and rendering. All inputs are serialized evidence values."""

from datetime import datetime
from hashlib import sha256
import json
import re


MAX_CITATIONS = 32
MAX_HISTORY = 256
PROVENANCE = {"module_rva":"PE file bytes", "routine_relative":"Verified packaged listing"}


def _canonical(record):
    return json.dumps(record, ensure_ascii=False, sort_keys=True, separators=(",",":"), allow_nan=False).encode("utf-8")


def _hash(data):
    return sha256(data).hexdigest()


def _text(value, limit, *, empty=False):
    if (not isinstance(value, str) or len(value)>limit or (not empty and not value.strip())
            or any(ord(c)<32 and c not in "\r\n\t" or 0xD800<=ord(c)<=0xDFFF for c in value)):
        raise ValueError("Finding contains missing, oversized or invalid text.")
    return value


def _shape(record, names):
    if type(record) is not dict or set(record)!=set(names.split()):
        raise ValueError("Finding fields do not match the versioned record.")


def _digest(value):
    if not isinstance(value,str) or not re.fullmatch(r"[0-9a-f]{64}",value):
        raise ValueError("Invalid SHA-256 in finding.")


def _timestamp(value):
    _text(value,48)
    stamp = datetime.fromisoformat(value)
    if stamp.utcoffset() is None:
        raise ValueError("A finding timestamp must identify a time zone.")
    return stamp


def _identity(record):
    first = record["history"][0]
    anchor = record["citations"][0]
    return _hash(_canonical([record["sha256"], record["routine"], anchor["address"], anchor["sha256"],
                             first["created"],first["body_sha256"]]))


def validate_envelope(record):
    """Verify schema, source/range hashes, selected revision and internal integrity."""
    _shape(record,"schema version finding_id artifact sha256 coordinate routine citations prediction revision "
                  "tests limitations history surge_observation record_sha256")
    if record["schema"]!="insight.finding" or type(record["version"]) is not int or record["version"]!=2:
        raise ValueError("Unsupported finding format.")
    for key in ("sha256","finding_id","record_sha256"):
        _digest(record[key])
    for key in ("artifact","routine"):
        _text(record[key],256)
    mode = record["coordinate"]
    if mode not in ("module_rva","routine_relative"):
        raise ValueError("Unknown coordinate system.")
    rev, history, citations = record["revision"],record["history"],record["citations"]
    _shape(rev,"number body created approved")
    _text(rev["body"],16000)
    if (type(rev["number"]) is not int or type(history) is not list or
            not 1 <= len(history) == rev["number"] <= MAX_HISTORY):
        raise ValueError("Incomplete revision history.")
    previous = None
    for number,item in enumerate(history,1):
        _shape(item,"number body_sha256 created approved")
        if type(item["number"]) is not int or item["number"]!=number:
            raise ValueError("Revision numbers must be consecutive.")
        _digest(item["body_sha256"])
        made = _timestamp(item["created"])
        if previous and made<previous or item["approved"] is not None and _timestamp(item["approved"])<made:
            raise ValueError("Revision timestamps are out of order.")
        previous = made
    final = history[-1]
    if (not rev["approved"] or rev["approved"]!=final["approved"] or rev["created"]!=final["created"]
            or _hash(rev["body"].encode("utf-8"))!=final["body_sha256"]):
        raise ValueError("Selected interpretation does not match its approved revision.")
    if type(citations) is not list or not 1 <= len(citations) <= MAX_CITATIONS:
        raise ValueError("A finding must have 1–32 verified citations.")
    seen = set()
    cited_bytes = {}
    for item in citations:
        _shape(item,"routine address size bytes sha256 provenance")
        _text(item["routine"],256)
        at, size, raw = item["address"],item["size"],item["bytes"]
        if (type(at) is not int or type(size) is not int or not 1 <= size <= 15
                or not 0 <= at < at+size <= 2**32 or not isinstance(raw,str)
                or len(raw)!=size*3-1 or not re.fullmatch(r"[0-9A-F]{2}(?: [0-9A-F]{2})*",raw)):
            raise ValueError("Invalid cited byte range.")
        _digest(item["sha256"])
        if (item["sha256"]!=_hash(bytes.fromhex(raw)) or item["provenance"]!=PROVENANCE[mode]
                or (item["routine"],at) in seen):
            raise ValueError("Cited bytes, provenance or range identity do not match.")
        seen.add((item["routine"],at))
        # PE addresses share one image. Relative addresses belong to one routine.
        space = None if mode == "module_rva" else item["routine"]
        for offset, byte in enumerate(bytes.fromhex(raw), at):
            if cited_bytes.setdefault((space, offset), byte) != byte:
                raise ValueError("Overlapping citations disagree on the same instruction bytes.")
    if citations[0]["routine"]!=record["routine"] or record["finding_id"]!=_identity(record):
        raise ValueError("Finding identity does not match its first revision and anchor.")
    for key in ("tests","limitations"):
        _text(record[key],2000,empty=True)
    pred = record["prediction"]
    if pred is not None:
        _shape(pred,"body recorded")
        _text(pred["body"],16000)
        if _timestamp(pred["recorded"])!=_timestamp(history[0]["created"]) or _hash(pred["body"].encode())!=history[0]["body_sha256"]:
            raise ValueError("The prediction must match the first saved revision.")
        if rev["number"]<2:
            raise ValueError("A prediction requires a later interpretation before approval.")
    if record["surge_observation"] is not None:
        from .observation_format import validate_saved_observation
        observation = validate_saved_observation(record["surge_observation"])
        anchor = citations[0]
        start = observation["rva"]
        reference = bytes.fromhex(observation["reference_hex"])
        if (observation["module_sha256"] != record["sha256"] or mode != "module_rva"
                or anchor["address"] >= start + len(reference)
                or anchor["address"] + anchor["size"] <= start
                or any(cited_bytes.get((None, offset), byte) != byte
                       for offset, byte in enumerate(reference, start))):
            raise ValueError("Attached observation disagrees with the finding's overlapping bytes.")
    if _hash(_canonical({k:v for k,v in record.items() if k!="record_sha256"}))!=record["record_sha256"]:
        raise ValueError("Finding record SHA-256 mismatch.")
    return record


def _literal(text):
    # Preserve personal prose exactly and stop raw HTML, links and embedded Markdown from activating.
    size = max((len(m[0]) for m in re.finditer(r"`+",text)), default=0)
    fence = "`"*max(3,size+1)
    return f"{fence}text\n{text}\n{fence}"


def serialize_record(record, format):
    validate_envelope(record)
    if format=="json":
        return json.dumps(record,indent=2,ensure_ascii=False)+"\n"
    if format!="md":
        raise ValueError("Choose Markdown or JSON.")
    rev, pred = record["revision"], record["prediction"]
    parts = ["# Insight finding", f"Format {record['schema']} v{record['version']}",
             f"Finding ID `{record['finding_id']}` · revision {rev['number']}",
             "## Artifact", _literal(record["artifact"]), f"SHA-256 `{record['sha256']}`",
             f"Coordinates `{record['coordinate']}`", "Pinned routine", _literal(record["routine"]),
             "## Recorded prediction", _literal(pred["body"]) if pred else "No separate prediction was recorded."]
    if pred:
        parts.append("Recorded "+pred["recorded"])
    parts += ["## Analyst interpretation", _literal(rev["body"]), "Saved "+rev["created"],
              "Approved "+rev["approved"], "## Verified instruction ranges"]
    for item in record["citations"]:
        parts.append(_literal(f"{item['provenance']} · routine {item['routine']} · 0x{item['address']:X} · "
                              f"{item['size']} bytes\n{item['bytes']}\nSHA-256 {item['sha256']}"))
    for title,key in (("Analyst-reported tests","tests"),("Limitations","limitations")):
        parts += ["## "+title,_literal(record[key]) if record[key] else "Unrecorded."]
    parts += ["## Attached observation"]
    parts.append(_literal(json.dumps(record["surge_observation"],indent=2,ensure_ascii=False))
                 if record["surge_observation"] else "None attached to this revision.")
    parts += ["## Revision history"]
    for item in record["history"]:
        parts.append(f"- Revision {item['number']} · saved {item['created']} · "
                     f"{'approved '+item['approved'] if item['approved'] else 'unapproved'} · body SHA-256 `{item['body_sha256']}`")
    parts += [f"Record SHA-256 `{record['record_sha256']}`"]
    return "\n\n".join(parts)+"\n"
