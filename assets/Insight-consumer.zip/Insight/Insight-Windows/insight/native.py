"""Native Windows investigation window. Only the selected range is decoded on demand."""

from collections import OrderedDict
from concurrent.futures import ThreadPoolExecutor
import ctypes
import os
from pathlib import Path
import sqlite3
from threading import Event
import tkinter as tk
from tkinter import ttk

from . import dialogs
from .analyst_edits import AnalystEdits
from .appearance import CRIMSON, LINE, MONO, MONO_TITLE, MUTED
from .breadcrumbs import Breadcrumbs
from .casebook import Casebook
from .diff_session import BinaryComparison
from .investigation import open_dll, open_example, reopen_case
from .layout_session import LayoutSession
from .native_notes import Notes
from .personal_workspace import PersonalWorkspace
from .views import LinkedViews
from .workbench_controls import WorkbenchControls
from .workspace_docks import WorkspaceDocks
from .workspace_settings import PRESETS, WorkspaceSettings
from .xref_navigation import CrossReferences


def default_folder():
    folder = os.environ.get("LOCALAPPDATA")
    if not folder or not Path(folder).is_absolute():
        raise ValueError("Windows local application storage is unavailable.")
    return Path(folder) / "Insight"


def prepare_window(root):
    root.title("Insight · Investigation")
    root.geometry("1130x800")
    root.minsize(650, 500)
    dialogs.apply_theme(root)
    root.iconbitmap(default=str(Path(__file__).with_name("dragon-eye.ico")))


class App:
    def __init__(self, root, folder, initial=None):
        self.root = root
        self.store = Casebook(folder)
        self.preferences = WorkspaceSettings(self.store)
        self.pool = ThreadPoolExecutor(max_workers=1, thread_name_prefix="snapshot")
        self.pending = None
        self.work_timer = None
        self.on_cancel = None
        self.decompiling = False
        self.decompiled = OrderedDict()
        self.case = self.routine = None
        self.rows, self.trail, self.step, self.index = [], [], -1, 0
        self.status = tk.StringVar(value="Choose an x64 DLL to begin a read-only investigation.")
        self.artifact = tk.StringVar(value="No artifact open")
        self.cursor = tk.StringVar(value="")
        self.diff = BinaryComparison(self)
        self.edits = AnalystEdits(self)
        self.layouts = LayoutSession(self)
        header = ttk.Frame(root,padding=(10,5))
        header.pack(fill="x")
        ttk.Button(header,text="Open DLL…",command=self.pick_dll).pack(side="left")
        ttk.Button(header,text="Recent cases…",command=self.recent).pack(side="left",padx=3)
        self.diff_button = ttk.Button(header, text="Compare builds…", command=self.diff.pick)
        self.diff_button.pack(side="left", padx=(0, 3))
        self.back = ttk.Button(header,text="←",width=3,command=lambda: self.visit(-1))
        self.forward = ttk.Button(header,text="→",width=3,command=lambda: self.visit(1))
        self.back.pack(side="left")
        self.forward.pack(side="left")
        ttk.Button(header,text="Find / Go to…",command=self.jump).pack(side="right")
        ttk.Label(header,textvariable=self.cursor,foreground="#ffb5be",font=MONO).pack(side="right",padx=5)
        ttk.Label(header,textvariable=self.artifact,font=MONO_TITLE, width=1).pack(
            side="left", padx=8, fill="x", expand=True)
        scope = ttk.Frame(root,padding=(10,3))
        scope.pack(fill="x")
        scope.columnconfigure(1, weight=1)
        tools = ttk.Frame(scope)
        self.xref_button = ttk.Button(tools, text="XREF matrix…", command=lambda: self.xrefs.open())
        self.xref_button.pack(side="right")
        self.xref_button.state(["disabled"])
        self.inspector_button = ttk.Button(tools, text="Inspector", command=lambda: self.xrefs.open_context())
        self.inspector_button.pack(side="right", padx=(0, 3))
        self.inspector_button.state(["disabled"])
        self.xref_back = ttk.Button(tools, command=lambda: self.xrefs.back())
        self.cancel = ttk.Button(tools,text="Cancel",command=self.cancel_work)
        ttk.Label(scope,text="Routine").grid(row=0, column=0, sticky="w")
        self.routine_box = ttk.Combobox(scope,state="readonly",width=1)
        self.routine_box.grid(row=0, column=1, sticky="ew", padx=6)
        self.routine_box.bind("<<ComboboxSelected>>", self.pick_routine)
        self.scope = ttk.Label(scope,foreground="#b2a9ad")
        def fit_scope(_event):
            width = scope.winfo_width()
            compact = width < self.root.winfo_fpixels("8.5i")
            self.scope.grid(row=0, column=2, sticky="w", padx=(0, 6))
            tools.grid(row=int(compact), column=0 if compact else 3,
                       columnspan=3 if compact else 1, sticky="e")
            self.scope.configure(wraplength=max(100, width//(2 if compact else 4)))
        scope.bind("<Configure>", fit_scope)
        self.breadcrumbs = Breadcrumbs(root, self.visit_location)
        self.breadcrumbs.function_name = self.edits.function_name
        self.breadcrumbs.pack(fill="x", padx=10)
        ttk.Separator(root).pack(fill="x", pady=(1, 0))
        self.cancel.pack(side="right")
        bottom = ttk.Frame(root,padding=(10,3))
        bottom.pack(side="bottom",fill="x")
        status_label = ttk.Label(bottom,textvariable=self.status)
        bottom.columnconfigure(0, weight=1)
        status_label.grid(row=0, column=0, sticky="ew")
        status_label.bind("<Configure>", lambda e: status_label.configure(wraplength=max(120, e.width-4)))
        self.telemetry = ttk.Label(bottom, font=MONO, foreground=MUTED)
        self.telemetry.grid(row=0, column=2, sticky="e", padx=(4,0))
        self.pulse_job = None
        self.dock = tk.PanedWindow(root,orient="vertical",background=LINE,sashwidth=5,
                                   sashrelief="flat",borderwidth=0)
        self.dock.pack(fill="both",expand=True)
        self.views = LinkedViews(self.dock,self.select,self.follow)
        self.views.pseudo.symbol_overlays = self.edits.symbol_overlays
        self.views.on_stack_labels = self.edits.stack_names
        self.views.on_layout_slot = self.layouts.show
        self.views.stack_regions = self.layouts.project
        self.views.stack.on_define = self.layouts.define_region
        self.views.stack.on_remove_region = self.layouts.remove_region
        self.views.struct.on_edit = self.layouts.edit
        self.views.struct.on_reset = self.layouts.reset
        self.views.struct.on_revisions = self.layouts.revisions
        self.views.configure_decompiler(self.decompile_current, self.cancel_work)
        self.xrefs = CrossReferences(self)
        self.xrefs.context.function_name = self.edits.function_name
        self.xrefs.matrix.function_name = self.edits.function_name
        self.dock.add(self.views, minsize=180,stretch="always")
        self.notes = Notes(self.dock, self.store, self.citation, self.open_citation, self.status.set,
                           follow_address=self.follow_note_address)
        self.dock.add(self.notes,minsize=150,stretch="never")
        self.notes_toggle = ttk.Button(bottom, command=self.toggle_notes)
        self.short_dock = False
        self.personal = PersonalWorkspace(self)
        self.observation_window = None
        self.evidence_menu = tk.Menu(root, tearoff=False)
        self.views.listing.bind("<Button-3>", self.instruction_menu)
        self.views.hex.bind("<Button-3>", self.byte_menu)
        actions = dict(open=self.pick_dll, palette=self.jump, goto=self.jump, decompile=self.decompile_current,
                       diff=self.diff.pick, xrefs=self.xrefs.open, save_note=self.notes.save,
                       back=lambda:self.visit(-1), forward=lambda:self.visit(1),
                       rename=lambda:self.edits.edit("name"), retype=lambda:self.edits.edit("type"))
        self.controls = WorkbenchControls(root, self.preferences, actions, on_change=self.refresh_accelerators,
                                         note_editor=self.notes.editor)
        self.docks = WorkspaceDocks(self, bind_window=self.controls.attach, unbind_window=self.controls.detach)
        self.menu()
        self.docks.apply(self.personal.saved, restore_main=True)
        self.personal.dock_baseline = {k:self.personal.saved[k] for k in self.docks.capture()}
        root.bind("<Configure>", self.fit_dock)
        self.docks.fit(root.winfo_height()>1 and root.winfo_height()<root.winfo_fpixels("5.5i"))
        self.update_nav()
        self.cancel.pack_forget()
        root.protocol("WM_DELETE_WINDOW",self.close)
        root.report_callback_exception = self.callback_error
        if initial:
            self.open_path(initial)
        elif self.store.last():
            self.resume(self.store.last()["digest"])
        else:
            self.example("encoded")

    def fit_dock(self, event):
        if event.widget is not self.root:
            return
        short = event.height < self.root.winfo_fpixels("5.5i")
        if short == self.short_dock:
            return
        self.docks.fit(short)

    def toggle_notes(self):
        self.docks.toggle_notes()

    def menu(self):
        bar = tk.Menu(self.root)
        files = tk.Menu(bar,tearoff=False)
        files.add_command(label="Open x64 DLL…", accelerator="Ctrl+O", command=self.pick_dll)
        files.add_command(label="Compare DLL builds…", accelerator="Ctrl+Shift+D", command=self.diff.pick)
        files.add_command(label="Open Surge observation…", command=self.open_surge)
        files.add_command(label="Recent cases…", command=self.recent)
        for build in ("plain","encoded"):
            files.add_command(label="Explore example · "+build, command=lambda b=build:self.example(b))
        files.add_separator()
        files.add_command(label="Close",command=self.close)
        bar.add_cascade(label="File",menu=files)
        case = tk.Menu(bar,tearoff=False)
        case.add_command(label="Find / Go to…",accelerator="Ctrl+K",command=self.jump)
        case.add_command(label="Decompile routine",accelerator="F5",command=self.decompile_current)
        case.add_command(label="XREF matrix…",accelerator="Ctrl+Shift+X",command=lambda: self.xrefs.open())
        case.add_command(label="Context inspector",command=lambda: self.xrefs.open_context())
        case.add_command(label="Function triage…", command=self.edits.triage)
        case.add_command(label="Rename selected symbol…", accelerator="L", command=lambda: self.edits.edit("name"))
        case.add_command(label="Retype selected symbol…", accelerator="T", command=lambda: self.edits.edit("type"))
        case.add_command(label="Analysis history…", command=self.edits.history)
        case.add_command(label="Record prediction…", command=self.notes.record_prediction)
        case.add_command(label="Review finding…", command=self.notes.review)
        case.add_command(label="Artifact identity",command=self.identity)
        case.add_command(label="Example replay results",command=self.replay_results)
        case.add_command(label="Blind trials…", command=self.open_trials)
        bar.add_cascade(label="Investigation",menu=case)
        tools = tk.Menu(bar, tearoff=False)
        tools.add_command(label="Transform bytes…", command=self.transform_bytes)
        tools.add_command(label="Live observations…", command=self.live_observations)
        tools.add_command(label="Evidence scripts…", command=self.evidence_scripts)
        bar.add_cascade(label="Tools", menu=tools)
        workspace = tk.Menu(bar, tearoff=False)
        self.preset_name = tk.StringVar(self.root, value=self.personal.preset)
        for name in PRESETS:
            workspace.add_radiobutton(label=name, value=name, variable=self.preset_name,
                                      command=lambda n=name:self.personal.apply(n))
        workspace.add_separator()
        for orientation, title in (("horizontal","Side by side"), ("vertical","Stack vertically")):
            workspace.add_command(label=title, command=lambda o=orientation:self.docks.arrange(o,self.views.listing_first))
        workspace.add_command(label="Swap pane order", command=lambda:self.docks.arrange(
            str(self.views.split.cget("orient")), not self.views.listing_first))
        panes = tk.Menu(workspace,tearoff=False)
        def list_panes():
            panes.delete(0,"end")
            for pane, name in (("listing","Listing"), ("reader","Interpretation"), ("structure","Struct Layout"), ("notes","Analyst notes")):
                action = self.docks.redock if pane in self.docks.detached else self.docks.detach
                panes.add_command(label=("Dock " if pane in self.docks.detached else "Detach ")+name,
                                  command=lambda p=pane,fn=action:fn(p))
        panes.configure(postcommand=list_panes)
        workspace.add_cascade(label="Dock and detach",menu=panes)
        workspace.add_command(label="Show or hide analyst notes", command=self.toggle_notes)
        workspace.add_command(label="Save current layout…",command=self.personal.save_named)
        named = tk.Menu(workspace, tearoff=False)
        def list_saved():
            named.delete(0, "end")
            names = self.preferences.layouts()
            for label in names:
                named.add_command(label=label, command=lambda name=label:self.personal.restore_named(name))
            if names:
                named.add_separator()
                forget = self.saved_layout_removal
                forget.delete(0,"end")
                for label in names:
                    forget.add_command(label=label, command=lambda name=label:self.personal.forget_named(name))
                named.add_cascade(label="Forget layout", menu=forget)
            else:
                named.add_command(label="No saved layouts",state="disabled")
        self.saved_layout_removal = tk.Menu(named, tearoff=False)
        named.configure(postcommand=list_saved)
        workspace.add_cascade(label="Saved layouts",menu=named)
        workspace.add_command(label="Keyboard and text size…", command=self.controls.show)
        bar.add_cascade(label="Workspace",menu=workspace)
        self.menu_keys = {"open":(files,0),"diff":(files,1),"palette":(case,0),"decompile":(case,1),
                          "xrefs":(case,2),"rename":(case,5),"retype":(case,6)}
        self.refresh_accelerators()
        self.root.configure(menu=bar)

    def open_surge(self):
        from .surge_view import open_observation
        return open_observation(self)

    def open_trials(self):
        from .blind_view import open_blind
        return open_blind(self)

    def transform_bytes(self, operation=None, instruction=False):
        from .transform_view import open_transforms
        coords = None if instruction else self.views.selected_bytes()
        return open_transforms(self, *(coords or ()), operation=operation)

    def evidence_scripts(self):
        from .script_view import open_scripts
        return open_scripts(self)

    def live_observations(self):
        from .runtime_view import open_observations
        return open_observations(self)

    def instruction_menu(self, event):
        item = self.views.listing.identify_row(event.y)
        if item and self.case:
            self.select(int(item))
            self.byte_menu(event, instruction=True)
        return "break"

    def byte_menu(self, event, instruction=False):
        if self.case:
            menu = self.evidence_menu
            menu.delete(0,"end")
            menu.add_command(label="Transform instruction bytes…" if instruction else "Transform bytes…",
                             command=lambda:self.transform_bytes(instruction=instruction))
            for text, operation in (("XOR with key…", "XOR"), ("Decode Base64…", "Base64 decode"),
                                    ("Decompress zlib…", "zlib decompress"), ("Preview patch…","Patch proposal")):
                menu.add_command(label=text, command=lambda op=operation:self.transform_bytes(op, instruction))
            menu.add_separator()
            menu.add_command(label="Evidence scripts…", command=self.evidence_scripts)
            try:
                menu.tk_popup(event.x_root, event.y_root)
            finally:
                menu.grab_release()
        return "break"

    def refresh_accelerators(self, *_):
        for action,(menu,index) in getattr(self,"menu_keys",{}).items():
            menu.entryconfigure(index,accelerator=self.controls.accelerator(action))

    def update_telemetry(self, bright=True):
        if self.pulse_job is not None:
            self.root.after_cancel(self.pulse_job)
            self.pulse_job = None
        base = ("x64 LE · " + self.cursor.get()) if self.case else ""
        if self.decompiling:
            self.telemetry.configure(text=f"● Ghidra   {base}", foreground=CRIMSON if bright else MUTED)
            self.pulse_job = self.root.after(600,self.update_telemetry,not bright)
        else:
            self.telemetry.configure(text=base, foreground=MUTED)

    def callback_error(self, exc, error, trace):
        if isinstance(error, (OSError,ValueError,sqlite3.Error)):
            self.error(str(error))
        else:
            import traceback
            traceback.print_exception(exc,error,trace)
            self.error("The action could not be completed.")

    def error(self, text):
        self.status.set(text)
        dialogs.inform(self.root, "Investigation error", text)

    def update_nav(self):
        self.breadcrumbs.refresh(self.case, self.trail, self.step)
        self.back.state(["!disabled" if self.step > 0 or self.xrefs.origin else "disabled"])
        self.forward.state(["!disabled" if self.step+1 < len(self.trail) else "disabled"])

    def busy(self, text, work, done, *, decompiler=False, failed=None, cancelled=None):
        self.cancel_work(announce=False)
        self.status.set(text)
        self.decompiling = decompiler
        self.update_telemetry()
        if decompiler:
            self.views.decompiler_state(text, busy=True)
        else:
            self.cancel.pack(side="right")
        self.cancel_token = Event()
        self.on_cancel = cancelled
        future = self.pool.submit(work,self.cancel_token)
        self.pending = future
        def check():
            self.work_timer = None
            if self.pending is not future:
                return
            if not future.done():
                self.work_timer = self.root.after(35,check)
                return
            self.pending = None
            self.on_cancel = None
            self.decompiling = False
            self.update_telemetry()
            self.cancel.pack_forget()
            try:
                result = future.result()
                done(result)
            except (OSError,ValueError,sqlite3.Error) as error:
                self.sync_routine()
                if failed:
                    failed(str(error))
                elif decompiler:
                    self.views.decompiler_state(str(error))
                    self.status.set("Decompilation did not finish. The listing and notes are available.")
                else:
                    self.error(str(error))
        self.work_timer = self.root.after(10,check)

    def cancel_work(self, announce=True):
        if self.work_timer is not None:
            self.root.after_cancel(self.work_timer)
            self.work_timer = None
        if self.pending:
            self.cancel_token.set()
            self.pending.cancel()
            self.pending = None
            if self.on_cancel:
                self.on_cancel()
            self.on_cancel = None
        if self.decompiling:
            self.views.decompiler_state("Decompilation cancelled.")
            self.decompiling = False
            self.update_telemetry()
        self.cancel.pack_forget()
        if announce:
            self.sync_routine()
            self.status.set("Cancelled. Current investigation retained.")

    def pick_dll(self):
        path = dialogs.choose_file(self.root)
        if path: self.open_path(path)

    def open_path(self, path):
        self.load_case(lambda: open_dll(path))

    def example(self, build):
        self.load_case(lambda: open_example(build))

    def resume(self, digest):
        record = self.store.metadata(digest)
        if record:
            self.load_case(lambda: reopen_case(self.store.path,record))

    def load_case(self, loader, *, after=None, selected=None):
        if self.xrefs.visible:
            self.xrefs.hide()
        def indexed(case, call_index=None):
            saved = self.store.metadata(case.digest)
            target_key = selected[0] if selected else (saved["routine"] if saved else None)
            if target_key is not None and target_key not in case.keys:
                if case.image and call_index is None:
                    from .xrefs import build_index
                    def recovered(index):
                        case.include_callers(index)
                        indexed(case, index)
                    self.busy("Recovering the saved caller…", lambda stop: build_index(case.image, stop), recovered)
                    return
                raise ValueError("Requested routine is missing. The previous case remains intact.")
            routine = case.keys[target_key] if target_key is not None else case.routines[0]
            if target_key is None and case.image is not None:
                routine = next((r for r in case.routines if r.rva == case.image.entry),routine)
            at = saved["rva"] if saved else (0x64 if case.example else routine.rva)
            raw = saved["raw"] if saved else None
            if selected:
                _, at, raw = selected
            def ready(rows):
                idx = self.locate(rows,at,raw)
                if self.case and not self.notes.allow_discard():
                    self.sync_routine()
                    self.status.set("Current investigation retained.")
                    return
                changed = any(rec["source"] == case.source and rec["digest"] != case.digest
                              for rec in self.store.recent())
                knowledge, functions = self.store.activate(case,case.key(routine),rows[idx])
                self.xrefs.reset(call_index)
                self.case,self.routine,self.rows,self.index = case,routine,rows,idx
                if self.observation_window is not None:
                    if case.image:
                        self.observation_window.reset_case(case)
                    else:
                        self.observation_window.close()
                self.edits.bind(case, knowledge, functions)
                self.layouts.bind(case)
                self.personal.bind(case)
                self.xref_button.state(["!disabled" if case.image else "disabled"])
                self.inspector_button.state(["!disabled" if case.image else "disabled"])
                self.trail, self.step = [], -1
                self.routine_box["values"] = [self.routine_label(r) for r in case.routines]
                self.artifact.set(case.label[:48])
                self.root.title(case.label + " — Insight")
                self.display_routine()
                self.record_location()
                self.notes.bind_case(case)
                self.status.set(("Different build at this path · previous notes remain with their fingerprint. "
                                 if changed else "") +
                                ("Read-only DLL snapshot" if case.image else "Read-only packaged example")
                                + " · SHA-256 " + case.digest[:16] + "…")
                self.personal.opened()
                if after:
                    after(case)
            self.busy("Decoding selected instruction range…",lambda stop:case.instructions(routine,stop),ready)
        self.busy("Reading and identifying the artifact…",lambda _stop:loader(),indexed)

    @staticmethod
    def locate(rows, at, raw=None):
        for i,row in enumerate(rows):
            if row.rva == at:
                if raw is not None and row.raw != raw:
                    raise ValueError("Citation mismatch. The bytes differ from the saved instruction.")
                return i
        raise ValueError("That address is outside the decoded range or between instruction starts.")

    def routine_label(self, r):
        return (f"0x{r.rva:08X}   " if self.case.image else "") + self.edits.function_name(r)

    def sync_routine(self):
        if self.routine: self.routine_box.set(self.routine_label(self.routine))

    def display_routine(self):
        self.sync_routine()
        case,r = self.case,self.routine
        self.views.show(self.rows,self.index,r.name if case.image else case.example["name"]+" · "+r.name,
                        is_dll=case.image is not None, coverage=r.extent)
        self.edits.function_labels()
        cached = self.decompiled.get((case.digest, r.rva, r.end)) if case.image else None
        if cached is not None:
            self.views.set_decompilation(cached, reveal=False)
        self.show_cursor()

    def decompile_current(self, *, reveal=True, after=None):
        if not self.case or not self.case.image:
            self.status.set("Open an x64 DLL to decompile its selected routine.")
            return
        if self.pending is not None:
            if reveal and self.decompiling and not self.xrefs.visible:
                self.views.show_pseudocode()
            return
        if self.xrefs.visible:
            self.xrefs.hide()
        from .ghidra import decompile
        if reveal:
            self.views.show_pseudocode()
        case, routine, rows = self.case, self.routine, self.rows
        key = (case.digest, routine.rva, routine.end)
        if key in self.decompiled:
            self.views.set_decompilation(self.decompiled[key], reveal=False)
            self.decompiled.move_to_end(key)
            if after:
                after()
            return

        def ready(result):
            # A cancelled work item never reaches this callback. Keep results scoped to this artifact.
            self.decompiled[key] = result
            if len(self.decompiled) > 8:
                self.decompiled.popitem(last=False)
            self.views.set_decompilation(result, reveal=False)
            self.status.set(f"Ghidra {result.version} · {routine.name} · read-only")
            if after:
                after()

        self.busy("Decompiling the read-only snapshot…",
                  lambda stop: decompile(case.data, case.digest, routine, rows, stop), ready, decompiler=True)

    def show_cursor(self):
        rva = self.rows[self.index].rva
        self.cursor.set(f"RVA 0x{rva:08X}" if self.case.image else f"{self.routine.name}+0x{rva:X}")
        self.update_telemetry()
        self.personal.cursor()
        if self.observation_window is not None:
            self.observation_window.overlay()
        self.xrefs.update_context()

    def citation(self):
        if self.case: return self.case.key(self.routine), self.rows[self.index]
        return None

    def record_location(self):
        key,row = self.citation()
        loc = (key,row.rva)
        if self.step < 0 or self.trail[self.step] != loc:
            self.trail[self.step+1:] = [loc]
            self.trail = self.trail[-200:]
            self.step = len(self.trail)-1
        self.update_nav()

    def select(self, index, history_step=None):
        if not self.case: return
        self.index = index
        if self.views.index != index:
            self.views.select(index)
        self.show_cursor()
        self.store.bookmark(self.case.digest,*self.citation())
        if history_step is None: self.record_location()
        else:
            self.step = history_step
            self.update_nav()
        self.notes.cursor_changed()

    def navigate(self,routine,rva,raw=None,history_step=None,after=None):
        if self.xrefs.visible:
            self.xrefs.hide()
        if routine == self.routine:
            if not self.decompiling:
                self.cancel_work(announce=False)
            self.select(self.locate(self.rows,rva,raw),history_step)
            if after:
                after()
            return
        case = self.case
        def ready(rows):
            index = self.locate(rows,rva,raw)
            self.rows,self.routine,self.index = rows,routine,index
            self.display_routine()
            self.select(index,history_step)
            self.status.set("Read-only · " + routine.name)
            if after:
                after()
        self.busy("Decoding "+routine.name+"…",lambda stop:case.instructions(routine,stop),ready)

    def pick_routine(self, _event):
        r = self.case.routines[self.routine_box.current()]
        self.navigate(r,r.rva)

    def open_citation(self, key, rva, raw):
        r = self.case.keys.get(key)
        if r is None and self.case.image and self.xrefs.index is None:
            from .xrefs import build_index
            case = self.case
            def recovered(index):
                case.include_callers(index)
                self.xrefs.index = index
                self.routine_box["values"] = [self.routine_label(r) for r in case.routines]
                self.open_citation(key, rva, raw)
            self.busy("Recovering the cited caller…", lambda stop: build_index(case.image, stop), recovered)
            return
        if r is None: raise ValueError("The cited routine is unavailable in this build.")
        self.navigate(r,rva,raw)

    def follow_note_address(self, digest, key, at, relative):
        case = self.case
        if not case or case.digest != digest or key not in case.keys:
            self.status.set("This note belongs to a different build or routine.")
            return
        if relative != (case.image is None):
            self.status.set("Use @0x followed by a DLL RVA, or @+0x for a packaged routine offset.")
            return
        routine = case.keys[key]
        if not routine.rva <= at < routine.end:
            matches = [r for r in case.routines if r.rva <= at < r.end] if case.image else []
            if len(matches) != 1:
                self.status.set("The note address has no unique indexed instruction range.")
                return
            routine = matches[0]
        self.navigate(routine, at)

    def follow(self, target):
        if isinstance(target,str) and self.case.example and target in self.case.keys:
            self.navigate(self.case.keys[target],0)
            return
        routine = self.routine
        if not (routine.rva <= target < routine.end):
            routine = next((r for r in self.case.routines if r.rva <= target < r.end), None) if self.case.image else None
        if routine: self.navigate(routine,target)
        else: self.status.set("Destination is outside the indexed code ranges.")

    def visit(self,delta):
        if self.xrefs.visible:
            self.xrefs.hide()
            return
        step = self.step+delta
        origin = self.xrefs.origin
        if delta == -1 and origin is not None:
            coord = (origin.key, origin.rva)
            if self.trail[self.step] == coord or (step >= 0 and self.trail[step] == coord):
                self.xrefs.back()
                return
        if 0 <= step < len(self.trail):
            self.visit_location(self.case, step, self.trail[step])

    def visit_location(self, case, step, coord):
        if case is self.case and 0 <= step < len(self.trail) and self.trail[step] == coord:
            key, rva = coord
            self.navigate(case.keys[key], rva, history_step=step)

    def show_graph(self):
        if self.xrefs.visible:
            self.xrefs.hide()
        self.xrefs.hide_context()
        if self.views.compact:
            self.views._layout(1)
        self.views.reader.select(self.views.graph)
        self.views.graph.canvas.focus_set()

    def jump(self):
        from .palette import choose
        case, routine = self.case, self.routine
        commands = {"Open x64 DLL": self.pick_dll, "Recent cases": self.recent,
                    "Open Surge observation": self.open_surge, "Blind trials": self.open_trials,
                    "Compare DLL builds": self.diff.pick, "Keyboard and text size": self.controls.show}
        commands.update({f"Workspace · {name}":lambda n=name:self.personal.apply(n) for name in PRESETS})
        if case is not None:
            commands.update({"Record prediction": self.notes.record_prediction, "Review finding": self.notes.review})
            commands.update({"Function graph": self.show_graph, "Artifact identity": self.identity})
            commands.update({"Transform bytes": self.transform_bytes, "Evidence scripts": self.evidence_scripts})
            commands.update({"Function triage": self.edits.triage, "Analysis history": self.edits.history,
                             "Rename selected symbol": lambda: self.edits.edit("name"),
                             "Retype selected symbol": lambda: self.edits.edit("type")})
            if case.image:
                commands["Live observations"] = self.live_observations
                commands.update({"Ghidra pseudocode": self.decompile_current, "Context inspector": self.xrefs.open_context,
                                 "XREF matrix": self.xrefs.open})
                commands["Stack Frame"] = lambda: self.xrefs._type_view("stack")
                if self.views.stack.current_slot:
                    commands["Struct Layout"] = lambda: self.xrefs._type_view("struct")
            if self.step > 0 or self.xrefs.origin:
                commands["Back"] = lambda: self.visit(-1)
            if self.step+1 < len(self.trail):
                commands["Forward"] = lambda: self.visit(1)
        choice = choose(self.root, case, tuple(commands))
        if not choice or case is not self.case:
            return
        kind, value = choice
        if kind == "command" and value in commands:
            commands[value]()
        elif kind == "address" and case:
            if case.image:
                self.follow(value)
            else:
                self.navigate(routine, value)
        elif kind == "function" and case and case.keys.get(case.key(value)) == value:
            self.navigate(value, value.rva)
        elif kind == "references" and case and case.image:
            self.xrefs.open_global(*value)

    def recent(self):
        records = self.store.recent()
        if not records:
            self.status.set("Open a DLL to create a case.")
            return
        digest = dialogs.choose_recent(self.root, records)
        if digest:
            self.resume(digest)

    def identity(self):
        if self.case:
            dialogs.inform(self.root, "Artifact identity", f"{self.case.source}\n\nSHA-256\n{self.case.digest}")

    def replay_results(self):
        if not self.case or not self.case.example:
            self.status.set("External DLLs have no trusted example scores.")
            return
        from .__main__ import summary
        dialogs.inform(self.root, "Packaged control replay", summary(self.case.example["report"]))

    def close(self):
        if not self.notes.allow_discard(): return
        for name in ("script_window", "observation_window"):
            window = getattr(self, name, None)
            if window is not None and window.winfo_exists():
                window.close()
        self.personal.cancel_index()
        try:
            self.personal.save()
        except (sqlite3.Error, ValueError, OSError) as error:
            self.error(str(error))
        self.docks.close()
        self.diff.close()
        self.cancel_work(announce=False)
        self.pool.shutdown(wait=False,cancel_futures=True)
        self.store.db.close()
        self.root.destroy()


def launch(initial=None):
    ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID("Insight.DragonsEye.Desktop")
    root = tk.Tk(className="Insight")
    prepare_window(root)
    App(root,default_folder(),initial)
    root.mainloop()
