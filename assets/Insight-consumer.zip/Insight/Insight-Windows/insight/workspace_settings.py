"""Per-user workspace preferences and monitor-aware placement of native windows."""

from copy import deepcopy
import json
import os
import tkinter as tk
import unicodedata

from .records import unique_fields


PANES = ("listing", "reader", "notes", "structure")
PRESETS = ("Investigation", "Triage", "Deep decompilation", "Graph")
TABS = ("Instruction", "Graph", "Ghidra pseudocode", "Stack Frame", "Struct Layout", "Triage overview")
KEYMAPS = ("Insight", "Ghidra", "IDA Pro", "Binary Ninja", "Vim")
CODE_FONTS = ("Automatic", "JetBrains Mono", "Fira Code", "Iosevka", "Consolas")
DEFAULTS = dict(preset="Investigation", split_ratio=.55, notes_ratio=.25, structure_ratio=.45,
                notes_visible=True, compact_notes=False,
                split_orientation="horizontal", listing_first=True, inspector_open=False,
                active_pane=0, reader_tab="Instruction", code_size=10, ui_size=10, code_font="Automatic",
                keymap="Insight", detached=[], geometries={}, shortcuts={})
MAX_BODY = 16384
MAX_LAYOUTS = 24
DOCK_FIELDS = ("preset", "split_ratio", "notes_ratio", "structure_ratio", "notes_visible", "compact_notes", "split_orientation",
               "listing_first", "inspector_open", "active_pane", "reader_tab", "detached", "geometries")


def _layout_name(name):
    if not isinstance(name, str) or not 1 <= len(name) <= 48 or not name.isprintable() or name != name.strip():
        raise ValueError("Enter a layout name of 1–48 visible characters without surrounding spaces.")
    key = unicodedata.normalize("NFKC", name).casefold()
    if key in (preset.casefold() for preset in PRESETS):
        raise ValueError("Choose a name different from a built-in workspace.")
    return key


def _integer(value, low, high):
    if type(value) is not int or not low <= value <= high:
        raise ValueError("Workspace coordinate or display setting is outside the supported range.")
    return value


def _geometry(value):
    if not isinstance(value, dict) or value.keys() != {"x", "y", "width", "height", "dpi"}:
        raise ValueError("Invalid saved window geometry.")
    return dict(x=_integer(value["x"], -262144, 262144), y=_integer(value["y"], -262144, 262144),
                width=_integer(value["width"], 1, 32768), height=_integer(value["height"], 1, 32768),
                dpi=_integer(value["dpi"], 48, 768))


def _field(key, value):
    choices = {"preset": PRESETS, "split_orientation": ("horizontal", "vertical"),
               "reader_tab": TABS, "keymap": KEYMAPS, "code_font": CODE_FONTS}
    if key in choices:
        if value in choices[key]:
            return value
    elif key in ("notes_visible", "compact_notes", "listing_first", "inspector_open"):
        if type(value) is bool:
            return value
    elif key in ("split_ratio", "notes_ratio", "structure_ratio"):
        if type(value) in (float, int) and .05 <= value <= .95:
            return value
    elif key == "active_pane":
        return _integer(value, 0, 1)
    elif key in ("ui_size", "code_size"):
        return _integer(value, 8, 24)
    elif key == "detached":
        if (isinstance(value, (tuple, list)) and len(value) <= len(PANES)
                and all(p in PANES for p in value) and len(set(value)) == len(value)):
            return list(value)
    elif key == "geometries":
        if isinstance(value, dict) and value.keys() <= {"main", *PANES}:
            return {name: _geometry(v) for name, v in value.items()}
    elif key == "shortcuts" and isinstance(value, dict) and value.keys() <= set(KEYMAPS):
        from .workbench_controls import ACTIONS, validate_bindings
        clean = {}
        for profile, bindings in value.items():
            if not isinstance(bindings, dict) or bindings.keys() - set(ACTIONS):
                raise ValueError("Unknown saved shortcut action.")
            if not all(isinstance(s, str) and len(s) <= 32 and (not s or s.isascii()) for s in bindings.values()):
                raise ValueError("Invalid saved shortcut.")
            canonical = validate_bindings(profile, bindings)
            clean[profile] = {action: canonical.get(action, "") for action in bindings}
        return clean
    raise ValueError(f"Invalid workspace preference: {key}")


class WorkspaceSettings:
    def __init__(self, casebook):
        self.db = casebook.db
        self.db.execute("""CREATE TABLE IF NOT EXISTS workspace_settings (
            id INTEGER PRIMARY KEY CHECK(id=1), version INTEGER NOT NULL, body BLOB NOT NULL)""")
        self.db.execute("""CREATE TABLE IF NOT EXISTS workspace_layouts (
            key TEXT PRIMARY KEY, name TEXT NOT NULL, version INTEGER NOT NULL, body BLOB NOT NULL)""")

    def _read(self):
        state = deepcopy(DEFAULTS)
        row = self.db.execute("""SELECT version,
            CASE WHEN typeof(body)='blob' AND length(body)<=? THEN body END
            FROM workspace_settings WHERE id=1""", (MAX_BODY,)).fetchone()
        if row is None:
            return state, 1
        version, raw = row
        if type(version) is not int or version != 1 or raw is None:
            return state, version
        try:
            record = json.loads(raw.decode("utf-8"), object_pairs_hook=unique_fields)
        except (ValueError, UnicodeError, RecursionError):
            return state, version
        if isinstance(record, dict):
            for key in record.keys() & state.keys():
                value = record[key]
                if key in ("geometries", "shortcuts") and isinstance(value, dict):
                    for name, stored in value.items():
                        try:
                            state[key].update(_field(key, {name: stored}))
                        except ValueError:
                            pass
                    continue
                try:
                    state[key] = _field(key, value)
                except ValueError:
                    pass  # Unusable fields have independent application defaults.
        return state, version

    def load(self):
        return self._read()[0]

    def update(self, **changed):
        if not changed:
            return self.load()
        new = {key: _field(key, value) for key, value in changed.items()}
        with self.db:
            self.db.execute("BEGIN IMMEDIATE")
            state, version = self._read()
            if type(version) is int and version > 1:
                raise ValueError("A newer Insight version saved these workspace preferences.")
            state.update(new)
            raw = json.dumps(state, separators=(",", ":"), allow_nan=False).encode("ascii")
            if len(raw) > MAX_BODY:
                raise ValueError("Workspace preferences exceed the storage limit.")
            self.db.execute("""INSERT INTO workspace_settings VALUES(1,1,?) ON CONFLICT(id)
                DO UPDATE SET version=1,body=excluded.body""", (raw,))
        return state

    def layouts(self):
        rows = self.db.execute("""SELECT key, name FROM workspace_layouts
            WHERE typeof(key)='text' AND length(CAST(key AS BLOB))<=4096
              AND typeof(name)='text' AND length(CAST(name AS BLOB))<=192
            ORDER BY key LIMIT ?""", (MAX_LAYOUTS,))
        names = []
        for key, name in rows:
            try:
                if key == _layout_name(name):
                    names.append(name)
            except ValueError:
                continue
        return tuple(names)

    def layout_exists(self, name):
        return self.db.execute("SELECT 1 FROM workspace_layouts WHERE key=?", (_layout_name(name),)).fetchone() is not None

    def save_layout(self, name, fields):
        key = _layout_name(name)
        if not isinstance(fields, dict) or "preset" not in fields or fields.keys() - set(DOCK_FIELDS):
            raise ValueError("A saved layout needs a workspace preset and valid pane settings.")
        state = {k: _field(k, fields.get(k, DEFAULTS[k])) for k in DOCK_FIELDS}
        raw = json.dumps(state, separators=(",", ":"), allow_nan=False).encode("ascii")
        with self.db:
            self.db.execute("BEGIN IMMEDIATE")
            existing = self.db.execute("SELECT version FROM workspace_layouts WHERE key=?", (key,)).fetchone()
            if existing and existing[0] != 1:
                raise ValueError("This saved layout uses an unsupported version.")
            if not existing and self.db.execute("SELECT 1 FROM workspace_layouts LIMIT 1 OFFSET ?",
                                                (MAX_LAYOUTS-1,)).fetchone():
                raise ValueError(f"Up to {MAX_LAYOUTS} personal layouts can be saved.")
            self.db.execute("""INSERT INTO workspace_layouts VALUES(?,?,1,?) ON CONFLICT(key)
                DO UPDATE SET name=excluded.name,body=excluded.body""", (key, name, raw))
        return state

    def get_layout(self, name):
        key = _layout_name(name)
        row = self.db.execute("""SELECT version,CASE WHEN typeof(body)='blob' AND length(body)<=?
            THEN body END FROM workspace_layouts WHERE key=?""", (MAX_BODY, key)).fetchone()
        if row is None:
            raise ValueError("This personal layout is no longer saved.")
        if row[0] != 1:
            raise ValueError("This saved layout uses an unsupported version.")
        try:
            data = json.loads(row[1].decode("ascii"), object_pairs_hook=unique_fields) if row[1] else None
            if not isinstance(data, dict) or data.keys() != set(DOCK_FIELDS):
                raise ValueError
            return {k: _field(k, data[k]) for k in DOCK_FIELDS}
        except (ValueError, RecursionError) as error:
            raise ValueError("The personal layout contains invalid pane settings.") from error

    def delete_layout(self, name):
        with self.db:
            self.db.execute("DELETE FROM workspace_layouts WHERE key=?", (_layout_name(name),))


def clamp_geometry(saved, work_area, chrome=(0, 0), dpi=96):
    """Scale the saved client size, keeping the whole decorated frame in the work area."""
    rect = _geometry(saved)
    left, top, right, bottom = work_area
    if right <= left or bottom <= top:
        raise ValueError("Invalid monitor work area.")
    cw, ch = chrome
    dpi = _integer(dpi, 48, 768)
    width = max(1, min(right-left-max(0, cw), round(rect["width"] * dpi / rect["dpi"])))
    height = max(1, min(bottom-top-max(0, ch), round(rect["height"] * dpi / rect["dpi"])))
    x = max(left, min(rect["x"], right-width-max(0, cw)))
    y = max(top, min(rect["y"], bottom-height-max(0, ch)))
    return dict(x=x, y=y, width=width, height=height, dpi=dpi)


def _native_frame(window):
    from ctypes import WinDLL, byref, wintypes

    dll = WinDLL("user32")
    handle = wintypes.HWND(int(window.tk.call("wm", "frame", window._w), 0))
    frame = wintypes.RECT()
    if not dll.GetWindowRect(handle, byref(frame)):
        raise OSError("Window geometry unavailable.")
    # Tk's client includes its managed menu. Use the client size used by wm geometry.
    width, height = window.winfo_width(), window.winfo_height()
    dpi = dll.GetDpiForWindow(handle) if hasattr(dll, "GetDpiForWindow") else 96
    rect = dict(x=frame.left, y=frame.top, width=width, height=height, dpi=dpi or 96)
    chrome = (max(0, frame.right-frame.left-width), max(0, frame.bottom-frame.top-height))
    return rect, chrome, handle


def _placement(window, parent, saved):
    from ctypes import Structure, WinDLL, byref, sizeof, wintypes

    class MonitorInfo(Structure):
        _fields_ = [("size", wintypes.DWORD), ("bounds", wintypes.RECT),
                    ("work", wintypes.RECT), ("flags", wintypes.DWORD)]

    current, chrome, handle = _native_frame(window)
    dll = WinDLL("user32")
    dll.MonitorFromRect.restype = dll.MonitorFromWindow.restype = wintypes.HMONITOR
    frame = wintypes.RECT(saved["x"], saved["y"], saved["x"] + saved["width"] + chrome[0],
                          saved["y"] + saved["height"] + chrome[1])
    monitor = dll.MonitorFromRect(byref(frame), 0)
    disconnected = not monitor
    if disconnected:
        owner = _native_frame(parent)[2] if parent is not None else handle
        monitor = dll.MonitorFromWindow(owner, 1)
    info = MonitorInfo()
    info.size = sizeof(info)
    monitor = wintypes.HMONITOR(monitor)
    if not dll.GetMonitorInfoW(monitor, byref(info)):
        raise OSError("Monitor work area unavailable.")
    area = info.work
    dpi = current["dpi"]
    try:
        dx, dy = wintypes.UINT(), wintypes.UINT()
        if WinDLL("shcore").GetDpiForMonitor(monitor, 0, byref(dx), byref(dy)) == 0 and 48 <= dx.value <= 768:
            dpi = dx.value
    except (AttributeError, OSError):
        pass
    scale = dpi / current["dpi"]
    chrome = (round(chrome[0]*scale), round(chrome[1]*scale))
    if disconnected:
        saved = dict(saved, x=area.left+16, y=area.top+16)
    return clamp_geometry(saved, (area.left, area.top, area.right, area.bottom), chrome, dpi)


def capture_geometry(window):
    try:
        if str(window.tk.call("wm", "state", window._w)) != "normal":
            return None
        if os.name == "nt":
            rect = _native_frame(window)[0]
        else:
            rect = dict(x=window.winfo_x(), y=window.winfo_y(), width=window.winfo_width(),
                        height=window.winfo_height(), dpi=round(window.winfo_fpixels("1i")))
        return _geometry(rect) if rect["width"] > 1 and rect["height"] > 1 else None
    except (OSError, ValueError, tk.TclError):
        return None


def restore_geometry(window, saved, parent=None):
    if saved is None:
        return False
    try:
        saved = _geometry(saved)
        window.update_idletasks()
        if os.name == "nt":
            rect = _placement(window, parent, saved)
        else:
            rect = clamp_geometry(saved, (0, 0, window.winfo_screenwidth(), window.winfo_screenheight()))
        w, h = rect["width"], rect["height"]
        minimum = window.tk.splitlist(window.tk.call("wm", "minsize", window._w))
        if int(minimum[0]) > w or int(minimum[1]) > h:
            window.tk.call("wm", "minsize", window._w, min(w, int(minimum[0])), min(h, int(minimum[1])))
        # Tk accepts "+-1920" for a literal negative origin on a left-hand monitor.
        window.tk.call("wm", "geometry", window._w, f"{w}x{h}+{rect['x']}+{rect['y']}")
        return True
    except (OSError, ValueError, tk.TclError):
        return False
