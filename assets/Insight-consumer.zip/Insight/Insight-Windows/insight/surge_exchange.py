"""Import bounded Surge collector observations and bind one range to one draft revision."""

from hashlib import sha256
import json

from .investigation import open_dll
from .observation_format import SCHEMAS, _hash, _text, validate_saved_observation
from .records import read_local, unique_fields

MAX_INPUT, MAX_ROWS = 1024*1024, 1000


def _canonical(data):
    return json.dumps(data, sort_keys=True, separators=(",",":"), ensure_ascii=False, allow_nan=False).encode()


def _capture_rows(obj):
    rows = obj.get("observations")
    if not isinstance(rows,list) or not 1 <= len(rows) <= MAX_ROWS:
        raise ValueError("Choose 1–1000 Surge observations.")
    if obj["schema"] == "native-code-capture-v1":
        return rows
    manifest = obj.get("ranges")
    if not isinstance(manifest,list) or not 2 <= len(manifest) <= 16 or len(rows) != 3*len(manifest):
        raise ValueError("The Surge capture's expected ranges and phases are incomplete.")
    keys = {"range_name","range_rva","range_size","reference_hex","reference_sha256"}
    if any(not isinstance(r,dict) or set(r)!=keys or not _text(r["range_name"]) for r in manifest):
        raise ValueError("Malformed Surge range manifest.")
    ranges = {r["range_name"]:r for r in manifest}
    if len(ranges) != len(manifest):
        raise ValueError("Duplicate names in the Surge range manifest.")
    remaining = {(name,phase) for name in ranges for phase in ("initial","sample","restored")}
    identities = set()
    for row in rows:
        if not isinstance(row,dict) or row.get("schema") != SCHEMAS[0]:
            raise ValueError("The capture contains an unsupported observation.")
        name, phase = row.get("range_name"),row.get("phase")
        if not _text(name) or not _text(phase) or (name,phase) not in remaining:
            raise ValueError("Duplicate or missing Surge capture phase.")
        if any(row.get(k)!=ranges[name][k] for k in keys):
            raise ValueError("The observation differs from its capture range manifest.")
        remaining.remove((name,phase))
        if not _hash(row.get("module_sha256")) or not _text(row.get("session_id")) or type(row.get("pid")) is not int:
            raise ValueError("Invalid capture process identity.")
        identities.add((row["module_sha256"],row["session_id"],row["pid"]))
    if len(identities)!=1:
        raise ValueError("The process or module changed within this Surge capture.")
    return rows


def _observation(row):
    if not isinstance(row, dict) or row.get("schema") not in SCHEMAS:
        raise ValueError("Choose a Surge native-code-range-v1 observation or surge-native-integrity-v1 export.")
    status = row.get("memory_status")
    size, observed = row.get("range_size"), row.get("observed_hex")
    if type(size) is not int or not 1 <= size <= 64 or (status != "complete" and observed is not None):
        raise ValueError("The observation is missing a usable byte range or has inconsistent coverage.")
    entry = dict(schema=row["schema"], module_sha256=row.get("module_sha256"), rva=row.get("range_rva"),
                 size=size, reference_hex=row.get("reference_hex"), observed_hex=observed if status=="complete" else "",
                 read_mask=("1" if status=="complete" else "0")*size, memory_status=status,
                 captured_at=row.get("captured_at"), session_id=row.get("session_id"), pid=row.get("pid"),
                 range_name=row.get("range_name","Unnamed range"), phase=row.get("phase","snapshot"),
                 source_sha256=sha256(_canonical(row)).hexdigest())
    validate_saved_observation(entry)
    if sha256(bytes.fromhex(entry["reference_hex"])).hexdigest() != row.get("reference_sha256"):
        raise ValueError("The Surge reference hash does not match its bytes.")
    if row["schema"] == SCHEMAS[1]:
        observed_hash = sha256(bytes.fromhex(observed)).hexdigest() if status=="complete" else None
        if row.get("observed_sha256") != observed_hash:
            raise ValueError("The Surge observation hash does not match its coverage and bytes.")
    return entry


def _check(cancel):
    if cancel is not None and cancel.is_set():
        raise ValueError("Surge import cancelled. The previous investigation is still open.")


def read_observations(path, cancel=None):
    _check(cancel)
    raw = read_local(path, MAX_INPUT)
    def reject_number(_):
        raise ValueError("Surge observations require finite JSON numbers.")
    def parse(data):
        return json.loads(data, object_pairs_hook=unique_fields, parse_constant=reject_number)
    try:
        data = raw.decode("utf-8-sig")
        try:
            obj = parse(data)
        except json.JSONDecodeError:
            lines = [line for line in data.splitlines() if line.strip()]
            if not 1 <= len(lines) <= MAX_ROWS:
                raise ValueError("Choose 1–1000 Surge observations.")
            rows = [parse(line) for line in lines]
        else:
            if isinstance(obj,dict) and obj.get("schema") in ("native-code-capture-v1","native-code-capture-v2"):
                rows = _capture_rows(obj)
            else:
                rows = [obj]
        if not isinstance(rows,list) or not 1 <= len(rows) <= MAX_ROWS:
            raise ValueError("Choose 1–1000 Surge observations.")
        result = []
        for row in rows:
            _check(cancel)
            result.append(_observation(row))
        return tuple(result)
    except (UnicodeError, RecursionError, json.JSONDecodeError) as error:
        raise ValueError("The selected file has invalid or excessively nested JSON.") from error


def verify_observation(case, record):
    validate_saved_observation(record)
    if case is None or case.image is None or case.digest != record["module_sha256"]:
        raise ValueError("The selected DLL SHA-256 does not match this Surge observation.")
    at = case.image.offset(record["rva"],record["size"])
    raw = case.data[at:at+record["size"]]
    if raw.hex() != record["reference_hex"]:
        raise ValueError("The Surge reference bytes disagree with the selected DLL at this RVA.")
    return raw


def bind_observation(path, record, cancel=None):
    _check(cancel)
    case = open_dll(path)
    verify_observation(case,record)
    _check(cancel)
    return case


def read_saved_observation(store, digest, note_id, revision_number):
    exists = store.db.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='surge_observations'").fetchone()
    if not exists:
        return None
    row = store.db.execute("""SELECT CASE WHEN typeof(s.body)='blob' AND length(s.body)<=4096 THEN s.body END
        FROM surge_observations s JOIN notes n ON n.id=s.note
        WHERE n.digest=? AND s.note=? AND s.revision=?""", (digest,note_id,revision_number)).fetchone()
    if not row:
        return None
    if not row[0]:
        raise ValueError("The saved Surge observation exceeds its limit.")
    try:
        record = validate_saved_observation(json.loads(row[0], object_pairs_hook=unique_fields))
    except (UnicodeError,RecursionError) as error:
        raise ValueError("The saved Surge observation has invalid encoding or nesting.") from error
    if record["module_sha256"] != digest:
        raise ValueError("The saved Surge observation belongs to a different build.")
    return record


def attach_observation(store, case, note_id, revision_number, record):
    verify_observation(case,record)
    payload = _canonical(record)
    with store.db:
        store.db.execute("BEGIN IMMEDIATE")
        store.db.execute("""CREATE TABLE IF NOT EXISTS surge_observations(
            note INTEGER, revision INTEGER, body BLOB NOT NULL, PRIMARY KEY(note,revision),
            FOREIGN KEY(note,revision) REFERENCES revisions(note,number))""")
        row = store.db.execute("""SELECT n.rva,n.raw,r.approved,r.number FROM notes n JOIN revisions r ON r.note=n.id
            WHERE n.digest=? AND n.id=? ORDER BY r.number DESC LIMIT 1""", (case.digest,note_id)).fetchone()
        if not row or row[2] or row[3] != revision_number:
            raise ValueError("Select the latest saved, unapproved finding revision.")
        rva, raw = row[0], row[1]
        if not max(rva,record["rva"]) < min(rva+len(raw),record["rva"]+record["size"]):
            raise ValueError("The pinned instruction must overlap the selected Surge range.")
        start = case.image.offset(rva,len(raw))
        if raw != case.data[start:start+len(raw)]:
            raise ValueError("The pinned instruction bytes no longer match this case.")
        prior = read_saved_observation(store,case.digest,note_id,revision_number)
        if prior and prior != record:
            raise ValueError("This revision already cites another observation. Save a new revision to change it.")
        store.db.execute("INSERT OR IGNORE INTO surge_observations VALUES(?,?,?)",(note_id,revision_number,payload))
