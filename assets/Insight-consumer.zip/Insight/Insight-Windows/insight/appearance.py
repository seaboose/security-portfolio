"""Shared materials and native widget styles for the desktop workbench."""

import tkinter as tk
from tkinter import font, ttk

CANVAS, SURFACE, LINE = "#121212", "#1c1c1e", "#443c40"
INK, MUTED = "#f1ece9", "#bcb3b4"
CRIMSON, AMBER, TEAL = "#e63946", "#ffb703", "#2a9d8f"
MONO, MONO_TITLE = "InsightCode", "InsightCodeTitle"
UI, UI_BOLD, UI_ITALIC = "InsightUI", "InsightUIBold", "InsightUIItalic"
UI_SMALL, UI_TITLE, UI_HEADING = "InsightUISmall", "InsightUITitle", "InsightUIHeading"
CODE_FAMILIES = ("JetBrains Mono", "Fira Code", "Iosevka", "Consolas")
RIM, WELL = "#65595b", "#161415"
SELECTION = "#59272f"


def available_code_fonts(root):
    installed = set(font.families(root))
    return tuple(f for f in CODE_FAMILIES if f in installed)


def set_fonts(widget, code_size=10, ui_size=10, code_font="Automatic", *, notify=True):
    if any(type(n) is not int or not 8 <= n <= 24 for n in (code_size, ui_size)):
        raise ValueError("Font sizes must be whole numbers from 8 to 24 points.")
    if code_font not in ("Automatic", *CODE_FAMILIES):
        raise ValueError("Unknown technical typeface.")
    root = widget._root()
    installed = set(font.families(root))
    available = [f for f in CODE_FAMILIES if f in installed]
    if code_font == "Automatic":
        family = next(iter(available), "Consolas")
    else:
        family = code_font if code_font in installed else "Consolas"
    ui = next((f for f in ("Inter", "IBM Plex Sans", "Segoe UI") if f in installed), "Segoe UI")
    if not hasattr(root, "_insight_fonts"):
        root._insight_fonts = {}
    for name, face, size, weight, slant in (
            (MONO, family, code_size, "normal", "roman"), (MONO_TITLE, family, code_size+2, "bold", "roman"),
            (UI, ui, ui_size, "normal", "roman"), (UI_BOLD, ui, ui_size, "bold", "roman"),
            (UI_ITALIC, ui, ui_size, "normal", "italic"), (UI_SMALL, ui, ui_size-1, "normal", "roman"),
            (UI_TITLE, ui, ui_size+1, "bold", "roman"), (UI_HEADING, ui, ui_size+2, "bold", "roman")):
        if name not in root._insight_fonts:
            root._insight_fonts[name] = font.Font(root, name=name)
        root._insight_fonts[name].configure(family=face, size=size, weight=weight, slant=slant)
    ttk.Style(root).configure("Insight.Treeview", rowheight=round(root._insight_fonts[MONO].metrics("linespace")*1.4))
    if notify:
        pending = list(root.children.values())
        while pending:
            child = pending.pop()
            pending.extend(child.children.values())
            if isinstance(child, tk.BaseWidget) and child.bind("<<InsightFontsChanged>>"):
                child.event_generate("<<InsightFontsChanged>>")


def mono_font(widget):
    root = widget._root()
    if not hasattr(root, "_insight_fonts"):
        set_fonts(root, notify=False)
    return root._insight_fonts[MONO]


def scrollable(frame, widget):
    frame.rowconfigure(0, weight=1)
    frame.columnconfigure(0, weight=1)
    widget.grid(row=0, column=0, sticky="nsew")
    y = ttk.Scrollbar(frame, orient="vertical", style="Insight.Vertical.TScrollbar", command=widget.yview)
    x = ttk.Scrollbar(frame, orient="horizontal", style="Insight.Horizontal.TScrollbar", command=widget.xview)
    y.grid(row=0, column=1, sticky="ns")
    x.grid(row=1, column=0, sticky="ew")
    widget.configure(yscrollcommand=y.set, xscrollcommand=x.set)
    return y


def _tab_plate(root, active, focus=False, hover=False):
    """Nine-slice face. Keep the cut corner and keyed rail at the original scale."""
    # Tk tiles the region inside the fixed borders for every tab repaint.
    width, height = 144, 40
    image = tk.PhotoImage(master=root, width=width, height=height)
    image.put(SURFACE, to=(0, 0, width, height))
    fill = "#302427" if active else "#262225" if hover else SURFACE
    for y in range(height):
        # The relieved top-right corner makes the active tab legible by shape.
        end = width - max(0, 5-y) if active else width
        image.put(fill, to=(0, y, end, y+1))
    image.put(RIM if active else LINE, to=(width-1, 6, width, height-1))
    image.put(CRIMSON if active else LINE, to=(0, height-2, width, height))
    if active:
        image.put("#b77b70", to=(0, 0, width-5, 1))
        for y in range(5):
            image.put("#b77b70", to=(width-6+y, y, width-5+y, y+1))
        for x in range(5):
            image.put(AMBER, to=(3+x, height-5-x, 5+x, height-2-x))
    if focus:
        image.put(AMBER, to=(0, 2, 2, height-4))
    return image


def _command_plate(root, fill, rim):
    """A single clipped lower corner keeps commands distinct from the keyed tabs."""
    width, height = 192, 40
    image = tk.PhotoImage(master=root, width=width, height=height)
    image.put(rim, to=(0, 0, width, height))
    image.put(fill, to=(1, 1, width-1, height-1))
    for cut in range(1, 5):
        y, end = height-5+cut, width-cut
        image.put(SURFACE, to=(end, y, width, y+1))
        image.put(rim, to=(end-1, y, end, y+1))
    return image


def apply_theme(widget):
    root = widget._root()
    if hasattr(root, "_insight_plates"):
        return
    root.configure(background=CANVAS)
    mono_font(root)
    style = ttk.Style(root)
    style.theme_use("clam")
    style.configure(".", font=UI, background=SURFACE, foreground=INK,
                    bordercolor=LINE, lightcolor=LINE, darkcolor=LINE, focuscolor=AMBER,
                    fieldbackground=WELL, troughcolor=WELL, arrowcolor=MUTED,
                    selectbackground=SELECTION, selectforeground=INK)
    style.configure("TButton", width=0, padding=("7p","3p"), background="#2b2729")
    style.map("TButton", foreground=[("disabled", "#92898c")])
    style.configure("Edge.TButton", anchor="w")
    style.configure("Branch.Edge.TButton", foreground="#f9c25d")
    for control in ("TEntry", "TCombobox"):
        style.configure(control, padding=("4p","2p"), bordercolor=RIM,
                        lightcolor=WELL, darkcolor=WELL, insertcolor=INK)
        style.map(control, bordercolor=[("focus", AMBER), ("active", "#897b7d")],
                  fieldbackground=[("readonly", WELL)], foreground=[("readonly", INK)])
    style.configure("TSeparator", background=LINE)
    style.configure("DockTitle.TLabel", font=UI_BOLD)
    style.configure("Insight.TNotebook", borderwidth=0, background=SURFACE, tabmargins=0)
    style.configure("Insight.Treeview", background=CANVAS, fieldbackground=CANVAS,
                    foreground=INK, font=MONO, borderwidth=1, lightcolor=LINE, darkcolor=LINE,
                    rowheight=round(mono_font(root).metrics("linespace")*1.4))
    style.map("Insight.Treeview", background=[("selected", SELECTION)],
              foreground=[("selected", "#fff2f3")], bordercolor=[("focus", "#ad8075")])
    style.configure("Insight.Treeview.Heading", font=UI_BOLD,
                    background="#282427", foreground="#d6c9c6", padding=("3p","2p"),
                    relief="flat", bordercolor=LINE, lightcolor="#3c3538", darkcolor=LINE)
    for axis in ("Vertical", "Horizontal"):
        name = f"Insight.{axis}.TScrollbar"
        style.configure(name, background="#51494a", lightcolor="#595051", darkcolor="#40393b",
                        bordercolor="#302b2e", arrowsize="9p", gripcount=0)
        style.map(name, background=[("disabled", "#2e292b"), ("active", "#746466")],
                  arrowcolor=[("disabled", "#9b9091")])

    # Fonts and chrome scale together on high-DPI displays.
    zoom = max(1, round(root.winfo_fpixels("1i") / 96))
    states = ((), ("selected", "focus"), ("selected",), ("focus",), ("active",))
    plates = [_tab_plate(root, "selected" in state, "focus" in state, "active" in state)
              for state in states]
    if zoom > 1:
        plates = [plate.zoom(zoom) for plate in plates]
    commands = [_command_plate(root, fill, rim) for fill, rim in (
        ("#2b2729", RIM), (SURFACE, LINE), (WELL, "#a07b70"), ("#302a2c", AMBER), ("#3c3032", "#937d7c"))]
    if zoom > 1:
        commands = [plate.zoom(zoom) for plate in commands]
    root._insight_plates = plates + commands
    style.element_create("Insight.command", "image", commands[0], ("disabled", commands[1]),
                         ("pressed", commands[2]), ("focus", commands[3]), ("active", commands[4]),
                         border=5*zoom, width=12*zoom, height=12*zoom, padding=0, sticky="nsew")
    style.layout("TButton", [("Insight.command", {"sticky": "nsew", "children": [
        ("Button.padding", {"sticky": "nsew", "children": [("Button.label", {"sticky": "nsew"})]})]})])
    style.element_create("Insight.tabplate", "image", plates[0],
                         *[(*state, plate) for state, plate in zip(states[1:], plates[1:])],
                         border=tuple(n*zoom for n in (10, 6, 6, 9)), width=24*zoom, height=16*zoom,
                         padding=0, sticky="nsew")
    for name, standard in (("Insight.TNotebook.Tab", "Notebook"), ("Insight.Switch.TRadiobutton", "Radiobutton")):
        label = (standard + ".label", {"sticky": "w"})
        inside = (standard + ".padding", {"sticky": "nsew", "children": [label]})
        style.layout(name, [("Insight.tabplate", {"sticky": "nsew", "children": [inside]})])
        padding = "10p 3p 6p 5p"
        style.configure(name, padding=padding, font=UI, foreground=MUTED)
        style.map(name, padding=[("selected", padding)],
                  foreground=[("selected", "#fff5e4"), ("active", INK)])
    for option, color in (("background", WELL), ("foreground", INK), ("selectBackground", SELECTION),
                          ("selectForeground", INK), ("highlightBackground", LINE)):
        root.option_add("*TCombobox*Listbox." + option, color)
    for pattern in ("*Menu.font", "*TCombobox*Listbox.font", "*Entry.font", "*TEntry.font",
                    "*TCombobox.font", "*TSpinbox.font"):
        root.option_add(pattern, UI)
