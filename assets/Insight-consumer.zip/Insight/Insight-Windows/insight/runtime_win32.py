"""Isolated read-only Windows PSS worker. Only the explicit case file and target PID are opened."""

from contextlib import contextmanager
import ctypes as c
from ctypes import wintypes as W
from datetime import datetime, timedelta, timezone
from hashlib import sha256
import json
import os
from pathlib import Path
import struct
import sys


READ_ACCESS = 0x0400 | 0x0010  # PROCESS_QUERY_INFORMATION | PROCESS_VM_READ.
CONTEXT_FLAGS = 0x100003  # AMD64 CONTROL | INTEGER.
MAX_MODULES, MAX_THREADS = 1024, 256
REGISTERS = ("RAX", "RCX", "RDX", "RBX", "RSP", "RBP", "RSI", "RDI",
             "R8", "R9", "R10", "R11", "R12", "R13", "R14", "R15", "RIP")
P, U, H = c.c_void_p, W.DWORD, W.HANDLE


class ThreadEntry(c.Structure):
    _fields_ = [("exit", U), ("teb", P), ("pid", U), ("tid", U), ("affinity", c.c_size_t),
                ("priority", c.c_int), ("base_priority", c.c_int), ("sysarg", P), ("syscall", W.WORD),
                ("created", W.FILETIME), ("exited", W.FILETIME), ("kernel_time", W.FILETIME),
                ("user_time", W.FILETIME), ("start", P), ("time", W.FILETIME), ("flags", U),
                ("suspend", W.WORD), ("size", W.WORD), ("context", P)]


class Memory(c.Structure):
    _fields_ = [("base", P), ("allocation", P), ("initial_protection", U), ("partition", W.WORD),
                ("size", c.c_size_t), ("state", U), ("protection", U), ("kind", U)]


class ModuleInfo(c.Structure):
    _fields_ = [("base", P), ("size", U), ("entry", P)]


def _ticks(time):
    return time.dwHighDateTime << 32 | time.dwLowDateTime


def _iso(ticks):
    return (datetime(1601, 1, 1, tzinfo=timezone.utc) + timedelta(microseconds=ticks//10)).isoformat()


def _ok(value):
    if not value:
        raise c.WinError(c.get_last_error())
    return value


def _pss(code):
    if code:
        raise c.WinError(code)


class Windows:
    def __init__(self):
        # Only built-in System32, never the case directory or the search path.
        dll = c.WinDLL("kernel32", winmode=0x800, use_last_error=True)
        specs = (
            ("OpenProcess", H, (U, W.BOOL, U)), ("CloseHandle", W.BOOL, (H,)),
            ("GetCurrentProcess", H, ()), ("GetProcessTimes", W.BOOL, (H, P, P, P, P)),
            ("CheckRemoteDebuggerPresent", W.BOOL, (H, P)), ("IsWow64Process2", W.BOOL, (H,P,P)),
            ("K32EnumProcessModulesEx", W.BOOL, (H,P,U,P,U)),
            ("K32GetModuleInformation", W.BOOL, (H,H,P,U)), ("K32GetMappedFileNameW", U, (H,P,P,U)),
            ("GetFinalPathNameByHandleW", U, (H,P,U,U)), ("GetDriveTypeW", U, (W.LPCWSTR,)),
            ("CreateFileW", H, (W.LPCWSTR,U,U,P,U,U,H)), ("GetFileType", U, (H,)),
            ("VirtualQueryEx", c.c_size_t, (H,P,P,c.c_size_t)), ("ReadProcessMemory", W.BOOL, (H,P,P,c.c_size_t,P)),
            ("PssCaptureSnapshot", U, (H,U,U,P)), ("PssFreeSnapshot", U, (H,H)),
            ("PssWalkMarkerCreate", U, (P,P)), ("PssWalkMarkerFree", U, (H,)),
            ("PssWalkSnapshot", U, (H,U,H,P,U)),
        )
        for name, result, args in specs:
            fn = getattr(dll, name)
            fn.restype, fn.argtypes = result, args
            setattr(self, name, fn)

    def mapped_name(self, process, base):
        buf = c.create_unicode_buffer(32768)
        n = self.K32GetMappedFileNameW(process, base, buf, len(buf))
        return buf.value.casefold() if 0 < n < len(buf) else None

    def module(self, process, case_path):
        modules, needed = (H * MAX_MODULES)(), U()
        _ok(self.K32EnumProcessModulesEx(process, modules, c.sizeof(modules), c.byref(needed), 2))
        if needed.value > c.sizeof(modules) or needed.value % c.sizeof(H):
            raise ValueError("The target's loaded module list exceeds the capture limit or changed.")
        matches = [base for base in modules[:needed.value//c.sizeof(H)]
                   if self.mapped_name(process, base) == case_path]
        if len(matches) != 1:
            raise ValueError("The open case file is not uniquely loaded in this process. Check its path and build.")
        base, info = matches[0], ModuleInfo()
        _ok(self.K32GetModuleInformation(process, base, c.byref(info), c.sizeof(info)))
        if info.base != base or not info.size:
            raise ValueError("Could not confirm the target module extent.")
        return base, info.size

    def memory(self, process, address, allocation, maximum, *, executable=False):
        page = Memory()
        if (self.VirtualQueryEx(process, address, c.byref(page), c.sizeof(page)) != c.sizeof(page)
                or page.allocation != allocation or page.state != 0x1000 or page.kind != 0x1000000
                or page.protection & 0x100 or page.protection & 0xff in (0, 1)
                or executable and page.protection & 0xff not in (0x10, 0x20, 0x40, 0x80)):
            return b""
        size = min(maximum, page.base + page.size-address)
        if size <= 0:
            return b""
        buf, count = (c.c_ubyte * size)(), c.c_size_t()
        if not self.ReadProcessMemory(process, address, buf, size, c.byref(count)):
            return b""
        return bytes(buf[:count.value])

    @contextmanager
    def contexts(self, process):
        snap, marker = H(), H()
        _pss(self.PssCaptureSnapshot(process, 0x180, CONTEXT_FLAGS, c.byref(snap)))
        try:
            _pss(self.PssWalkMarkerCreate(None, c.byref(marker)))
            try:
                yield snap, marker
            finally:
                self.PssWalkMarkerFree(marker)
        finally:
            self.PssFreeSnapshot(self.GetCurrentProcess(), snap)

    def threads(self, process, pid, module):
        base, size = module
        items = []
        with self.contexts(process) as (snapshot, marker):
            while True:
                row = ThreadEntry()
                rc = self.PssWalkSnapshot(snapshot, 3, marker, c.byref(row), c.sizeof(row))
                if rc == 259:  # ERROR_NO_MORE_ITEMS
                    return items
                _pss(rc)
                if len(items) == MAX_THREADS or row.pid != pid:
                    raise ValueError("The thread snapshot exceeds its limit or changed process identity.")
                context = c.string_at(row.context, 256) if row.context and row.size >= 256 and not row.flags else b""
                registers, memory, status, memory_at = {}, b"", "", ""
                if context and struct.unpack_from("<I", context, 48)[0] & CONTEXT_FLAGS == CONTEXT_FLAGS:
                    registers = dict(zip(REGISTERS, struct.unpack_from("<17Q", context, 120)))
                    registers["EFLAGS"] = struct.unpack_from("<I", context, 68)[0]
                    ip = registers["RIP"]
                    if base <= ip < base+size:
                        memory = self.memory(process, ip, base, min(15, base+size-ip), executable=True)
                        memory_at = datetime.now(timezone.utc).isoformat()
                        if not memory:
                            status = "Could not verify readable executable image bytes at the captured RIP."
                else:
                    status = "Thread exited or Windows did not supply its x64 register context."
                items.append(dict(tid=row.tid, time=_iso(_ticks(row.time)), registers=registers,
                                  memory=memory.hex(), memory_at=memory_at, status=status))


def observe(pid, digest, source):
    import msvcrt
    if c.sizeof(P) != 8:
        raise ValueError("Use the 64-bit Windows build of Insight for x64 runtime capture.")
    win = Windows()
    path = Path(source)
    if (not path.is_absolute() or not path.drive.endswith(":") or
            win.GetDriveTypeW(path.anchor) not in (2, 3, 6)):
        raise ValueError("The open case must have a local disk path to verify the mapped build.")
    process = _ok(win.OpenProcess(READ_ACCESS, False, pid))
    try:
        machine, native = W.WORD(), W.WORD()
        _ok(win.IsWow64Process2(process, c.byref(machine), c.byref(native)))
        if machine.value or native.value != 0x8664:
            raise ValueError("Select a native AMD64 target process.")
        created, exited, kernel, user = (W.FILETIME() for _ in range(4))
        _ok(win.GetProcessTimes(process, c.byref(created), c.byref(exited), c.byref(kernel), c.byref(user)))
        # The kernel resolves the explicit case path before any read. Reject device
        # streams and remote destinations, including a local link to a remote file.
        handle = win.CreateFileW(str(path), 0x80000000, 1, None, 3, 0, None)  # GENERIC_READ / FILE_SHARE_READ
        if handle == c.c_void_p(-1).value:
            raise c.WinError(c.get_last_error())
        try:
            if win.GetFileType(handle) != 1:  # FILE_TYPE_DISK
                raise ValueError("Only local disk files can identify a capture.")
            name = c.create_unicode_buffer(32768)
            n = _ok(win.GetFinalPathNameByHandleW(handle, name, len(name), 2))
            if n >= len(name) or not name.value.casefold().startswith("\\device\\harddiskvolume"):
                raise ValueError("The module's local backing file could not be verified.")
            case_path = name.value.casefold()
            fd = msvcrt.open_osfhandle(handle, os.O_RDONLY | os.O_BINARY)
        except BaseException:
            win.CloseHandle(handle)
            raise
        with os.fdopen(fd, "rb") as stream:
            size = os.fstat(stream.fileno()).st_size
            if not 0 < size <= 64 * 1024**2:
                raise ValueError("The on-disk module is outside the supported file size.")
            data = stream.read(size+1)
            if len(data) != size or sha256(data).hexdigest() != digest:
                raise ValueError("The module file no longer matches the open case SHA-256.")
            pe = struct.unpack_from("<I", data, 0x3c)[0]
            extent, headers = struct.unpack_from("<II", data, pe+24+56)
            signature = data[:min(headers, 4096)]
            module = win.module(process, case_path)
            # Windows can put the actual ASLR base in the mapped PE32+ header.
            relocated = bytearray(signature)
            struct.pack_into("<Q", relocated, pe+24+24, module[0])
            def verified():
                return (module[1] == extent and signature and
                        win.memory(process, module[0], module[0], len(signature)) in (signature, relocated))
            if not verified():
                raise ValueError("The loaded PE headers differ from the open case.")
            debugger = W.BOOL()
            _ok(win.CheckRemoteDebuggerPresent(process, c.byref(debugger)))
            items = win.threads(process, pid, module)
            if win.module(process, case_path) != module or not verified():
                raise ValueError("The verified module was unloaded or changed during capture.")
            _ok(win.GetProcessTimes(process, c.byref(created), c.byref(exited), c.byref(kernel), c.byref(user)))
            if _ticks(exited):
                raise ValueError("The process exited during capture.")
            return dict(base=module[0], size=module[1], created=_ticks(created), path=str(path),
                        time=datetime.now(timezone.utc).isoformat(), debugger=bool(debugger.value), threads=items)
    finally:
        win.CloseHandle(process)


if __name__ == "__main__":
    try:
        result = observe(int(sys.argv[1]), sys.argv[2], sys.argv[3])
    except (OSError, ValueError, AttributeError, OverflowError, struct.error) as error:
        result = {"error": "Windows capture unavailable: " + str(error)[:440]}
    print(json.dumps(result, ensure_ascii=True, separators=(",", ":")))
