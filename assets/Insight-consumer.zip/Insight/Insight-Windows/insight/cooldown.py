"""Verify the owned fixture and score comparisons on exactly representable seconds."""

from dataclasses import dataclass
from hashlib import sha256
import operator
from pathlib import Path
import re

from .records import fields, integer, read_document, snapshot, version_one


CASE_DIR = Path(__file__).resolve().parents[1] / "cases" / "survive-cooldown"
ASSET_DIR = CASE_DIR.parents[1] / "context" / "cooldown"
OBJECT_FILES = {"plain": "cooldown0.obj", "encoded": "cooldown1.obj"}
OPERATORS = {"<": operator.lt, "<=": operator.le, ">": operator.gt,
             ">=": operator.ge, "==": operator.eq, "!=": operator.ne}
COMPARISON = re.compile(r"(now|deadline) *(<=|>=|==|!=|<|>) *(now|deadline)")


@dataclass(frozen=True)
class Case:
    digest: str
    deadlines: tuple[float, ...]
    delta: float
    evidence: dict


def load_case() -> Case:
    data = snapshot(CASE_DIR / "case.json")
    record = read_document(data)
    version_one(record)
    fields(record, "version", "id", "reference", "deadline_quarters", "delta_quarters", "builds")
    if record["id"] != "survive-dash-cooldown" or record["reference"] != "finite-dash-ready/1":
        raise ValueError("unsupported case or reference")
    ticks = record["deadline_quarters"]
    if type(ticks) is not list or not 1 <= len(ticks) <= 16:
        raise ValueError("expected 1 to 16 deadlines")
    deadlines = tuple(integer(tick, 1, 2**30) / 4 for tick in ticks)
    if len(set(deadlines)) != len(deadlines):
        raise ValueError("duplicate deadline")
    delta = integer(record["delta_quarters"], 1, min(ticks)) / 4
    builds = record["builds"]
    fields(builds, *OBJECT_FILES)
    for build, filename in OBJECT_FILES.items():
        binding = builds[build]
        fields(binding, "object_sha256", "file_offset", "length", "range_sha256")
        obj = snapshot(ASSET_DIR / filename)
        if sha256(obj).hexdigest() != binding["object_sha256"]:
            raise ValueError(f"{build} object fingerprint mismatch")
        start = integer(binding["file_offset"], 0, len(obj))
        size = integer(binding["length"], 1, len(obj) - start)
        if sha256(obj[start:start + size]).hexdigest() != binding["range_sha256"]:
            raise ValueError(f"{build} routine fingerprint mismatch")
    return Case(sha256(data).hexdigest(), deadlines, delta, builds)


def score(expression: str, case: Case) -> dict:
    if type(expression) is not str or len(expression) > 64:
        raise ValueError("expected a comparison of at most 64 characters")
    match = COMPARISON.fullmatch(expression.strip(" "))
    if not match:
        raise ValueError("use one comparison between now and deadline")
    left, symbol, right = match.groups()
    misses = []
    outputs = []
    for deadline in case.deadlines:
        for now in (deadline - case.delta, deadline, deadline + case.delta):
            values = {"now": now, "deadline": deadline}
            actual = OPERATORS[symbol](values[left], values[right])
            outputs.append(actual)
            expected = not (now < deadline)
            if actual != expected:
                misses.append(dict(now=now, deadline=deadline, expected=expected, actual=actual))
    total = 3 * len(case.deadlines)
    return {"passed": total - len(misses), "total": total, "outputs": outputs, "misses": misses}
