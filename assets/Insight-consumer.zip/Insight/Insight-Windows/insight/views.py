"""Read-only native panes driven by one instruction selection."""

from bisect import bisect_right
import tkinter as tk
from tkinter import font, ttk

from .appearance import (AMBER, CANVAS, CRIMSON, INK, LINE, MONO, MONO_TITLE, MUTED, SURFACE, TEAL,
                         UI, UI_BOLD, UI_SMALL, UI_TITLE, apply_theme)
from .flow_graph import OUTSIDE, build_graph
from .graph_view import GraphView
from .pseudocode import GhidraPane
from .stack_view import StackFrame
from .struct_view import StructLayout
from .workspace_docks import Sash
from .workspace_evidence import entropy_windows, string_sites


def label(parent, text="", color=INK, font=UI, **options):
    return tk.Label(parent, text=text, fg=color, bg=parent["bg"], font=font,
                    anchor="w", justify="left", **options)


def describe(row):
    if row.flow == "invalid" or row.op == "(undecoded)":
        return "The decoder could not establish an instruction at these bytes."
    if row.flow == "conditional":
        return "The processor tests the branch condition. A taken branch uses its encoded destination."
    if row.flow == "return":
        return "The return destination is determined by runtime state."
    if row.flow in {"call", "jump", "indirect"}:
        if row.target is None:
            return "The destination is determined at runtime. These bytes provide no direct branch address."
        return "The instruction encodes a direct transfer of control."
    return {
        "cmp": "Compares the operands and updates the arithmetic flags.",
        "test": "Tests the bitwise AND of the operands and updates the flags.",
        "mov": "Copies the source operand into the destination.",
        "lea": "Computes the effective address and writes it to the destination.",
        "push": "Places the operand on the stack.",
        "pop": "Reads the top of the stack into the destination.",
        "nop": "Advances to the following instruction without changing its operands.",
    }.get(row.op.lower(), "Inspect the decoded operands and their surrounding instructions.")


def demo_source(name, row, end):
    """Source correspondence applies only to the two known, hashed case listings."""
    build, _, function = name.partition(" · ")
    if function == "ready" and build == "plain":
        return 10, "return !(now < deadline);"
    if function == "ready" and build == "encoded":
        if row.rva < 0x15:
            return 5, "volatile unsigned char state = now < deadline ? 0x5A : 0xC3;"
        return 6, "return state == 0xC3;"
    if function == "main":
        return {
            0x55: (17, "if (ready(deadline - 0.25, deadline)) return 1;"),
            0x64: (18, "if (!ready(deadline, deadline)) return 2;"),
            0x77: (19, "if (!ready(deadline + 0.25, deadline)) return 3;"),
            0x85: (16, "for (double deadline : deadlines)"),
        }.get(end.rva)
    return None


class _Reader(ttk.Notebook):
    """Route an explicit tab destination to its live undocked or split surface."""

    def select(self, tab_id=None):
        alternate = getattr(self, "external", {})
        if tab_id is not None and str(tab_id) in alternate:
            pane = alternate[str(tab_id)]
            pane.winfo_toplevel().lift()
            pane.focus_selection()
            return str(pane)
        return super().select(tab_id)


class LinkedViews(tk.Frame):
    def __init__(self, parent, on_select, on_navigate):
        super().__init__(parent, bg=CANVAS)
        self.on_select, self.on_navigate = on_select, on_navigate
        self.rows, self.addresses = [], []
        self.image = None
        self.strings = ()
        self.string_refs = set()
        self.flow_graph = build_graph(())
        self.index = -1
        self.is_dll = True
        self.name = ""
        self.mapped = set()
        self.decompile_busy = False
        self.start_decompile = self.cancel_decompile = None
        self.compact = None
        self.split_width = max(760, font.Font(self, font=MONO).measure("0" * 78) + 130)
        self.active_pane = 0
        self.listing_first = True
        self.floating = set()
        self.graph_only = self.deep_mode = False
        self.deep_room = False
        self.tabs = tk.Frame(self, bg=SURFACE)
        self.split = tk.PanedWindow(self, orient="horizontal", bg=LINE, borderwidth=0,
                                    sashwidth=5, sashrelief="flat", opaqueresize=True)
        self.split.pack(fill="both", expand=True)
        self.split_sash = Sash(self.split, .55)
        self.machine = tk.Frame(self.split, bg=CANVAS)
        apply_theme(self)
        self.reader_host = tk.Frame(self.split, bg=SURFACE)
        self.reader_split = tk.PanedWindow(self.reader_host, orient="vertical", bg=LINE, borderwidth=0,
                                          sashwidth=5, sashrelief="flat", opaqueresize=True)
        self.reader_split.pack(fill="both", expand=True)
        self.struct_sash = Sash(self.reader_split, .55)
        self.reader_split.bind("<Configure>", self._deep_size)
        self.reader = _Reader(self.reader_split, style="Insight.TNotebook")
        self.reader.external = {}
        self.reader_split.add(self.reader, stretch="always")
        self.reader.enable_traversal()
        self.reader_picker = ttk.Combobox(self.reader_host, state="readonly", width=12)
        self.reader_picker.bind("<<ComboboxSelected>>", self._pick_reader)
        self.reader.bind("<<NotebookTabChanged>>", self._reader_choices, add="+")
        self.reader.bind("<Configure>", self._reader_choices, add="+")
        self.reading = tk.Frame(self.reader, bg="#191719", padx=12, pady=6)
        self.reader.add(self.reading,text="Instruction")
        self.graph = GraphView(self.reader, on_navigate)
        self.reader.add(self.graph, text="Graph")
        self.pseudo = GhidraPane(self.reader,self._decompile_action,self._select_line,self._follow_evidence)
        self.reader.add(self.pseudo,text="Ghidra pseudocode")
        self.struct = StructLayout(self.reader_split)
        self.stack = StackFrame(self.reader, self._stack_action, self._struct_slot,
                                lambda: self.reader.select(self.struct))
        self.reader.add(self.stack, text="Stack Frame")
        self.pane_number = tk.IntVar(self, value=self.active_pane)
        self.tabs_buttons = []
        for number, title in enumerate(("Listing", "Interpretation")):
            button = ttk.Radiobutton(self.tabs, text=title, value=number, variable=self.pane_number,
                                     command=lambda n=number: self._layout(n), style="Insight.Switch.TRadiobutton")
            self.tabs.columnconfigure(number, weight=1, uniform="panes")
            button.grid(row=0, column=number, sticky="ew")
            self.tabs_buttons.append(button)
        self._build_listing()
        self._build_reading()
        self.bind("<Configure>", self._resized)
        self.bind("<<InsightFontsChanged>>", self.fonts_changed)

    def fonts_changed(self, _event=None):
        self.split_width = max(760, font.Font(self, font=MONO).measure("0" * 78) + self.winfo_pixels("97p"))
        self.refresh_layout()

    def _build_listing(self):
        title_bar = tk.Frame(self.machine,bg=CANVAS)
        title_bar.pack(fill="x", padx=8, pady=(3,2))
        self.decompile_button = ttk.Button(title_bar, text="Decompile with Ghidra", command=self._decompile_action)
        self.heading = label(title_bar, font=UI_TITLE)
        self.heading.pack(side="left",fill="x",expand=True,padx=2)
        body = tk.Frame(self.machine, bg=CANVAS)
        iris_bar = tk.Frame(body, bg=SURFACE)
        iris_bar.pack(side="left", fill="y")
        label(iris_bar, "Iris", MUTED, UI_SMALL).pack()
        self.iris = tk.Canvas(iris_bar, width=33, height=40, bg=SURFACE, highlightthickness=1,
                              highlightcolor=AMBER, highlightbackground=LINE, takefocus=True,
                              cursor="crosshair")
        self.iris.pack(fill="y", expand=True)
        self.iris.bind("<Configure>", lambda _e: self._iris_ticks())
        self.iris.bind("<Button-1>", self._scrub)
        self.iris.bind("<B1-Motion>", self._scrub)
        self.iris.bind("<Motion>", self._iris_hover)
        self.iris.bind("<Leave>", lambda _: self._heat_caption())
        self.iris.bind("<FocusIn>", lambda _:self.byte_caption.configure(
            text="Iris · teal string · white call · amber conditional · crimson jump · ↑/↓ move"))
        self.iris.bind("<FocusOut>", lambda _:self._heat_caption())
        for key, delta in (("Up",-1),("Down",1),("Prior",-10),("Next",10)):
            self.iris.bind(f"<{key}>", lambda _e, d=delta:self._iris_step(d))

        table = tk.Frame(body, bg=CANVAS)
        table.pack(fill="both", expand=True)
        table.columnconfigure(0, weight=1)
        table.rowconfigure(0, weight=1)
        self.listing = ttk.Treeview(table, columns=("address", "op", "args"), show="headings",
                                    height=5, style="Insight.Treeview", selectmode="browse")
        for col, title, width in (("address", "RVA", 94), ("op", "Instruction", 85), ("args", "Operands", 230)):
            self.listing.heading(col, text=title, anchor="w")
            self.listing.column(col, width=width, minwidth=55, stretch=col == "args")
        self.listing.grid(row=0, column=0, sticky="nsew")
        scroll = ttk.Scrollbar(table, command=self.listing.yview, style="Insight.Vertical.TScrollbar")
        scroll.grid(row=0, column=1, sticky="ns")
        def scroll_changed(first, last):
            scroll.set(first, last)
            self._iris_cursor()
        self.listing.configure(yscrollcommand=scroll_changed)
        self.listing.bind("<<TreeviewSelect>>", self._picked)
        self.listing.bind("<ButtonRelease-1>", self._listing_click)
        self.listing.tag_configure("mapped", background="#16433e", foreground="#e3fff8")
        self.listing.tag_configure("branch", foreground="#f9c25d")
        bytes_header = tk.Frame(self.machine, bg=CANVAS)
        label(bytes_header, "Bytes", font=UI_BOLD).pack(side="left")
        self.heat = tk.BooleanVar(value=True)
        tk.Checkbutton(bytes_header, text="Entropy overlay", variable=self.heat, command=self._bytes,
                       bg=CANVAS, fg=MUTED, activebackground=CANVAS, activeforeground=INK,
                       selectcolor=SURFACE, font=UI, highlightthickness=0).pack(side="right")
        self.hex = tk.Text(self.machine, height=3, width=25, bg=CANVAS, fg=INK, font=MONO,
                           highlightthickness=1, highlightbackground=LINE, borderwidth=0,
                           relief="flat", padx=5, pady=2, wrap="none", exportselection=False, takefocus=False)
        self.hex_cells = []
        self.hex.tag_configure("offset", foreground=MUTED)
        for n, color in enumerate(("#262122", "#422c25", "#5c3626", "#78402a")):
            self.hex.tag_configure(f"heat{n}", background=color)
        self.hex.tag_configure("zero", background="#222022")
        self.hex.tag_configure("selected", background="#632832", foreground="white", underline=True)
        self.hex.configure(state="disabled")
        self.byte_caption = label(self.machine, color=MUTED, font=UI_SMALL)
        self.byte_caption.pack(side="bottom", fill="x", padx=8, pady=(0, 4))
        self.byte_caption.bind("<Configure>", lambda e:self.byte_caption.configure(wraplength=max(48,e.width-4)))
        self.hex.pack(side="bottom", fill="x", padx=8)
        bytes_header.pack(side="bottom", fill="x", padx=8)
        self.runtime_line = label(self.machine, color=TEAL, font=MONO)
        self.runtime_line.bind("<Configure>", lambda e:self.runtime_line.configure(wraplength=max(120,e.width-6)))
        body.pack(fill="both", expand=True)

    def _build_reading(self):
        canvas = tk.Canvas(self.reading, bg=self.reading["bg"], highlightthickness=0, width=1, height=1)
        scroll = ttk.Scrollbar(self.reading, command=canvas.yview, style="Insight.Vertical.TScrollbar")
        scroll.pack(side="right", fill="y")
        canvas.configure(yscrollcommand=scroll.set)
        canvas.pack(fill="both", expand=True)
        content = tk.Frame(canvas, bg=self.reading["bg"])
        item = canvas.create_window(0, 0, window=content, anchor="nw")
        canvas.bind("<Configure>", lambda e: canvas.itemconfigure(item, width=e.width))
        content.bind("<Configure>", lambda e: canvas.configure(scrollregion=(0, 0, e.width, e.height)))
        self.source_label = label(content, color=MUTED)
        self.source_label.pack(fill="x")
        self.instruction = label(content, font=MONO_TITLE)
        self.instruction.pack(fill="x", pady=(3, 5))
        self.explanation = label(content)
        self.explanation.pack(fill="x")
        tk.Frame(content, bg=LINE, height=1).pack(fill="x", pady=7)
        label(content, "Local control flow", font=UI_BOLD).pack(fill="x")
        self.flow_caption = label(content, color=MUTED, font=MONO)
        self.flow_caption.pack(fill="x")
        self.flow_node = tk.Canvas(content, height=42, width=70, bg=content["bg"],
                                   highlightthickness=0)
        self.flow_node.pack(fill="x", pady=(3, 0))
        self.edges = tk.Frame(content, bg=content["bg"])
        self.edges.pack(fill="x")
        content.bind("<Configure>", self._wrap, add="+")

    def _wrap(self, event):
        for widget in (self.instruction, self.explanation, self.flow_caption, self.source_label):
            widget.configure(wraplength=max(100, event.width - 30))
        self._draw_node()

    def _resized(self, event):
        if event.width <= 1:
            return
        vertical = str(self.split.cget("orient")) == "vertical"
        compact = self.graph_only or (event.height < self.winfo_pixels("165p") if vertical else event.width < self.split_width)
        if self.compact != compact:
            self.compact = compact
            self._layout(self.active_pane)

    def refresh_layout(self):
        vertical = str(self.split.cget("orient")) == "vertical"
        self.compact = self.graph_only or (self.winfo_height() < self.winfo_pixels("165p") if vertical
                                           else self.winfo_width() < self.split_width)
        self._layout(self.active_pane)

    def _layout(self, number):
        self.active_pane = number
        for pane in self.split.panes():
            self.split.forget(pane)
        panels = (("listing", self.machine), ("reader", self.reader_host))
        available = [(name,pane) for name,pane in panels if name not in self.floating]
        if len(available)<2:
            self.tabs.pack_forget()
            for _, pane in available:
                self.split.add(pane, stretch="always")
        elif self.compact:
            self.tabs.pack(before=self.split, fill="x")
            self.split.add(panels[number][1], stretch="always")
            self.pane_number.set(number)
        else:
            self.tabs.pack_forget()
            for _,pane in (available if self.listing_first else reversed(available)):
                self.split.add(pane, minsize=90, stretch="always")
            self._fit_reader_tabs()
            self.split_sash.place()

    def _fit_reader_tabs(self):
        self._reader_choices()
        if len(self.split.panes()) == 2 and str(self.split.cget("orient")) == "horizontal":
            self.split.paneconfigure(self.reader_host, minsize=215)

    def _reader_choices(self, _event=None):
        # Tk notebooks clip their trailing tabs on a narrow detached monitor or large type.
        titles = [self.reader.tab(tab,"text") for tab in self.reader.tabs()
                  if self.reader.tab(tab,"state") == "normal"]
        width = self.reader.winfo_width()
        tab_font = font.nametofont(UI, root=self)
        needed = sum(tab_font.measure(t)+self.winfo_pixels("16p") for t in titles)
        if 1 < width < needed and titles:
            self.reader_picker.configure(values=titles)
            current = self.reader.select()
            self.reader_picker.set(self.reader.tab(current,"text") if current else "")
            if not self.reader_picker.winfo_manager():
                self.reader_picker.pack(before=self.reader_split, fill="x")
        else:
            self.reader_picker.pack_forget()

    def _pick_reader(self, _event=None):
        title = self.reader_picker.get()
        for tab in self.reader.tabs():
            if self.reader.tab(tab,"text") == title and self.reader.tab(tab,"state") == "normal":
                self.reader.select(tab)
                break

    def _struct_slot(self, slot):
        if slot:
            if getattr(self, "on_layout_slot", None):
                self.on_layout_slot(slot)
            else:
                self.struct.populate(slot, self.rows)
        else:
            self.struct.reset("Select recovered stack storage to inspect its layout.")
        self._struct_position()
        self._fit_reader_tabs()

    def _deep_size(self, event):
        room = event.height >= self.winfo_pixels("220p")
        if room != self.deep_room:
            self.deep_room = room
            if self.deep_mode:
                self._struct_position()

    def _struct_position(self):
        key = str(self.struct)
        external = "structure" in self.floating or (self.deep_mode and self.deep_room)
        if external:
            if key in self.reader.tabs():
                self.reader.forget(self.struct)
            self.reader.external[key] = self.struct
            if "structure" not in self.floating and key not in map(str,self.reader_split.panes()):
                self.reader_split.add(self.struct, minsize=80, stretch="always")
                self.struct_sash.place()
        else:
            self.reader.external.pop(key,None)
            if key in map(str,self.reader_split.panes()):
                self.reader_split.forget(self.struct)
            if self.struct.current_slot:
                self.reader.add(self.struct, text="Struct Layout")
            elif key in self.reader.tabs():
                if self.reader.select() == key:
                    self.reader.select(self.stack)
                self.reader.hide(self.struct)

    def _address(self, at):
        return f"0x{at:08X}" if self.is_dll else f"+0x{at:02X}"

    def show(self, rows, index, name, is_dll=True, coverage=""):
        """Replace the current decoded range, then resolve every view against the same row."""
        self.rows, self.name, self.is_dll = rows, name, is_dll
        self.routine_bytes = b"".join(r.raw for r in rows) if self.image is None else b""
        self.string_refs = string_sites(rows, self.strings)
        self.index = -1
        self.addresses = [r.rva for r in rows]
        self.row_at = {rva:i for i,rva in enumerate(self.addresses)}
        self.flow_graph = build_graph(rows)
        self.graph.load(rows, self.flow_graph, self._address, coverage)
        self.mapped.clear()
        self.decompiler_state("Recover this routine’s pseudocode and stack variables.")
        if is_dll:
            self.reader.add(self.pseudo,text="Ghidra pseudocode")
            self.reader.add(self.stack, text="Stack Frame")
            self.decompile_button.pack(side="right",before=self.heading)
        else:
            if self.reader.select() != str(self.graph):
                self.reader.select(self.reading)
            self.reader.hide(self.pseudo)
            self.reader.hide(self.stack)
            self.decompile_button.pack_forget()
        self._fit_reader_tabs()
        self.listing.delete(*self.listing.get_children())
        self.listing.heading("address", text="RVA" if is_dll else "Offset")
        self.heading.configure(text=f"{name}   ·   {len(rows):,} instructions")
        for i, row in enumerate(rows):
            self.listing.insert("", "end", iid=str(i), values=(self._address(row.rva), row.op, row.args),
                                tags=("branch",) if row.flow in {"jump", "conditional"} else ())
        self._iris_ticks()
        if rows:
            self.select(index)
        else:
            for widget in (self.instruction, self.explanation, self.source_label, self.byte_caption, self.flow_caption):
                widget.configure(text="")
            self.flow_node.delete("all")
            for child in self.edges.winfo_children():
                child.destroy()
            self._bytes()

    def configure_decompiler(self, on_decompile, on_cancel):
        self.start_decompile, self.cancel_decompile = on_decompile, on_cancel

    def show_pseudocode(self):
        if self.compact:
            self._layout(1)
        self.reader.select(self.pseudo)

    def _decompile_action(self):
        self.show_pseudocode()
        if self.decompile_busy:
            if self.cancel_decompile:
                self.cancel_decompile()
        elif self.pseudo.result is None and self.start_decompile:
            self.start_decompile()

    def _stack_action(self):
        if self.decompile_busy:
            self.cancel_decompile()
        elif self.start_decompile:
            self.start_decompile(reveal=False)

    def decompiler_state(self, message, busy=False):
        self._mark_mapped(())
        self.decompile_busy = busy
        self.pseudo.reset(message,busy)
        self.stack.reset(message, busy)
        self.decompile_button.configure(text="Cancel Ghidra" if busy else "Decompile with Ghidra")

    def set_decompilation(self, result, *, reveal=True):
        self.decompile_busy = False
        self.pseudo.populate(result,self.rows)
        at = self.rows[self.index].rva if self.index >= 0 else None
        slots = getattr(result, "stack", ())
        regions = self.stack_regions(slots) if getattr(self, "stack_regions", None) else ()
        self.stack.populate(slots, self.rows, at, regions=regions)
        if getattr(self, "on_stack_labels", None):
            self.on_stack_labels()
        self.decompile_button.configure(text="Show pseudocode")
        if reveal:
            self.show_pseudocode()
        if self.index >= 0:
            self.pseudo.cursor(self.rows[self.index].rva)

    def _mark_mapped(self, rvas):
        indices = {self.row_at[rva] for rva in rvas}
        for i in self.mapped ^ indices:
            tags = ["branch"] if self.rows[i].flow in {"jump","conditional"} else []
            if i in indices:
                tags.append("mapped")
            self.listing.item(str(i),tags=tags)
        self.mapped = indices

    def _select_line(self, rvas, follow=True):
        self._mark_mapped(rvas)
        if rvas and follow:
            current = self.rows[self.index].rva if self.index >= 0 else None
            self._follow_evidence(current if current in rvas else rvas[0])
            first, stop = self.listing.yview()
            top = round(first * len(self.rows))
            visible = round((stop-first) * len(self.rows))
            low, high = min(self.mapped), max(self.mapped)
            if high-low < visible:
                # Shift only far enough to reveal the whole group without moving the cursor.
                wanted = min(low, max(top, high-visible+1))
                if wanted != top:
                    self.listing.yview_moveto(wanted / len(self.rows))

    def _follow_evidence(self, rva):
        i = self.row_at[rva]
        self.select(i,from_line=True)
        self.on_select(i)

    def _listing_click(self, event):
        if self.pseudo.line is not None and self.listing.identify_row(event.y) == str(self.index):
            self._mark_mapped(())
            self.pseudo.cursor(self.rows[self.index].rva)

    def select(self, index, from_line=False):
        if not 0 <= index < len(self.rows):
            return
        self.index = index
        row = self.rows[index]
        if row.flow == "call":
            self.stack.select_call(row.rva)
        if not from_line:
            self._mark_mapped(())
            self.pseudo.cursor(row.rva)
        self.listing.selection_set(str(index))
        self.listing.focus(str(index))
        self.listing.see(str(index))
        self._bytes()
        self._flow()
        self.graph.select(index)
        self._iris_cursor()

    def _picked(self, _event):
        items = self.listing.selection()
        if items and int(items[0]) != self.index:
            self.select(int(items[0]))
            self.on_select(self.index)

    def _scrub(self, event):
        if self.rows:
            first, last = self.addresses[0], self.addresses[-1]
            at = first + max(0, min(1, event.y/max(1, self.iris.winfo_height()-1))) * (last - first)
            index = max(0, bisect_right(self.addresses, at) - 1)
            self.listing.selection_set(str(index))
            self.listing.focus_set()

    def _iris_step(self, delta):
        if self.rows:
            self.on_select(max(0, min(len(self.rows)-1, self.index+delta)))
        return "break"

    def _iris_hover(self, event):
        if self.rows:
            first, last = self.addresses[0], self.addresses[-1]
            at = first + max(0, min(1, event.y/max(1, self.iris.winfo_height()-1))) * (last-first)
            row = self.rows[max(0, bisect_right(self.addresses, at)-1)]
            kind = "string reference" if row.rva in self.string_refs else row.flow
            self.byte_caption.configure(text=f"Iris · {self._address(row.rva)} · {row.op} {row.args} · {kind}")

    def _iris_y(self, at):
        start = self.addresses[0]
        end = self.addresses[-1] + len(self.rows[-1].raw)
        return min(self.iris.winfo_height()-1, int((at-start) * self.iris.winfo_height() / max(1,end-start)))

    def _iris_ticks(self):
        self.iris.delete("all")
        if not self.rows:
            return
        ticks = set()
        for row in self.rows:
            y = self._iris_y(row.rva)
            ticks.add((y, row.flow if row.flow in ("jump","conditional","call") else "instruction"))
            if row.rva in self.string_refs:
                ticks.add((y, "string"))
        lanes = {"instruction": (12,19,LINE), "string": (2,10,TEAL), "call": (12,20,INK),
                 "jump": (22,31,CRIMSON), "conditional": (22,31,AMBER)}
        for y, kind in sorted(ticks, key=lambda item: (item[1] != "instruction", item[1], item[0])):
            x1, x2, color = lanes[kind]
            self.iris.create_line(x1, y, x2, y, fill=color, tags=kind)
        self._iris_cursor()

    def _iris_cursor(self):
        self.iris.delete("marker")
        if self.index < 0 or not self.rows:
            return
        first, stop = self.listing.yview()
        start = min(len(self.rows)-1, int(first * len(self.rows)))
        end = min(len(self.rows)-1, max(start, round(stop * len(self.rows))-1))
        self.iris.create_rectangle(3, self._iris_y(self.rows[start].rva), 29,
                                   self._iris_y(self.rows[end].rva+len(self.rows[end].raw)),
                                   outline="#b1a3a9", tags="marker")
        y = self._iris_y(self.rows[self.index].rva)
        self.iris.create_line(1, y, 32, y, fill=CRIMSON, width=3, tags="marker")

    def _bytes(self):
        self.heat_samples = {}
        self.hex_cells.clear()
        self.hex.configure(state="normal")
        self.hex.delete("1.0", "end")
        if self.index >= 0:
            row = self.rows[self.index]
            base = self.rows[0].rva
            start = base + (row.rva - base)//8*8
            stop = max(start+16, row.rva+len(row.raw))
            stop += (start-stop) % 8
            if self.heat.get():
                self.heat_samples = entropy_windows(self.image, start, stop, base=base, data=self.routine_bytes)
            data = {}
            for i in range(max(0, bisect_right(self.addresses, start)-1), len(self.rows)):
                other = self.rows[i]
                if other.rva >= stop:
                    break
                data.update((other.rva+j, b) for j,b in enumerate(other.raw))
            for addr in range(start, stop, 8):
                chunk = [data.get(addr+j) for j in range(8)]
                known = [b for b in chunk if b is not None]
                if not known:
                    break
                self.hex.insert("end", self._address(addr)+"  ", "offset")
                for j,b in enumerate(chunk):
                    tag = "selected" if row.rva <= addr+j < row.rva+len(row.raw) else ""
                    sample = self.heat_samples.get(addr+j)
                    if not tag and sample and b is not None:
                        tag = "zero" if b == 0 else f"heat{min(3, int(sample[0]/1.5))}"
                    if b is not None:
                        self.hex_cells.append((addr+j, self.hex.index("end-1c")))
                    self.hex.insert("end", "  " if b is None else f"{b:02X}", tag)
                    self.hex.insert("end", " ")
                self.hex.insert("end","\n")
            self.hex.configure(height=(stop - start + 7)//8)
            self._heat_caption()
        self.hex.configure(state="disabled")

    def selected_bytes(self):
        bounds = self.hex.tag_ranges("sel")
        if not bounds:
            return None
        addresses = [at for at, pos in self.hex_cells
                     if self.hex.compare(pos, "<", bounds[1]) and self.hex.compare(pos + "+2c", ">", bounds[0])]
        if not addresses or addresses[-1] - addresses[0] + 1 != len(addresses):
            raise ValueError("Select a continuous range of displayed byte cells.")
        return addresses[0], len(addresses)

    def _heat_caption(self):
        if not self.rows or self.index < 0:
            return
        if not self.heat.get():
            self.byte_caption.configure(text="Selected instruction bytes underlined")
            return
        sample = self.heat_samples.get(self.rows[self.index].rva)
        text = (f"H {sample[0]:.2f} bits/byte · {sample[1]} B window · amber = higher · 00 = zero"
                if sample else "No backed sample for this instruction.")
        self.byte_caption.configure(text=text)

    def _flow(self):
        row = self.rows[self.index]
        block = self.flow_graph.blocks[self.flow_graph.block_at(self.index)]
        first, stop = block.first, block.stop
        end = self.rows[stop-1]
        self.block_end = end
        self.source_label.configure(text="Decoded instruction · x64" if self.is_dll else "Retained instruction · x64")
        self.instruction.configure(text=f"{self._address(row.rva)}   {row.op} {row.args}".rstrip())
        mapping = None if self.is_dll else demo_source(self.name, row, end)
        self.explanation.configure(text=(f"cooldown.cpp · line {mapping[0]}\n{mapping[1]}"
                                        if mapping else describe(row)))
        self.flow_caption.configure(text=f"Block {self._address(self.rows[first].rva)} – {self._address(end.rva+len(end.raw)-1)} inclusive")
        self._draw_node()
        for child in self.edges.winfo_children():
            child.destroy()
        links = []
        if row.flow == "call" and row.target is not None:
            links.append(("Follow call", row.target))
        if not self.is_dll:
            call = next((i for i in range(first, stop)
                         if self.rows[i].op.lower() == "call" and self.rows[i].args.strip() == "ready"), None)
            if call is not None:
                def follow_ready():
                    if self.index != call:
                        self.select(call)
                        self.on_select(call)
                    self.on_navigate("ready")
                ttk.Button(self.edges, text=f"Follow call  {self._address(self.rows[call].rva)} → ready",
                           command=follow_ready, style="Edge.TButton").pack(fill="x", pady=1)
        labels = {"taken": "Taken", "jump": "Jump", "fallthrough": "Fall through"}
        for edge in block.edges:
            if edge.kind in labels and (edge.block is not None or
                    (edge.kind in {"taken", "jump"} and self.is_dll and edge.reason == OUTSIDE)):
                links.append((labels[edge.kind], edge.target))
            elif edge.reason:
                destination = self._address(edge.target) + " · " if edge.target is not None else ""
                label(self.edges, destination + edge.reason, MUTED).pack(fill="x", padx=8)
        for title, at in links:
            style = "Branch.Edge.TButton" if title in {"Taken","Jump"} else "Edge.TButton"
            cmd = ttk.Button(self.edges, text=f"{title}  {self._address(at)}",
                             command=lambda a=at: self.on_navigate(a), style=style)
            cmd.pack(fill="x", pady=1)

    def _draw_node(self):
        self.flow_node.delete("all")
        if self.index < 0:
            return
        width = max(40, self.flow_node.winfo_width()-3)
        self.flow_node.create_polygon(1,7, 7,1, width,1, width,26, width-6,32, 1,32,
                                      outline=LINE, fill="#30252a")
        self.flow_node.create_line(2,7,2,28, fill=CRIMSON, width=2)
        end = self.block_end
        self.flow_node.create_text(9,17,anchor="w",fill=INK,font=MONO,
                                   text=f"Block exit   {self._address(end.rva)}   {end.op}")
        self.flow_node.create_line(18,32,18,42,fill=AMBER)

