"""Physical stack storage and byte-checked references in one x64 routine."""

from bisect import bisect_left, bisect_right
from dataclasses import dataclass
from itertools import islice

from .struct_layout import LARGE_INTEGER


@dataclass(frozen=True)
class StackToken:
    start: int
    end: int
    offset: int
    size: int


@dataclass(frozen=True)
class StackAccess:
    rva: int
    kind: str
    offset: int
    size: int


@dataclass(frozen=True)
class StackSlot:
    name: str
    offset: int
    size: int
    accesses: tuple[StackAccess, ...]
    layout_calls: tuple[int, ...] = ()

    @property
    def layout(self):
        return LARGE_INTEGER if self.layout_calls else None


MAX_REGIONS = 128
MAX_REGION_LINKS = 65_536


def _stack_range(offset, size):
    if (type(offset) is not int or type(size) is not int or not -(2**31) <= offset < 2**31
            or not 1 <= size <= 2**31 or offset + size > 2**31):
        raise ValueError("Invalid signed stack offset or region size.")


def project_regions(ranges, slots):
    """Bind analyst regions to recovered storage and the original verified access objects."""
    ranges, slots = tuple(islice(ranges, MAX_REGIONS + 1)), tuple(islice(slots, 8193))
    if len(ranges) > MAX_REGIONS or len(slots) > 8192:
        raise ValueError("Stack region or recovered slot count exceeds the supported limit.")
    if not ranges:
        return ()
    native = {}
    evidence = set()
    links = 0
    for slot in slots:
        _stack_range(slot.offset, slot.size)
        native[slot.offset, slot.size] = slot
        links += len(slot.accesses)
        if links > MAX_REGION_LINKS:
            raise ValueError("Recovered stack access count exceeds the supported limit.")
        evidence.update(slot.accesses)
    if not native:
        raise ValueError("Recover stack storage before defining a region.")
    # Prefix maxima identify intersection with a recovered slot even for nested ranges.
    sorted_slots = sorted(native)
    starts, ends = [], []
    for at, size in sorted_slots:
        starts.append(at)
        ends.append(max(ends[-1] if ends else at, at + size))
    keys = []
    for region in ranges:
        if not isinstance(region, (tuple, list)) or len(region) != 2:
            raise ValueError("A stack region needs an offset and size.")
        at, size = region
        _stack_range(at, size)
        stop = at + size
        i = bisect_left(starts, stop) - 1
        if at < starts[0] or stop > ends[-1] or i < 0 or ends[i] <= at:
            raise ValueError("The region must fit the recovered frame and intersect recovered storage.")
        keys.append((at, size))
    if len(set(keys)) != len(keys):
        raise ValueError("Duplicate stack region.")

    ordered = sorted(evidence, key=lambda s: (s.offset, s.rva, s.kind, s.size))
    addresses = [site.offset for site in ordered]
    widths = max((max(site.size, 1) for site in ordered), default=1)
    projected, available = [], MAX_REGION_LINKS
    for at, size in keys:
        if (at, size) in native:
            slot = native[at, size]
        else:
            # Binary-search the actual starts. Width-zero address records identify a
            # point in the frame; they do not become read/write evidence for a field.
            first, stop = bisect_right(addresses, at - widths), bisect_left(addresses, at + size)
            hits = []
            for i in range(first, stop):
                site = ordered[i]
                if site.offset + max(site.size, 1) > at:
                    if len(hits) >= available:
                        raise ValueError("These regions exceed the combined stack access display limit.")
                    hits.append(site)
            hits.sort(key=lambda s: (s.rva, s.kind, s.offset, s.size))
            slot = StackSlot("Analyst region", at, size, tuple(hits))
        available -= len(slot.accesses)
        if available < 0:
            raise ValueError("These regions exceed the combined stack access display limit.")
        projected.append(slot)
    return tuple(projected)


def project_region(offset, size, slots):
    return project_regions(((offset, size),), slots)[0]


def _records(record, key, limit):
    items = record.get(key, [])
    if not isinstance(items, list) or len(items) > limit or not all(isinstance(s, dict) for s in items):
        raise ValueError("Malformed Ghidra stack records.")
    return items


def _region(record, address_only=False):
    offset, size = record.get("offset"), record.get("size")
    minimum = 0 if address_only else 1
    if (type(offset) is not int or type(size) is not int or not -(2**31) <= offset < 2**31
            or not minimum <= size <= 2**31 or offset + size > 2**31):
        raise ValueError("Invalid Ghidra stack storage range.")
    return offset, size


def stack_tokens(line, regions):
    result = []
    previous = 0
    for item in _records(line, "stack", len(line["text"])):
        offset, size = _region(item)
        start, end = item.get("start"), item.get("end")
        if (type(start) is not int or type(end) is not int or
                not previous <= start < end <= len(line["text"]) or (offset, size) not in regions):
            raise ValueError("Invalid Ghidra stack token.")
        result.append(StackToken(start, end, offset, size))
        previous = end
    return tuple(result)


def stack_frame(doc, raw, listing, rows, image):
    names = {}
    for item in _records(doc, "stack", 8192):
        key = _region(item)
        name = item.get("name")
        if not isinstance(name, str) or not 0 < len(name) <= 1024 or not name.isprintable():
            raise ValueError("Invalid Ghidra stack symbol name.")
        names.setdefault(key, []).append(name)

    # Duplicate accesses in raw p-code (e.g. updating individual flags) describe
    # one machine instruction. Only a corroborated instruction may become a link.
    sites = set()
    counter_calls = {}
    slots = None
    by_rva = {row.rva: row for row in rows}
    for item in _records(doc, "accesses", 32768):
        rva, kind = item.get("rva"), item.get("kind")
        if (type(rva) is not int or not 0 <= rva < 2**32
                or kind not in ("Read", "Write", "Address", "Argument 1")):
            raise ValueError("Invalid Ghidra stack reference.")
        address_only = kind in ("Address", "Argument 1")
        offset, size = _region(item, address_only)
        if (address_only and size != 0) or size > 512:
            raise ValueError("Invalid Ghidra stack access width.")
        if rva not in listing or str(rva) not in raw:
            continue
        if raw[str(rva)] != listing[rva]:
            raise ValueError(f"Ghidra and the snapshot disagree on the bytes at RVA 0x{rva:X}.")
        if kind == "Argument 1":
            # Microsoft documents QueryPerformanceCounter's sole argument as an
            # [out] LARGE_INTEGER*. Verify the direct IAT call in the original PE.
            from .xrefs import _iat_slot, read_imports
            if slots is None:
                try:
                    slots = read_imports(image)[0] if image is not None else {}
                except ValueError:
                    slots = {}  # Unavailable import metadata cannot prove a callee effect.
            row = by_rva[rva]
            symbol = slots.get(_iat_slot(row, 0x15))
            if (row.op != "call" or symbol is None or symbol.name != "QueryPerformanceCounter"
                    or symbol.module.casefold() not in ("kernel32.dll", "kernelbase.dll",
                                                        "api-ms-win-core-profile-l1-1-0.dll")):
                continue
            kind, size = "Write via call", LARGE_INTEGER.size
            counter_calls.setdefault(offset, set()).add(rva)
        sites.add(StackAccess(rva, kind, offset, size))

    ordered = sorted(sites, key=lambda site: (site.offset, site.rva, site.kind))
    offsets = [site.offset for site in ordered]
    result = []
    links = 0
    for (offset, size), labels in sorted(names.items()):
        # References can partially overlap a slot (a dword read of a qword local).
        start = bisect_left(offsets, offset - 511)
        stop = bisect_left(offsets, offset + size)
        matches = [site for site in ordered[start:stop] if site.offset + max(1, site.size) > offset]
        links += len(matches)
        if links > 65536:
            raise ValueError("Stack reference count exceeds the display limit.")
        matches.sort(key=lambda site: (site.rva, site.kind, site.offset, site.size))
        # A neighboring slot can overlap the output write. Bind the union only
        # when the recovered storage matches both the argument address and size.
        calls = tuple(sorted(counter_calls.get(offset, ()))) if size == LARGE_INTEGER.size else ()
        result.append(StackSlot(" / ".join(dict.fromkeys(labels)), offset, size, tuple(matches), calls))
    return tuple(result)
