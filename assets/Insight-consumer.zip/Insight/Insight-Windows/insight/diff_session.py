"""A temporary, read-only comparison beside the open investigation."""

from collections import OrderedDict
from threading import Event
import tkinter as tk

from . import dialogs
from .binary_diff import compare_builds, inspect_match
from .diff_view import DiffView
from .investigation import open_dll
from .private_matches import is_private, suggest_private


def _place_comparison(window, parent):
    """Open over the investigation, keeping its frame inside the owner's monitor."""
    x, y = parent.winfo_x(), parent.winfo_y()
    width, height = max(630, parent.winfo_width()), max(420, parent.winfo_height())
    window.geometry(f"{width}x{height}+{x}+{y}")
    if window.tk.call("tk", "windowingsystem") != "win32":
        return

    from ctypes import Structure, WinDLL, byref, sizeof, wintypes

    class MonitorInfo(Structure):
        _fields_ = [("size", wintypes.DWORD), ("bounds", wintypes.RECT),
                    ("work", wintypes.RECT), ("flags", wintypes.DWORD)]

    window.update_idletasks()
    user32 = WinDLL("user32")
    user32.MonitorFromWindow.restype = wintypes.HMONITOR
    monitor = user32.MonitorFromWindow(wintypes.HWND(int(parent.frame(), 0)), 2)
    info, frame = MonitorInfo(), wintypes.RECT()
    info.size = sizeof(info)
    if (not user32.GetMonitorInfoW(wintypes.HMONITOR(monitor), byref(info))
            or not user32.GetWindowRect(wintypes.HWND(int(window.frame(), 0)), byref(frame))):
        return
    chrome_w = frame.right - frame.left - window.winfo_width()
    chrome_h = frame.bottom - frame.top - window.winfo_height()
    area = info.work
    width = min(width, max(1, area.right - area.left - chrome_w))
    height = min(height, max(1, area.bottom - area.top - chrome_h))
    window.minsize(min(630, width), min(420, height))
    x = max(area.left, min(x, area.right - width - chrome_w))
    y = max(area.top, min(y, area.bottom - height - chrome_h))
    # A literal '+' before a negative coordinate selects an absolute monitor coordinate in Tk.
    window.geometry(f"{width}x{height}+{x}+{y}")


class BinaryComparison:
    def __init__(self, app):
        self.app = app
        self.window = self.panel = None
        self.pending = self.stop = self.poll = None
        self.left = self.right = None
        self.cache = OrderedDict()
        self.previous_focus = None

    def pick(self):
        if self.window:
            self.window.lift()
            return
        selection = dialogs.choose_builds(self.app.root, self.app.case)
        if selection:
            self.open(*selection)

    def open(self, left_path, right_path):
        self.close()
        root = self.app.root
        baseline = self.app.case if left_path is None else None
        if left_path is None and (baseline is None or baseline.image is None):
            raise ValueError("Choose an x64 DLL for build A.")
        preferred_rva = self.app.routine.rva if baseline is not None else None
        self.previous_focus = root.focus_get()
        window = self.window = tk.Toplevel(root)
        window.withdraw()
        window.title("Binary diff — Insight")
        window.transient(root)
        window.minsize(630, 420)
        window.protocol("WM_DELETE_WINDOW", self.close)
        for key in ("<Escape>", "<Alt-Left>"):
            window.bind(key, lambda _: self._return())
        self.panel = DiffView(window, self.inspect, self.close, self.identities,
                              on_private=self.suggest, can_private=self.can_suggest)
        self.panel.pack(fill="both", expand=True)
        _place_comparison(window, root)
        window.deiconify()
        window.grab_set()
        self.panel.back.focus_set()

        def identify(stop):
            left = baseline if baseline is not None else open_dll(left_path)
            if stop.is_set():
                raise ValueError("Comparison cancelled.")
            right = open_dll(right_path)
            return left, right, compare_builds(left, right, stop)

        def ready(result):
            self.left, self.right, matches = result
            self.panel.set_index(matches, self._label(self.left), self._label(self.right),
                                 preferred_rva=preferred_rva)

        self._work("Matching functions in the two read-only snapshots…", identify, ready)

    @staticmethod
    def _label(case):
        return f"{case.label}  ·  {case.digest[:12]}"

    def identities(self):
        if self.left is not None and self.right is not None:
            records = (f"Build {side}  ·  {case.source}\n{len(case.data):,} bytes\nSHA-256  {case.digest}"
                       for side, case in (("A", self.left), ("B", self.right)))
            dialogs.inform(self.window, "Build identities", "\n\n".join(records))

    def can_suggest(self, match):
        if self.left is None or self.right is None or match is None or match.status != "Unmatched":
            return False
        if (match.left is None) == (match.right is None):
            return False
        case, routine = (self.left, match.left) if match.left else (self.right, match.right)
        return is_private(case, routine)

    def suggest(self, match):
        panel = self.panel
        if not self.can_suggest(match) or panel.current_match != match:
            return
        self._cancel()
        left, right, matches = self.left, self.right, panel.matches

        def ready(result):
            candidates, summary = result
            if panel.current_match == match:
                panel.set_candidates(match, candidates, summary)

        self._work("Comparing private functions in the two snapshots…",
                   lambda stop: suggest_private(left, right, matches, match, stop), ready,
                   keep_detail=True)

    def inspect(self, match):
        if self.left is None or self.right is None:
            return
        self._cancel()
        if match is None:
            return
        if match in self.cache:
            self.cache.move_to_end(match)
            self.panel.set_detail(self.cache[match])
            return
        left, right = self.left, self.right

        def ready(detail):
            self.cache[match] = detail
            if len(self.cache) > 3:
                self.cache.popitem(last=False)
            self.panel.set_detail(detail)

        self._work("Decoding and decompiling the selected function…",
                   lambda stop: inspect_match(left, right, match, stop), ready)

    def _work(self, message, work, done, *, keep_detail=False):
        # The shared worker serializes Ghidra jobs. Comparison jobs have their
        # own cancellation token and never change the investigation's bookmark.
        status = self.panel.status.set if keep_detail else self.panel.set_status
        status(message)
        self.stop = Event()
        future = self.pending = self.app.pool.submit(work, self.stop)

        def check():
            self.poll = None
            if self.pending is not future:
                return
            if not future.done():
                self.poll = self.window.after(40, check)
                return
            self.pending = self.stop = None
            try:
                result = future.result()
            except (OSError, ValueError) as error:
                status(str(error))
                return
            done(result)

        self.poll = self.window.after(10, check)

    def _cancel(self):
        if self.poll is not None:
            self.window.after_cancel(self.poll)
        if self.stop is not None:
            self.stop.set()
            self.pending.cancel()
        self.poll = self.pending = self.stop = None

    def _return(self):
        self.close()
        return "break"

    def close(self):
        if self.window is None:
            return
        self._cancel()
        self.window.grab_release()
        self.window.destroy()
        self.window = self.panel = self.left = self.right = None
        self.cache.clear()
        if self.previous_focus and self.previous_focus.winfo_exists():
            self.previous_focus.focus_set()
        self.previous_focus = None
