"""Move between a DLL's import-call matrix and the linked investigation views."""

from collections import deque
from dataclasses import dataclass

from .context_view import ContextView
from .ghidra import Decompilation
from .xref_view import XrefMatrix
from .xrefs import build_index


@dataclass(frozen=True)
class Origin:
    key: str
    rva: int
    raw: bytes
    step: int
    reader_tab: str
    compact_pane: int
    pseudocode: Decompilation | None
    line: int | None
    listing_top: float
    code_top: float
    code_left: float
    symbol_focus: tuple | None
    stack_filter: str
    stack_slot: tuple[int, int] | None
    struct_selection: tuple | None
    stack_from_local: bool
    context_open: bool = False


class CrossReferences:
    def __init__(self, app):
        self.app = app
        self.matrix = XrefMatrix(app.views, self.follow, self.hide)
        self.context = ContextView(app.views.reader, self.follow_context, self.hide_context,
                                   self._caller_matrix, self._type_view)
        self.context_open = False
        self.index = self.origin = self.local_origin = None
        self.parents = deque(maxlen=8)
        self.from_global = False
        self.visible = self.indexing = False
        app.views.pseudo.on_global = self.open_global
        app.views.pseudo.on_local = self.open_local
        app.views.pseudo.on_function = self.open_function
        app.views.stack.on_follow = self.follow_stack
        app.views.struct.on_follow = self.follow_field
        self.reader_tab = app.views.reader.select()
        app.views.reader.bind("<<NotebookTabChanged>>", self._reader_changed, add="+")

    def reset(self, index=None):
        self.hide_context()
        self.context.clear()
        self.hide()
        self.matrix.reset()
        self.index, self.origin = index, None
        self.local_origin = None
        self.parents.clear()
        self.app.xref_back.pack_forget()

    def hide(self):
        if self.indexing and not self.context_open:
            self.app.cancel_work(announce=False)
        self.matrix.place_forget()
        self.visible = False
        if self.app.case:
            if self.context_open:
                self.context.tree.focus_set()
            elif self.from_global:
                self.app.views.pseudo.code.focus_set()
            else:
                self.app.views.listing.focus_set()
        self.from_global = False

    def open_context(self):
        app = self.app
        if not app.case or not app.rows:
            return
        if app.pending is not None and not self.indexing:
            app.status.set("Finish or cancel the current analysis to open the inspector.")
            return
        self.context_open = True
        if self.visible:
            self.hide()
        if app.views.compact:
            app.views._layout(1)
        self.context.place(x=0, y=0, relwidth=1, relheight=1)
        self.context.lift()
        self.context.tree.focus_set()
        self.update_context()
        if app.case.image:
            self._load_index()

    def hide_context(self):
        self.context_open = False
        self.context.place_forget()
        if self.indexing and not self.visible:
            self.app.cancel_work(announce=False)

    def update_context(self, message=None):
        if not self.context_open or not self.app.case or not self.app.rows:
            return
        app = self.app
        tree = getattr(self.index, "call_tree", None)
        if tree is not None and tree.digest != app.case.digest:
            tree = None
            message = "The index belongs to a different snapshot."
        if message is None:
            message = (self.index.coverage if tree else "Indexing reachable calls…" if app.case.image
                       else "Call indexing is available for x64 DLL snapshots.")
        self.context.show(app.case.digest, app.routine, app.rows[app.index], tree, message,
                          dll=bool(app.case.image), has_struct=bool(app.views.struct.current_slot))

    def _type_view(self, name):
        views = self.app.views
        if name == "struct" and views.struct.current_slot is None:
            self.app.status.set("Choose recovered stack storage with an available layout.")
            return
        if self.visible:
            self.hide()
        self.hide_context()
        if views.compact:
            views._layout(1)
        views.reader.select(views.struct if name == "struct" else views.stack)
        if name == "stack" and views.pseudo.result is None:
            self.app.decompile_current(reveal=False)

    def _caller_matrix(self):
        self.matrix.for_caller(self.app.routine.rva)
        self.open()

    def follow_context(self, site, routine):
        app = self.app
        tree = getattr(self.index, "call_tree", None)
        if not self.context_open or not tree or tree.digest != app.case.digest or site not in tree.sites:
            return
        if routine is not None and routine not in (site.routine, site.target):
            return
        owner = site.routine if routine is None else routine
        at = site.rva if routine is None else routine.rva
        if not owner.rva <= at < owner.end:
            app.status.set("The call site is outside the decoded preview.")
            return
        self.remember()
        self.hide_context()
        app.navigate(owner, at, raw=site.raw if routine is None else None)

    def open_global(self, rva, size):
        self.matrix.select_global(rva, size)
        self.from_global = True
        self.open()

    def open_function(self, rva):
        app = self.app
        target = app.case.keys.get(f"{rva:X}") if app.case and app.case.image else None
        if target is None:
            app.status.set("This function has no indexed entry in the current build.")
            return
        self.remember()
        app.navigate(target, rva, after=app.decompile_current)

    def remember(self, reader_tab=None):
        app, views = self.app, self.app.views
        key, row = app.citation()
        reader_tab = reader_tab or views.reader.select()
        from_local = self.origin is not None and self.local_origin is self.origin
        if self.origin is not None:
            self.parents.append(self.origin)
        slot = views.stack.current_slot
        self.origin = Origin(key, row.rva, row.raw, app.step, reader_tab,
                             views.active_pane, views.pseudo.result, views.pseudo.line,
                             views.listing.yview()[0], views.pseudo.code.yview()[0],
                             views.pseudo.code.xview()[0], views.pseudo.focus_snapshot(), views.stack.mode.get(),
                             (slot.offset, slot.size) if slot else None,
                             views.struct.capture_state() if reader_tab == str(views.struct) else None,
                             from_local and reader_tab == str(views.stack), self.context_open)
        self._return_label()
        app.xref_back.pack(side="right", before=app.xref_button, padx=(0, 3))
        app.update_nav()

    def _return_label(self):
        origin = self.origin
        if origin.context_open:
            target = "Inspector"
        elif origin.struct_selection:
            target = origin.struct_selection[0] or "Struct Layout"
        elif origin.reader_tab == str(self.app.views.stack):
            target = "Stack Frame"
        else:
            target = f"0x{origin.rva:X}"
        self.app.xref_back.configure(text=f"↩ Return to {target}")

    def open_local(self, offset, size):
        views = self.app.views
        if views.stack.select_slot(offset, size):
            self.remember()
            self.local_origin = self.origin
            if views.compact:
                views._layout(1)
            views.reader.select(views.stack)
            views.stack.slots.focus_set()

    def _reader_changed(self, _event):
        views = self.app.views
        previous, self.reader_tab = self.reader_tab, views.reader.select()
        if (self.reader_tab == str(views.struct) and previous != self.reader_tab
                and self.app.case and views.struct.current_slot):
            self.remember(previous)
            views.struct.focus_selection()
        if self.reader_tab != str(views.stack):
            self.local_origin = None

    def follow_stack(self, row):
        views = self.app.views
        if not (self.local_origin and self.local_origin is self.origin
                and self.local_origin.pseudocode is views.pseudo.result):
            self.remember()
        self.local_origin = None
        self._inspect(row)

    def follow_field(self, row):
        self.remember(str(self.app.views.struct))
        self._inspect(row)

    def _inspect(self, row):
        app, views = self.app, self.app.views
        app.navigate(app.routine, row.rva, raw=row.raw)
        views.show_pseudocode()
        views.select(app.index)
        views.pseudo.code.focus_set()

    def open(self):
        app = self.app
        if not app.case or not app.case.image:
            app.status.set("Open an x64 DLL to inspect its cross-references.")
            return
        if app.pending is not None and not (app.decompiling or self.indexing):
            app.status.set("Wait for the selected DLL or routine to finish opening.")
            return
        self.matrix.place(x=0, y=0, relwidth=1, relheight=1)
        self.matrix.lift()
        self.visible = True
        self.matrix.focus_search()
        self._load_index()

    def _load_index(self):
        app = self.app
        if self.index is not None:
            if self.visible:
                self.matrix.set_index(self.index)
            return
        if self.indexing:
            return

        case = app.case
        def ready(index):
            self.indexing = False
            case.include_callers(index)
            app.routine_box["values"] = [app.routine_label(r) for r in case.routines]
            self.index = index
            if self.visible:
                self.matrix.set_index(index)
            self.update_context()
            app.status.set("Read-only cross-references · " + case.label)

        def stopped(message):
            self.indexing = False
            self.matrix.set_status(message)
            self.update_context(message)
            app.status.set(message)

        message = "Tracing calls and global data accesses…"
        self.matrix.set_status(message)
        app.busy(message, lambda stop: build_index(case.image, stop), ready,
                 failed=stopped, cancelled=lambda: stopped("Indexing cancelled. Reopen the matrix to retry."))
        self.indexing = True

    def follow(self, site):
        app = self.app
        if not self.visible or self.index is None or site not in self.matrix.matches:
            return
        if not site.routine.rva <= site.rva < site.routine.end:
            app.status.set(f"Site at 0x{site.rva:X} is outside the routine’s supported instruction preview.")
            return
        if self.origin is None or self.from_global or self.context_open or app.views.reader.select() == str(app.views.struct):
            self.remember()
        self.hide()
        self.hide_context()
        app.navigate(site.routine, site.rva, raw=site.raw, after=app.decompile_current)

    def back(self):
        app, origin = self.app, self.origin
        self.local_origin = None
        if origin is None:
            self.hide()
            return
        self.hide()
        self.hide_context()
        app.cancel_work(announce=False)
        step = origin.step
        if not (0 <= step < len(app.trail) and app.trail[step] == (origin.key, origin.rva)):
            step = None

        def restore():
            views = app.views
            if origin.pseudocode is not None:
                if views.pseudo.result is not origin.pseudocode:
                    views.set_decompilation(origin.pseudocode, reveal=False)
                if origin.line is not None:
                    views.pseudo.choose_line(origin.line, follow=False)
                else:
                    views.select(app.index)
            if origin.stack_slot and origin.reader_tab in (str(views.stack), str(views.struct)):
                views.stack.select_slot(*origin.stack_slot)
                views.stack.mode.set(origin.stack_filter)
                views.stack._render()
            # Restoring a panel is part of Back, not a new visit to the layout.
            self.reader_tab = origin.reader_tab
            views.reader.select(origin.reader_tab)
            if views.compact:
                views._layout(origin.compact_pane)
            views.listing.yview_moveto(origin.listing_top)
            views.pseudo.restore_scroll(origin.code_top)
            views.pseudo.code.xview_moveto(origin.code_left)
            if origin.reader_tab == str(views.pseudo):
                views.pseudo.restore_focus(origin.symbol_focus)
                views.pseudo.code.focus_set()
            elif origin.struct_selection:
                views.struct.restore(origin.struct_selection)
            elif origin.reader_tab == str(views.stack) and origin.stack_slot:
                views.stack.slots.focus_set()
            else:
                views.listing.focus_set()
            if origin.context_open:
                self.open_context()
            self.origin = self.parents.pop() if self.parents else None
            self.local_origin = self.origin if origin.stack_from_local else None
            if self.origin:
                self._return_label()
            else:
                app.xref_back.pack_forget()
            app.update_nav()

        app.navigate(app.case.keys[origin.key], origin.rva, origin.raw, history_step=step, after=restore)
