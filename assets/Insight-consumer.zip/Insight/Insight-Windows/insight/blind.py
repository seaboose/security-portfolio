"""Freeze anonymous cooldown trials, seal independent submissions, and rescore offline."""

import argparse
from contextlib import contextmanager
from hashlib import sha256
import json
from pathlib import Path
import re
import secrets
import sys
import sqlite3
from tempfile import NamedTemporaryFile

from .cooldown import COMPARISON, OPERATORS, load_case, score
from .blind_events import replay
from .desktop import functions_for
from .records import fields, integer, read_document, snapshot


PROMPT = ("Infer the routine's Boolean return value for finite inputs, as one comparison between now "
          "and deadline using <, <=, >, >=, == or !=. Use only this listing and the public examples. "
          "Cite routine-relative instruction offsets in decimal. You may abstain. Do not consult other sources.")
REPLY = ('Return JSON with outcome submitted or abstained, expression (comparison or null), '
         'citations (a list of decimal offsets) and reason (up to 240 characters).')
PUBLIC = ((3,7,False), (11,7,True))
STAGES = ("initial","revision")
SESSION = re.compile(r"[a-zA-Z0-9][a-zA-Z0-9._:/-]{0,127}")
SLOT = re.compile(r"[a-f0-9]{16}")
DEFAULT_TRIAL = Path(__file__).resolve().parents[1]/"cases"/"survive-cooldown"/"blind"


def canonical(value):
    return json.dumps(value,ensure_ascii=True,sort_keys=True,separators=(",",":"),allow_nan=False).encode("ascii")


def digest(value):
    return sha256(canonical(value)).hexdigest()


def write_once(path, value):
    """Publish a complete record atomically and never replace an existing receipt."""
    import os
    path = Path(path)
    with NamedTemporaryFile(dir=path.parent,delete=False) as out:
        temp = Path(out.name)
        try:
            out.write(canonical(value)+b"\n")
            out.flush()
            os.fsync(out.fileno())
        except BaseException:
            out.close()
            temp.unlink(missing_ok=True)
            raise
    try:
        # Windows rename is atomic and refuses to replace the destination; POSIX rename replaces it.
        if os.name=="nt":
            os.rename(temp,path)
        else:
            os.link(temp,path)
    except FileExistsError:
        if canonical(read_document(snapshot(path)))!=canonical(value):
            raise ValueError("This trial record is already sealed with different contents.") from None
    finally:
        temp.unlink(missing_ok=True)


@contextmanager
def _write_lock(folder):
    """Serialize submissions and seals. SQLite releases the lock on process exit."""
    db = sqlite3.connect(Path(folder)/".coordinator.sqlite3",timeout=5)
    try:
        db.execute("BEGIN IMMEDIATE")
        yield
    finally:
        db.close()


def _label(value,limit):
    if not isinstance(value,str) or not 1<=len(value)<=limit or not value.isprintable():
        raise ValueError("Invalid trial label or evidence text.")
    return value


def settings(model,effort,max_tokens,max_seconds,accounting="Provider token counts where reported.",
             *,max_reply_bytes=600, isolation="Packet only. No external tools, network, source or peer material."):
    if max_tokens is not None:
        integer(max_tokens,1,262144)
    return dict(model=_label(model,128), effort=_label(effort,64), max_calls_per_stage=1,
                max_tokens_per_stage=max_tokens, max_seconds_per_stage=integer(max_seconds,1,3600),
                max_reply_bytes=integer(max_reply_bytes,100,4096),max_tool_calls=0,isolation=_label(isolation,240),
                revision_limit=1, accounting=_label(accounting,240))


def _packet(case,build,slot,limits):
    binding = case.evidence[build]
    rows = functions_for(build,binding["object_sha256"])["ready"]
    raw = b"".join(bytes.fromhex(row["bytes"]) for row in rows)
    if sha256(raw).hexdigest()!=binding["range_sha256"]:
        raise ValueError("Trial listing differs from the verified routine bytes.")
    return dict(protocol="insight-blind/1", packet=slot, prompt=PROMPT, reply=REPLY,
                signature="Windows x64. bool routine(double now: XMM0, double deadline: XMM1). Return in AL.",
                public=[dict(now=a,deadline=b,result=c) for a,b,c in PUBLIC], settings=limits,
                listing=[dict(offset=r["at"],bytes=r["bytes"],instruction=(r["op"]+" "+r["args"]).strip()) for r in rows])


def _manifest(case,slots,limits):
    return dict(protocol="insight-blind/1",case_sha256=case.digest,settings=limits,
                slots={slot:dict(build=build,packet_sha256=digest(_packet(case,build,slot,limits)),
                                object_sha256=case.evidence[build]["object_sha256"],
                                range_sha256=case.evidence[build]["range_sha256"]) for slot,build in slots})


def prepare(folder,limits):
    root = Path(folder)
    root.mkdir(parents=True,exist_ok=True)
    slots = sorted(secrets.token_hex(8) for _ in range(2))
    builds = ["plain","encoded"]
    secrets.SystemRandom().shuffle(builds)
    if slots[0]==slots[1]:
        raise ValueError("Packet identifier collision. Retry preparation.")
    result = _manifest(load_case(),zip(slots,builds),limits)
    write_once(root/"manifest.json",result)
    return result


def read_manifest(root):
    m = read_document(snapshot(Path(root)/"manifest.json"))
    fields(m,"protocol","case_sha256","settings","slots")
    limits = m["settings"]
    fields(limits,"model","effort","max_calls_per_stage","max_tokens_per_stage","max_seconds_per_stage",
           "revision_limit","accounting","max_reply_bytes","max_tool_calls","isolation")
    checked = settings(limits["model"],limits["effort"],limits["max_tokens_per_stage"],
                       limits["max_seconds_per_stage"],limits["accounting"],max_reply_bytes=limits["max_reply_bytes"],
                       isolation=limits["isolation"])
    if type(m["slots"]) is not dict or len(m["slots"])!=2 or any(not SLOT.fullmatch(s) for s in m["slots"]):
        raise ValueError("Invalid anonymous pair.")
    bindings = []
    for s,b in m["slots"].items():
        fields(b,"build","packet_sha256","object_sha256","range_sha256")
        bindings.append((s,b["build"]))
    if sorted(b for s,b in bindings)!=["encoded","plain"]:
        raise ValueError("Expected the two different verified routines.")
    if canonical(m)!=canonical(_manifest(load_case(),bindings,checked)):
        raise ValueError("Trial manifest does not match the frozen protocol and verified evidence.")
    return m


def packet(folder,slot):
    m = read_manifest(folder)
    if slot not in m["slots"]:
        raise ValueError("Unknown packet.")
    return _packet(load_case(),m["slots"][slot]["build"],slot,m["settings"])


def validate_answer(answer, offsets):
    fields(answer,"outcome","expression","citations","reason")
    status,expression,refs = (answer[k] for k in ("outcome","expression","citations"))
    _label(answer["reason"],240)
    if type(refs) is not list or len(refs)>12 or any(type(n) is not int or n not in offsets for n in refs):
        raise ValueError("Each citation must be an instruction start in this packet.")
    if status=="submitted":
        if not isinstance(expression,str) or len(expression)>64 or not COMPARISON.fullmatch(expression.strip(" ")):
            raise ValueError("Submission must express a supported Boolean comparison.")
    elif status in ("abstained","timed_out"):
        if refs or expression is not None:
            raise ValueError("Abstentions and timeouts have no predicate or citations.")
    else:
        raise ValueError("Unknown submission outcome.")
    return answer


def public_feedback(answer):
    if answer["outcome"]!="submitted":
        return {"checked":0,"passed":0}
    left,op,right = COMPARISON.fullmatch(answer["expression"].strip(" ")).groups()
    passed = 0
    for now,deadline,value in PUBLIC:
        args = {"now":now,"deadline":deadline}
        passed += OPERATORS[op](args[left],args[right])==value
    return {"checked":len(PUBLIC),"passed":passed}


def _usage(usage,limits,outcome):
    fields(usage,"session","model","effort","calls","elapsed_ms","input_tokens","output_tokens","reasoning_tokens",
           "provenance","budget_status","tool_calls","reply_bytes","raw_reply_sha256","runner_receipt_sha256")
    if not isinstance(usage["session"],str) or not SESSION.fullmatch(usage["session"]):
        raise ValueError("Invalid independent session identifier.")
    if (usage["model"],usage["effort"])!=(limits["model"],limits["effort"]):
        raise ValueError("Model or effort differs from the shared limits.")
    integer(usage["calls"],0,limits["max_calls_per_stage"])
    integer(usage["tool_calls"],0,0)
    integer(usage["reply_bytes"],0,limits["max_reply_bytes"])
    if not isinstance(usage["raw_reply_sha256"],str) or not re.fullmatch("[a-f0-9]{64}",usage["raw_reply_sha256"]):
        raise ValueError("Invalid raw response fingerprint.")
    trace = usage["runner_receipt_sha256"]
    if trace is not None and (not isinstance(trace,str) or not re.fullmatch("[a-f0-9]{64}",trace)):
        raise ValueError("Invalid runner event receipt fingerprint.")
    if outcome=="submitted" and usage["calls"]!=1:
        raise ValueError("A model submission requires one recorded call.")
    integer(usage["elapsed_ms"],0,3_600_000)
    if usage["elapsed_ms"]>limits["max_seconds_per_stage"]*1000 and outcome!="timed_out":
        raise ValueError("Submission exceeded the frozen time budget.")
    for key in ("input_tokens","output_tokens","reasoning_tokens"):
        if usage[key] is not None:
            integer(usage[key],0,2**31-1)
    if usage["budget_status"] not in ("enforced","requested_unverified","unavailable"):
        raise ValueError("Unknown output token budget provenance.")
    if (limits["max_tokens_per_stage"] is not None and usage["output_tokens"] is not None
            and usage["output_tokens"]>limits["max_tokens_per_stage"]
            and outcome!="timed_out"):
        raise ValueError("Reported output exceeds the frozen output-token budget.")
    _label(usage["provenance"],240)


def _read(root,name):
    return read_document(snapshot(Path(root)/name))


def _receipt(m,slot,stage,answer,usage,previous,raw):
    if slot not in m["slots"] or stage not in STAGES:
        raise ValueError("Unknown packet or submission stage.")
    p = _packet(load_case(),m["slots"][slot]["build"],slot,m["settings"])
    validate_answer(answer,{r["offset"] for r in p["listing"]})
    _usage(usage,m["settings"],answer["outcome"])
    if not isinstance(raw,bytes) or len(raw)!=usage["reply_bytes"] or sha256(raw).hexdigest()!=usage["raw_reply_sha256"]:
        raise ValueError("Raw response length or fingerprint mismatch.")
    if raw:
        if canonical(read_document(raw)) != canonical(answer):
            raise ValueError("Submitted answer differs from the captured original response.")
    elif answer["outcome"]!="timed_out":
        raise ValueError("A submitted answer or abstention must retain its original response.")
    if stage=="revision" and previous["usage"]["session"]!=usage["session"]:
        raise ValueError("The revision must belong to the original independent session.")
    return dict(protocol="submission/1",manifest=digest(m),packet=m["slots"][slot]["packet_sha256"],
                stage=stage,previous=digest(previous) if previous else None,answer=answer,usage=usage,
                raw_chunks=[raw[i:i+64].hex() for i in range(0,len(raw),64)], public=public_feedback(answer))


def _stages(root,m,slot):
    if slot not in m["slots"]:
        raise ValueError("Unknown packet.")
    runs = []
    for stage in STAGES:
        path = Path(root)/f"{slot}-{stage}.json"
        if not path.exists():
            if stage=="initial" and (Path(root)/f"{slot}-revision.json").exists():
                raise ValueError("The initial receipt is missing.")
            break
        saved = read_document(snapshot(path))
        fields(saved,"protocol","manifest","packet","stage","previous","answer","usage","raw_chunks","public")
        chunks = saved["raw_chunks"]
        if (type(chunks) is not list or len(chunks)>64 or any(not isinstance(c,str) or
                not re.fullmatch("[0-9a-f]{2,128}",c) or len(c)%2 for c in chunks)):
            raise ValueError("Invalid archived response bytes.")
        raw = bytes.fromhex("".join(chunks))
        verified = _receipt(m,slot,stage,saved["answer"],saved["usage"],runs[-1] if runs else None,raw)
        if canonical(verified)!=canonical(saved):
            raise ValueError("Submission receipt integrity check failed.")
        runs.append(verified)
    return runs


def submit(folder,slot,stage,raw,usage, *, timeout_reason=None):
    with _write_lock(folder):
        return _submit(folder,slot,stage,raw,usage,timeout_reason)


def _submit(folder,slot,stage,raw,usage,timeout_reason):
    root,m = Path(folder),read_manifest(folder)
    if slot not in m["slots"] or stage not in STAGES:
        raise ValueError("Unknown packet or stage.")
    runs = _stages(root,m,slot)
    if stage=="revision" and not runs:
        raise ValueError("Seal the unaided submission before a revision.")
    answer = (dict(outcome="timed_out",expression=None,citations=[],reason=timeout_reason)
              if timeout_reason is not None else read_document(raw))
    measured = dict({"runner_receipt_sha256":None},**usage)
    measured.update(reply_bytes=len(raw),raw_reply_sha256=sha256(raw).hexdigest())
    receipt = _receipt(m,slot,stage,answer,measured,runs[0] if stage=="revision" else None,raw)
    if (root/"pair-seal.json").exists() or (root/f"{slot}-seal.json").exists():
        index = STAGES.index(stage)
        if len(runs)>index and canonical(receipt)==canonical(runs[index]):
            return runs[index]
        raise ValueError("This packet has already been sealed.")
    write_once(root/f"{slot}-{stage}.json",receipt)
    return receipt


def revision_packet(folder,slot):
    root,m = Path(folder),read_manifest(folder)
    runs = _stages(root,m,slot)
    if not runs:
        raise ValueError("Store the unaided answer first.")
    return dict(packet=packet(root,slot),initial=runs[0]["answer"],public_feedback=runs[0]["public"],
                request="One revision is available after public feedback. Keep or revise your answer using the same JSON format.")


def seal(folder,slot):
    with _write_lock(folder):
        return _seal(folder,slot)


def _seal(folder,slot):
    root,m = Path(folder),read_manifest(folder)
    runs = _stages(root,m,slot)
    if not runs:
        raise ValueError("Store an unaided outcome before sealing.")
    record = dict(protocol="packet-seal/1",manifest=digest(m),packet=m["slots"][slot]["packet_sha256"],
                  receipts=[digest(r) for r in runs])
    write_once(root/f"{slot}-seal.json",record)
    return digest(record)


def lock_pair(folder,write=True):
    root,m = Path(folder),read_manifest(folder)
    seals,sessions = {},set()
    for slot in m["slots"]:
        runs = _stages(root,m,slot)
        if not runs or not (root/f"{slot}-seal.json").exists():
            raise ValueError("Hidden scoring requires both independent submissions to be sealed.")
        frozen = _read(root,f"{slot}-seal.json")
        expected = dict(protocol="packet-seal/1",manifest=digest(m),packet=m["slots"][slot]["packet_sha256"],
                        receipts=[digest(r) for r in runs])
        if canonical(frozen)!=canonical(expected):
            raise ValueError("The sealed submission changed.")
        seals[slot] = digest(frozen)
        sessions.add(runs[0]["usage"]["session"])
    if len(sessions)!=2:
        raise ValueError("Each build requires a different independent session.")
    result = dict(protocol="pair-seal/1",manifest=digest(m),seals=seals)
    if write:
        write_once(root/"pair-seal.json",result)
    elif canonical(_read(root,"pair-seal.json"))!=canonical(result):
        raise ValueError("Previously recorded pair seal differs from the stage seals.")
    return result


def report(folder,*,read_only=False):
    root = Path(folder)
    lock = lock_pair(root,write=not read_only)
    m,case = read_manifest(root),load_case()
    results = []
    for slot,binding in m["slots"].items():
        stages = []
        for r in _stages(root,m,slot):
            answer = r["answer"]
            outcome = answer["outcome"]
            scored = score(answer["expression"],case) if outcome=="submitted" else None
            stages.append(dict(stage=r["stage"],answer=answer,usage=r["usage"],public=r["public"],
                               hidden=scored, fraction=f"{scored['passed']}/{scored['total']}" if scored else None))
        results.append(dict(packet=slot,build=binding["build"],stages=stages))
    control = score("now > deadline",case)
    return dict(protocol="blind-report/1",pair_seal_sha256=digest(lock),settings=m["settings"],
                rubric="Each hidden Boolean decision has equal weight. Abstentions and timeouts are unscored.",
                trials=results,incorrect_control=dict(provenance="deliberate strict inequality", result=control))


def archived_report(folder):
    root = Path(folder)
    if not (root/"pair-seal.json").is_file():
        raise ValueError("Missing previously recorded pair seal.")
    computed = report(root,read_only=True)
    receipt = _read(root,"report-receipt.json")
    expected = dict(protocol="report-receipt/1",sha256=digest(computed),seal=computed["pair_seal_sha256"])
    if canonical(receipt)!=canonical(expected):
        raise ValueError("Independently recomputed scores differ from the saved report fingerprint.")
    return computed


def verify_runner_events(folder,events):
    """Check detached runner logs against the hashes committed before hidden scoring."""
    root = Path(folder)
    verified = archived_report(root)
    threads = set()
    for trial in verified["trials"]:
        for stage in trial["stages"]:
            expected = stage["usage"]["runner_receipt_sha256"]
            if expected is None:
                raise ValueError("An external event fingerprint was not recorded for this stage.")
            path = Path(events)/f"{trial['packet']}-{stage['stage']}.jsonl"
            stream = snapshot(path)
            if sha256(stream).hexdigest()!=expected:
                raise ValueError("The external runner event log does not match its sealed fingerprint.")
            task = (packet(root,trial["packet"]) if stage["stage"]=="initial"
                    else revision_packet(root,trial["packet"]))
            thread = replay(stream,stage["usage"],stage["answer"]["outcome"]=="timed_out",task)
            if thread in threads:
                raise ValueError("Independent runner stages reused a request identity.")
            threads.add(thread)
    return verified


def main(argv=None):
    parser = argparse.ArgumentParser(prog="python -m insight.blind")
    sub = parser.add_subparsers(dest="command",required=True)
    new = sub.add_parser("prepare",help="freeze settings and generate anonymous packet IDs")
    new.add_argument("folder",type=Path)
    new.add_argument("--model",required=True)
    new.add_argument("--effort",required=True)
    new.add_argument("--seconds",type=int,default=120)
    new.add_argument("--max-tokens",type=int,default=None,help="only specify a runner-enforced output token limit")
    new.add_argument("--reply-bytes",type=int,default=600)
    new.add_argument("--isolation",required=True,help="observed contestant access and isolation")
    new.add_argument("--accounting",required=True,help="runner's usage source and measurement limits")
    for command in ("packet","revision-packet","seal"):
        p = sub.add_parser(command)
        p.add_argument("folder",type=Path)
        p.add_argument("slot")
    send = sub.add_parser("submit",help="record exact model response and runner usage")
    send.add_argument("folder",type=Path)
    send.add_argument("slot")
    send.add_argument("stage",choices=STAGES)
    send.add_argument("--reply",type=Path)
    send.add_argument("--usage",type=Path,required=True)
    send.add_argument("--timeout-reason")
    for command in ("report","verify"):
        p = sub.add_parser(command)
        p.add_argument("folder",type=Path,nargs="?",default=DEFAULT_TRIAL)
        if command=="verify":
            p.add_argument("--events",type=Path,help="also verify retained SL0T-STAGE.jsonl event logs (64 KiB each)")
    args = parser.parse_args(argv)
    try:
        folder = args.folder
        if args.command=="prepare":
            policy = settings(args.model,args.effort,args.max_tokens,args.seconds,args.accounting,
                              max_reply_bytes=args.reply_bytes,isolation=args.isolation)
            manifest = prepare(folder,policy)
            result = dict(packets=sorted(manifest["slots"]),manifest=digest(manifest))
        elif args.command=="packet":
            result = packet(folder,args.slot)
        elif args.command=="revision-packet":
            result = revision_packet(folder,args.slot)
        elif args.command=="submit":
            if bool(args.reply)==bool(args.timeout_reason):
                raise ValueError("Choose exactly one original response file or timeout reason.")
            saved = submit(folder,args.slot,args.stage,snapshot(args.reply) if args.reply else b"",
                           _read(args.usage.parent,args.usage.name),timeout_reason=args.timeout_reason)
            result = dict(sealed_stage=digest(saved),public_feedback=saved["public"])
        elif args.command=="seal":
            result = dict(packet_seal=seal(folder,args.slot))
        elif args.command=="report":
            result = report(folder)
            write_once(folder/"report-receipt.json",dict(protocol="report-receipt/1",sha256=digest(result),
                                                         seal=result["pair_seal_sha256"]))
        else:
            result = verify_runner_events(folder,args.events) if args.events else archived_report(folder)
    except (ValueError,OSError,TypeError) as error:
        print(f"Blind trial rejected: {error}",file=sys.stderr)
        return 2
    print(json.dumps(result,ensure_ascii=True,indent=2))
    return 0


if __name__=="__main__":
    sys.exit(main())
