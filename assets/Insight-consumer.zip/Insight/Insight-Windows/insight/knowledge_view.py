"""Build-scoped analyst judgments, reversible history and symbol overlays."""

import tkinter as tk
from tkinter import ttk

from .appearance import AMBER, CRIMSON, INK, MONO, MUTED, TEAL, scrollable
from .dialogs import Prompt
from .knowledge import Annotation, CONFIDENCES, STATUSES, StaleEdit, Subject


PAGE = 60
FIELDS = (("name", "Name"), ("type_name", "Type"), ("status", "Status"), ("confidence", "Confidence"))


def _check_build(case, knowledge):
    if case.digest != knowledge.digest:
        raise ValueError("The analyst record belongs to a different build.")


def _build_label(case):
    return f"{case.label}  ·  SHA-256 {case.digest[:16]}"


def _table(parent, columns):
    frame = ttk.Frame(parent)
    frame.pack(fill="both", expand=True, pady=(4, 2))
    table = ttk.Treeview(frame, columns=[key for key, _, _ in columns], show="headings", height=8,
                         style="Insight.Treeview", selectmode="browse")
    for index, (key, title, chars) in enumerate(columns):
        width = table.winfo_pixels(f"{chars*6}p")
        table.heading(key, text=title, anchor="w")
        table.column(key, width=width, minwidth=min(width, 52), stretch=index==1)
    scrollable(frame, table)
    return table


def _pick(table, key):
    table.selection_set(key)
    table.focus(key)
    table.see(key)


def _choice(parent, values, width):
    box = ttk.Combobox(parent, values=values, width=width, state="readonly")
    box.current(0)
    return box


class Triage(Prompt):
    def __init__(self, parent, case, knowledge, current=None):
        _check_build(case, knowledge)
        super().__init__(parent, "Function triage")
        self.case, self.knowledge = case, knowledge
        ttk.Label(self.body, text=_build_label(case), style="DockTitle.TLabel").pack(anchor="w")
        row = ttk.Frame(self.body)
        row.pack(fill="x", pady=(5, 0))
        self.term = tk.StringVar(self)
        self.search = ttk.Entry(row, textvariable=self.term, width=18)
        self.search.pack(side="left", fill="x", expand=True)
        self.status_filter = _choice(row, ("All statuses", *STATUSES), 16)
        self.conf_filter = _choice(row, ("All confidence", *CONFIDENCES), 13)
        for box in (self.status_filter, self.conf_filter):
            box.pack(side="left", padx=(3, 0))
            box.bind("<<ComboboxSelected>>", lambda _:self.filter())
        self.table = _table(self.body, (("at", "RVA" if case.image else "Offset", 10),
                            ("name", "Function", 24), ("status", "Triage", 16), ("confidence", "Confidence", 11)))
        for status, color in zip(STATUSES, (MUTED, AMBER, TEAL, MUTED, CRIMSON)):
            self.table.tag_configure(status, foreground=color)
        self.table.bind("<<TreeviewSelect>>", lambda _:self._editor())
        self.table.bind("<Double-Button-1>", lambda e:self.open_function() if self.table.identify_row(e.y) else None)
        pages = ttk.Frame(self.body)
        pages.pack(fill="x")
        self.count = ttk.Label(pages, foreground=MUTED)
        self.count.pack(side="left")
        self.next = ttk.Button(pages, text="Next", command=lambda:self.render(self.page+1))
        self.previous = ttk.Button(pages, text="Previous", command=lambda:self.render(self.page-1))
        self.next.pack(side="right")
        self.previous.pack(side="right")
        edit = ttk.Frame(self.body)
        edit.pack(fill="x", pady=(5, 0))
        ttk.Label(edit, text="Status").pack(side="left")
        self.status = _choice(edit, STATUSES, 15)
        self.status.pack(side="left", padx=(2, 5))
        ttk.Label(edit, text="Confidence").pack(side="left")
        self.conf = _choice(edit, CONFIDENCES, 8)
        self.conf.pack(side="left", padx=2)
        self.save = ttk.Button(edit, text="Save triage", command=self.commit)
        self.save.pack(side="right")
        self.info = ttk.Label(self.body, foreground=MUTED, wraplength=480)
        self.info.pack(fill="x", pady=(3, 0))
        self.term.trace_add("write", lambda *_:self.filter())
        knowledge.refresh()
        self.expected = knowledge.version
        self.records = knowledge.functions()
        self.filter(current)

    def filter(self, current=None):
        query = self.term.get().strip().casefold()
        status, confidence = self.status_filter.get(), self.conf_filter.get()
        self.visible = []
        selected = 0
        empty = Annotation()
        for routine in self.case.routines:
            key = self.case.key(routine)
            record = self.records.get(key, empty)
            if (status != "All statuses" and status != record.status
                    or confidence != "All confidence" and confidence != record.confidence):
                continue
            if not any(query in v.casefold() for v in (routine.name, record.name, hex(routine.rva))):
                continue
            if routine == current:
                selected = len(self.visible)
            self.visible.append(routine)
        self.render(selected // PAGE, selected % PAGE)

    def render(self, page, index=0):
        self.page = page
        start = page*PAGE
        self.table.delete(*self.table.get_children())
        for n, routine in enumerate(self.visible[start:start+PAGE], start):
            record = self.records.get(self.case.key(routine), Annotation())
            self.table.insert("", "end", iid=str(n), tags=(record.status,),
                              values=(hex(routine.rva), record.name or routine.name, record.status, record.confidence))
        total = len(self.visible)
        if total:
            _pick(self.table, str(start+index))
        self._editor()
        self.count.configure(text=f"{start+1}–{min(start+PAGE,total)} of {total} functions" if total else "No matching functions")
        self.previous.state(["!disabled" if page else "disabled"])
        self.next.state(["!disabled" if start+PAGE < total else "disabled"])

    def selected(self):
        sel = self.table.selection()
        return self.visible[int(sel[0])] if sel else None

    def _editor(self):
        routine = self.selected()
        record = self.records.get(self.case.key(routine), Annotation()) if routine else Annotation()
        self.status.set(record.status)
        self.conf.set(record.confidence)
        self.save.state(["!disabled" if routine else "disabled"])

    def commit(self):
        routine = self.selected()
        if not routine:
            return
        try:
            changed = self.knowledge.edit(Subject.function(self.case.key(routine)), status=self.status.get(),
                                          confidence=self.conf.get(), expected=self.expected)
            note = "Saved to this build’s analysis history." if changed else "The recorded triage already matches."
        except StaleEdit:
            note = "Another edit was saved. Review the refreshed triage before applying your change."
            self.knowledge.refresh()
        self.records = self.knowledge.functions()
        self.expected = self.knowledge.version
        self.filter(routine)
        self.info.configure(text=note)

    def open_function(self):
        if routine := self.selected():
            self.finish(routine)


def triage(parent, case, knowledge, current=None):
    prompt = Triage(parent, case, knowledge, current)
    return prompt.show(prompt.open_function, "Open function", prompt.search, cancel="Close")


def _subject(subject, case):
    if subject.kind == "global":
        return f"Global 0x{subject.offset:X}"
    routine = case.keys.get(subject.routine)
    name = routine.name if routine else subject.routine
    if subject.kind == "local":
        scope = f"0x{subject.routine}" if case.image else name
        return f"RSP {subject.offset:+#x} · {subject.size} B in {scope}"
    if case.image:
        name += f" @ 0x{subject.routine}"
    return name


class History(Prompt):
    def __init__(self, parent, case, knowledge):
        _check_build(case, knowledge)
        super().__init__(parent, "Analysis history")
        self.case, self.knowledge = case, knowledge
        ttk.Label(self.body, text=_build_label(case), style="DockTitle.TLabel").pack(anchor="w")
        self.table = _table(self.body, (("position", "Edit", 6), ("who", "Symbol", 28),
                            ("what", "Fields", 17), ("state", "State", 10)))
        self.table.bind("<<TreeviewSelect>>", lambda _:self._details())
        bar = ttk.Frame(self.body)
        bar.pack(fill="x")
        self.undo = ttk.Button(bar, text="Undo", command=lambda:self._move(knowledge.undo))
        self.redo = ttk.Button(bar, text="Redo", command=lambda:self._move(knowledge.redo))
        self.restore = ttk.Button(bar, text="Restore after selected", command=self._restore)
        for w in (self.undo, self.redo, self.restore):
            w.pack(side="left")
        self.older = ttk.Button(bar, text="Older", command=lambda:self.load(self.records[-1].position))
        self.newer = ttk.Button(bar, text="Newer", command=self._newer)
        self.older.pack(side="right")
        self.newer.pack(side="right")
        self.detail = ttk.Label(self.body, justify="left", wraplength=440, foreground=INK)
        self.detail.pack(fill="x", pady=(5, 0))
        self.detail.bind("<Configure>", lambda e:self.detail.configure(wraplength=max(120, e.width-4)))
        self.message = ttk.Label(self.body, foreground=AMBER, wraplength=440)
        self.message.pack(fill="x")
        self.pages = []
        knowledge.refresh()
        self.load()

    def load(self, before=None):
        try:
            records = self.knowledge.history(limit=PAGE+1, before=before)
        except StaleEdit:
            self.knowledge.refresh()
            before = None
            self.pages.clear()
            records = self.knowledge.history(limit=PAGE+1)
            self.message.configure(text="Another edit was saved. Showing the latest timeline.")
        self.records = records[:PAGE]
        self.pages.append(before)
        self.table.delete(*self.table.get_children())
        for i, change in enumerate(self.records):
            fields = ", ".join(label for field,label in FIELDS
                               if getattr(change.before, field) != getattr(change.after, field))
            self.table.insert("", "end", iid=str(i), values=(change.position, _subject(change.subject,self.case),
                              fields, "Applied" if change.applied else "Undone"))
        if self.records:
            _pick(self.table, "0")
        self._details()
        self.undo.state(["!disabled" if self.knowledge.can_undo else "disabled"])
        self.redo.state(["!disabled" if self.knowledge.can_redo else "disabled"])
        self.older.state(["!disabled" if len(records)>PAGE else "disabled"])
        self.newer.state(["!disabled" if len(self.pages)>1 else "disabled"])
        self.expected = self.knowledge.version

    def _newer(self):
        self.pages.pop()
        self.load(self.pages.pop())

    def _details(self):
        sel = self.table.selection()
        if not sel:
            self.detail.configure(text="No analyst edits recorded for this build.")
            self.restore.state(["disabled"])
            return
        change = self.records[int(sel[0])]
        text = [f"{_subject(change.subject, self.case)}   ·   {change.created}"]
        for field, label in FIELDS:
            before, after = getattr(change.before, field), getattr(change.after, field)
            if before != after:
                text.append(f"{label}    {before or '∅'}  →  {after or '∅'}")
        self.detail.configure(text="\n".join(text))
        self.restore.state(["disabled" if change.position == self.knowledge.cursor else "!disabled"])

    def _restore(self):
        sel = self.table.selection()
        if sel:
            change = self.records[int(sel[0])]
            self._move(self.knowledge.undo_to if change.applied else self.knowledge.redo_to, change.position)

    def _move(self, action, *args):
        try:
            action(*args, expected=self.expected)
            self.message.configure(text="")
        except StaleEdit:
            self.knowledge.refresh()
            self.message.configure(text="Another edit was saved. Review the refreshed timeline.")
        self.pages.clear()
        self.load()


def history(parent, case, knowledge):
    prompt = History(parent, case, knowledge)
    prompt.show(prompt.finish, "Close", prompt.table, cancel=None)


def edit_symbol(parent, case, scope, original, current, field):
    if field not in ("name", "type"):
        raise ValueError("Choose a name or type annotation.")
    prompt = Prompt(parent, "Rename symbol" if field=="name" else "Retype symbol")
    ttk.Label(prompt.body, text=_build_label(case), style="DockTitle.TLabel").pack(anchor="w")
    ttk.Label(prompt.body, text=scope, font=MONO, wraplength=400).pack(anchor="w", pady=(5, 0))
    ttk.Label(prompt.body, text=f"Source symbol   {original or 'Unspecified'}",
              foreground=MUTED, wraplength=400).pack(anchor="w")
    ttk.Label(prompt.body, text=f"Project {field}").pack(anchor="w", pady=(5, 0))
    entry = ttk.Entry(prompt.body, width=42, font=MONO)
    entry.pack(fill="x")
    entry.insert(0, current or "")
    entry.selection_range(0, "end")
    feedback = ttk.Label(prompt.body, text="Stored as an analyst annotation for this build. Clear to remove.",
                         foreground=MUTED, wraplength=400)
    feedback.pack(anchor="w")
    def accept():
        value = entry.get().strip()
        try:
            Annotation(**{("type_name" if field == "type" else "name"): value})
        except ValueError as error:
            feedback.configure(text=str(error), foreground=AMBER)
            entry.focus_set()
            return
        prompt.finish(value)
    return prompt.show(accept, "Apply to project", entry)
