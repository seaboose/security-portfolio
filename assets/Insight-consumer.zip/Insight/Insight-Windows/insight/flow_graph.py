"""Basic blocks and possible intraprocedural transfers in a decoded x64 range."""

from bisect import bisect_right
from dataclasses import dataclass

from .pe import MAX_ROUTINE_BYTES


OUTSIDE = "Outside the decoded range"
TERMINALS = {
    "return": "Return to caller",
    "indirect": "Destination determined at runtime",
    "stop": "End of statically traced block",
    "invalid": "Undecoded bytes",
}


@dataclass(frozen=True)
class Edge:
    kind: str
    target: int | None
    block: int | None
    reason: str = ""


@dataclass(frozen=True)
class Block:
    first: int
    stop: int
    edges: tuple[Edge, ...]


@dataclass(frozen=True)
class Graph:
    blocks: tuple[Block, ...]
    starts: tuple[int, ...]

    def block_at(self, row_index):
        if not self.blocks or not 0 <= row_index < self.blocks[-1].stop:
            raise IndexError("Instruction is outside the decoded range.")
        return bisect_right(self.starts, row_index) - 1


def build_graph(rows):
    """Use only verified instruction starts for links inside the displayed range."""
    if len(rows) > MAX_ROUTINE_BYTES:
        raise ValueError("Too many instructions for the decoded range.")
    if not rows:
        return Graph((), ())

    leaders = {0}
    targets = set()
    addresses = []
    byte_count = 0
    previous_end = 0
    for i, row in enumerate(rows):
        size = len(row.raw)
        byte_count += size
        if not 1 <= size <= 15 or row.rva < previous_end or byte_count > MAX_ROUTINE_BYTES:
            raise ValueError("Invalid or overlapping instruction range.")
        if i and row.rva != previous_end:
            leaders.add(i)
        if row.flow == "invalid":
            leaders.add(i)
        if row.flow in ("conditional", "jump"):
            targets.add(row.target)
        if row.flow not in ("next", "call") and i + 1 < len(rows):
            leaders.add(i + 1)
        addresses.append(row.rva)
        previous_end = row.rva + size

    leaders.update(i for i, at in enumerate(addresses) if at in targets)
    starts = tuple(sorted(leaders))
    by_address = {addresses[i]: number for number, i in enumerate(starts)}

    def destination(kind, target):
        if target is None:
            reason = "Destination unavailable"
        elif target < addresses[0] or target >= previous_end:
            reason = OUTSIDE
        elif target in by_address:
            number = by_address[target]
            if rows[starts[number]].flow != "invalid":
                return Edge(kind, target, number)
            reason = "Undecoded bytes at destination"
        else:
            row = rows[bisect_right(addresses, target) - 1]
            reason = ("Inside a decoded instruction" if target < row.rva + len(row.raw)
                      else "Gap in decoded instructions")
        return Edge(kind, target, None, reason)

    blocks = []
    for first, stop in zip(starts, (*starts[1:], len(rows))):
        tail = rows[stop - 1]
        edges = []
        if tail.flow in ("conditional", "jump"):
            kind = "taken" if tail.flow == "conditional" else "jump"
            edges.append(destination(kind, tail.target))
        if tail.flow in ("next", "call", "conditional"):
            edges.append(destination("fallthrough", tail.rva + len(tail.raw)))
        elif tail.flow != "jump":
            if tail.flow not in TERMINALS:
                raise ValueError("Unknown instruction control flow.")
            edges.append(Edge(tail.flow, None, None, TERMINALS[tail.flow]))
        blocks.append(Block(first, stop, tuple(edges)))
    return Graph(tuple(blocks), starts)
