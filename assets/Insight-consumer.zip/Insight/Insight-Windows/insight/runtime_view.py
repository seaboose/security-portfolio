"""Display a user-requested Windows observation beside its static investigation."""

from concurrent.futures import ThreadPoolExecutor
from threading import Event
import tkinter as tk
from tkinter import ttk

from .appearance import AMBER, MONO, MUTED, SURFACE, TEAL, scrollable


def open_observations(app):
    if not app.case or not app.case.image:
        app.status.set("Open an x64 DLL to compare a live observation with its file bytes.")
        return
    window = getattr(app, "observation_window", None)
    if window is None or not window.winfo_exists():
        window = app.observation_window = ObservationWindow(app)
    window.deiconify()
    window.lift()
    window.pid.focus_set()
    return window


class ObservationWindow(tk.Toplevel):
    def __init__(self, app):
        super().__init__(app.root, background=SURFACE)
        self.app, self.case = app, app.case
        self.title("Live observations — Insight")
        self.geometry("730x550")
        self.minsize(420, 340)
        self.pool = ThreadPoolExecutor(max_workers=1, thread_name_prefix="observation")
        self.work = self.timer = self.cancel = None
        self.sample = None
        self.closed = False
        self.columnconfigure(0, weight=1)
        self.rowconfigure(3, weight=1)
        self.rowconfigure(5, weight=1)
        bar = ttk.Frame(self, padding=6)
        bar.grid(row=0, column=0, sticky="ew")
        ttk.Label(bar, text="Process ID").pack(side="left")
        self.pid = ttk.Entry(bar, width=11, font=MONO)
        self.pid.pack(side="left", padx=5)
        self.take = ttk.Button(bar, text="Capture once", command=self.capture)
        self.take.pack(side="left")
        self.stop = ttk.Button(bar, text="Cancel", command=self.cancel_capture)
        self.stop.pack(side="left", padx=4)
        self.stop.state(["disabled"])
        self.forget = ttk.Button(bar, text="Disconnect", command=self.disconnect)
        self.forget.pack(side="left")
        self.forget.state(["disabled"])
        self.identity = ttk.Label(self, foreground=MUTED)
        self.identity.grid(row=1, column=0, sticky="ew", padx=8)
        self.status = ttk.Label(self, text="Enter the PID of a running x64 process that has this DLL loaded.")
        self.status.grid(row=2, column=0, sticky="ew", padx=8, pady=3)
        self.threads = self.table(3, (("tid","Thread",65), ("rip","Captured RIP",140),
                                      ("rva","DLL RVA",85), ("status","Instruction evidence",220)))
        self.threads.bind("<<TreeviewSelect>>", self.select_thread)
        self.summary = ttk.Label(self, font=MONO, foreground=TEAL)
        self.summary.grid(row=4, column=0, sticky="ew", padx=8, pady=3)
        self.registers = self.table(5, (("reg","Register",90), ("value","Captured value",175),
                                        ("rva","Points into this DLL",160)))
        self.follow = ttk.Button(self, text="Show matching instruction", command=self.show_instruction)
        self.follow.grid(row=6, column=0, sticky="e", padx=6, pady=4)
        self.follow.state(["disabled"])
        for label in (self.identity, self.status, self.summary):
            label.bind("<Configure>", lambda e:e.widget.configure(wraplength=max(160,e.width-4)))
        self.pid.bind("<Return>", lambda _:self.capture())
        self.protocol("WM_DELETE_WINDOW", self.close)
        self.reset_case(app.case)

    def table(self, row, columns):
        frame = ttk.Frame(self, padding=(6,0))
        frame.grid(row=row, column=0, sticky="nsew")
        table = ttk.Treeview(frame, columns=[c[0] for c in columns], show="headings",
                             height=4, selectmode="browse", style="Insight.Treeview")
        for key, label, width in columns:
            table.heading(key, text=label, anchor="w")
            table.column(key, width=width, minwidth=55, stretch=key == columns[-1][0])
        scrollable(frame, table)
        return table

    def reset_case(self, case):
        self.disconnect()
        self.case = case
        self.identity.configure(text=f"{case.label} · SHA-256 {case.digest}")
        self.status.configure(text="Enter the PID of a running x64 process that has this DLL loaded.",
                              foreground=MUTED)

    def disconnect(self):
        self.cancel_capture()
        self.connection = None
        self.clear_results()
        self.pid.delete(0, "end")
        self.forget.state(["disabled"])
        self.status.configure(text="Disconnected. Enter a PID to take another observation.", foreground=MUTED)

    def clear_results(self):
        self.sample = None
        self.threads.delete(*self.threads.get_children())
        self.select_thread()

    def cancel_capture(self):
        if self.cancel is not None:
            self.cancel.set()
        if self.work is not None:
            self.work.cancel()
        if self.timer is not None:
            self.after_cancel(self.timer)
        self.cancel = self.work = self.timer = None
        self.stop.state(["disabled"])
        self.take.state(["!disabled"])
        self.status.configure(text="Capture cancelled.", foreground=MUTED)

    def capture(self):
        from .runtime_capture import capture
        if self.work or self.app.case is not self.case:
            return
        text = self.pid.get().strip()
        if not (text.isascii() and text.isdecimal() and 0 < len(text) <= 10 and 0 < int(text) <= 0xffffffff):
            self.status.configure(text="Enter a decimal Windows process ID.", foreground=AMBER)
            return
        pid = int(text)
        previous = self.connection
        if previous and previous.pid != pid:
            self.status.configure(text="Disconnect from the previous process before changing PID.", foreground=AMBER)
            return
        self.clear_results()
        self.cancel = Event()
        self.work = self.pool.submit(capture, self.case, pid, tuple(self.app.rows), self.cancel, previous=previous)
        self.status.configure(text=f"Reading Windows snapshot for PID {pid}…", foreground=MUTED)
        self.stop.state(["!disabled"])
        self.take.state(["disabled"])
        self.timer = self.after(35, self.poll)

    def poll(self):
        self.timer = None
        if self.work is None or self.closed:
            return
        if not self.work.done():
            self.timer = self.after(40, self.poll)
            return
        work = self.work
        self.work = self.cancel = None
        self.stop.state(["disabled"])
        self.take.state(["!disabled"])
        try:
            result = work.result()
            if self.case is not self.app.case or result.digest != self.case.digest:
                raise ValueError("The observation belongs to another DLL snapshot.")
        except (OSError, ValueError, RuntimeError, TimeoutError) as error:
            self.status.configure(text=str(error), foreground=AMBER)
            return
        self.sample = self.connection = result
        self.forget.state(["!disabled"])
        debugger = "debugger attached" if result.debugger_attached else "standalone observation"
        self.status.configure(text=f"{result.provider} · {debugger} · PID {result.pid} · {result.captured_at} · "
                                   f"module base 0x{result.module_base:X} · {result.module_path}", foreground=MUTED)
        for i, thread in enumerate(result.threads):
            rip = thread.registers.get("RIP")
            self.threads.insert("", "end", iid=str(i), values=(thread.tid,
                f"0x{rip:016X}" if rip is not None else "Unavailable",
                hex(thread.rva) if thread.rva is not None else "—", thread.status))
        if result.threads:
            i = next((i for i,t in enumerate(result.threads) if t.raw), 0)
            self.threads.selection_set(str(i))
            self.threads.see(str(i))
        self.select_thread()

    def thread(self):
        selected = self.threads.selection()
        if selected and self.sample and self.case is self.app.case:
            return self.sample.threads[int(selected[0])]

    def matched(self):
        thread = self.thread()
        if thread and thread.raw:
            idx = self.app.views.row_at.get(thread.rva)
            if idx is not None and self.app.rows[idx].raw == thread.raw:
                return idx

    def select_thread(self, _event=None):
        self.registers.delete(*self.registers.get_children())
        thread = self.thread()
        if thread:
            for name, value in thread.registers.items():
                ptr = thread.pointers.get(name)
                self.registers.insert("", "end", values=(name, f"0x{value:016X}",
                                                         hex(ptr) if ptr is not None else "—"))
        idx = self.matched()
        self.follow.state(["!disabled" if idx is not None else "disabled"])
        detail = ""
        if thread:
            detail = f"Thread {thread.tid} · registers captured {thread.captured_at}"
            if thread.file_raw or thread.memory:
                file_hex = thread.file_raw.hex(" ").upper() or "Unavailable"
                live_hex = thread.memory.hex(" ").upper() or "Unavailable"
                detail += f"\nFile bytes   {file_hex}\nMemory       {live_hex}"
                if thread.memory_at:
                    detail += f" · read {thread.memory_at}"
        self.summary.configure(text=detail, foreground=TEAL if idx is not None else MUTED)
        self.overlay()

    def overlay(self):
        app = self.app
        label = app.views.runtime_line
        idx = self.matched()
        if idx is None or idx != app.index or self.closed:
            label.pack_forget()
            return
        thread = self.thread()
        regs = "  ".join(f"{key}=0x{thread.registers[key]:X}" for key in ("RIP", "RSP", "RAX", "RCX")
                         if key in thread.registers)
        label.configure(text=f"Capture · PID {self.sample.pid} · thread {thread.tid} · {thread.captured_at}\n"
                             f"{thread.raw.hex(' ').upper()} · matches file bytes  {regs}")
        if not label.winfo_manager():
            label.pack(before=app.views.hex, side="bottom", fill="x", padx=8)

    def show_instruction(self):
        idx = self.matched()
        if idx is not None:
            self.app.select(idx)
            self.app.root.lift()
            self.app.views.listing.focus_set()

    def close(self):
        self.closed = True
        self.cancel_capture()
        self.pool.shutdown(wait=False, cancel_futures=True)
        self.app.views.runtime_line.pack_forget()
        self.app.observation_window = None
        self.destroy()
