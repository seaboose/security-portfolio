"""Read synthetic control records, independently score each stage, then check its receipt."""

from dataclasses import dataclass
from pathlib import Path

from .cooldown import Case, load_case, score
from .records import fields, integer, read_document, snapshot, version_one


@dataclass(frozen=True)
class Attempt:
    outcome: str
    expression: str | None
    saved_passed: int | None
    saved_outputs: tuple[bool, ...] | None


@dataclass(frozen=True)
class Run:
    build: str
    initial: Attempt
    revised: Attempt | None


def read_attempt(record) -> Attempt:
    fields(record, "outcome", "expression", "saved_passed", "saved_outputs")
    outcome = record["outcome"]
    outputs = record["saved_outputs"]
    if outcome == "submitted":
        if type(record["expression"]) is not str:
            raise ValueError("missing submitted expression")
        integer(record["saved_passed"], 0, 48)
        if type(outputs) is not list or not all(type(value) is bool for value in outputs):
            raise ValueError("expected a saved Boolean outcome for each check")
    elif outcome in ("abstained", "timed_out"):
        if any(record[key] is not None for key in ("expression", "saved_passed", "saved_outputs")):
            raise ValueError("an unsubmitted answer cannot have a predicate or score")
    else:
        raise ValueError("unsupported attempt outcome")
    return Attempt(outcome, record["expression"], record["saved_passed"],
                   tuple(outputs) if outputs is not None else None)


def read_run(record, case: Case) -> Run:
    fields(record, "build", "range_sha256", "provenance", "calls", "elapsed_ms", "initial", "revised")
    build = record["build"]
    if type(build) is not str or build not in case.evidence:
        raise ValueError("unknown build")
    if record["range_sha256"] != case.evidence[build]["range_sha256"]:
        raise ValueError("run is bound to a different routine")
    if record["provenance"] != "synthetic_control":
        raise ValueError("v1 accepts labeled synthetic controls only")
    integer(record["calls"], 0, 0)
    if record["elapsed_ms"] is not None:
        raise ValueError("synthetic controls do not have measured agent time")
    revised = record["revised"]
    return Run(build, read_attempt(record["initial"]), None if revised is None else read_attempt(revised))


def replay_attempt(attempt: Attempt, case: Case) -> dict:
    result = {"outcome": attempt.outcome, "expression": attempt.expression}
    if attempt.outcome == "submitted":
        result.update(score(attempt.expression, case))
        if result["passed"] != attempt.saved_passed:
            raise ValueError("recomputed score differs from the saved count")
        if tuple(result["outputs"]) != attempt.saved_outputs:
            raise ValueError("recomputed answers differ from the saved outcomes")
    return result


def replay(path: Path) -> dict:
    case = load_case()
    document = read_document(snapshot(path))
    version_one(document)
    fields(document, "version", "case_sha256", "runs")
    if document["case_sha256"] != case.digest:
        raise ValueError("saved records target a different case revision")
    records = document["runs"]
    if type(records) is not list or len(records) != len(case.evidence):
        raise ValueError("expected one run per build")
    runs = [read_run(record, case) for record in records]
    if {run.build for run in runs} != case.evidence.keys():
        raise ValueError("expected both distinct builds")

    report = []
    for run in runs:
        report.append({
            "build": run.build, "range_sha256": case.evidence[run.build]["range_sha256"],
            "initial": replay_attempt(run.initial, case),
            "revised": replay_attempt(run.revised, case) if run.revised else None,
        })
    return {"version": 1, "case_sha256": case.digest, "provenance": "synthetic_control",
            "calls": 0, "elapsed_ms": None, "runs": report}
