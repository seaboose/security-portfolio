"""Address-ordered control-flow graph linked to the investigation cursor."""

from bisect import bisect_left
import tkinter as tk
from tkinter import ttk

from .appearance import AMBER, CANVAS, CRIMSON, INK, LINE, MONO, MUTED, SELECTION, SURFACE, TEAL, mono_font


EDGE_NAMES = {"taken": "Taken", "fallthrough": "Fall through", "jump": "Jump",
              "indirect": "Indirect", "return": "Return", "invalid": "Undecoded", "stop": "Stop"}
SOURCE_PAGE = 32


class GraphView(ttk.Frame):
    def __init__(self, parent, on_follow):
        super().__init__(parent, padding=4)
        self.on_follow = on_follow
        self.rows, self.blocks = (), ()
        self.current = None
        self.mono = mono_font(self)
        self.bind("<<InsightFontsChanged>>", self._fonts_changed)
        self.line = self.mono.metrics("linespace")
        self.pitch = self.line * 4
        self.columnconfigure(0, weight=1)
        self.rowconfigure(1, weight=1)
        self.heading = ttk.Label(self, style="DockTitle.TLabel")
        self.heading.grid(row=0, column=0, columnspan=2, sticky="ew", pady=(0, 3))
        self.canvas = tk.Canvas(self, background=CANVAS, width=1, height=1, takefocus=True,
                                highlightthickness=1, highlightbackground=LINE, highlightcolor=AMBER,
                                yscrollincrement=1)
        self.canvas.grid(row=1, column=0, sticky="nsew")
        scrollbar = ttk.Scrollbar(self, orient="vertical", command=self._scroll,
                                  style="Insight.Vertical.TScrollbar")
        scrollbar.grid(row=1, column=1, sticky="ns")
        self.canvas.configure(yscrollcommand=scrollbar.set)
        self.canvas.bind("<Configure>", self._resize)
        self.canvas.bind("<ButtonRelease-1>", self._click)
        self.canvas.bind("<MouseWheel>", self._wheel)
        self.canvas.bind("<Up>", lambda _: self._go((self.current or 0) - 1))
        self.canvas.bind("<Down>", lambda _: self._go((self.current or 0) + 1))
        self.canvas.bind("<Home>", lambda _: self._go(0))
        self.canvas.bind("<End>", lambda _: self._go(len(self.blocks)-1))
        self.detail = ttk.Label(self, font=MONO)
        self.detail.grid(row=2, column=0, columnspan=2, sticky="ew", pady=(4, 1))
        self.exits = ttk.Frame(self)
        self.exits.grid(row=3, column=0, columnspan=2, sticky="ew")
        self.sources = ttk.Frame(self)
        self.sources.grid(row=4, column=0, columnspan=2, sticky="ew", pady=(2, 0))
        self.sources.columnconfigure(0, weight=1)
        self.source_picker = ttk.Combobox(self.sources, state="readonly", width=12)
        self.source_picker.grid(row=0, column=0, sticky="ew")
        self.source_picker.bind("<<ComboboxSelected>>", self._follow_source)
        self.previous = ttk.Button(self.sources, text="‹", command=lambda: self._sources(self.page-1))
        self.next = ttk.Button(self.sources, text="›", command=lambda: self._sources(self.page+1))
        self.sources.grid_remove()

    def load(self, rows, graph, format_address, coverage=""):
        self.rows, self.graph, self.blocks = rows, graph, graph.blocks
        self.format_address = format_address
        self.current = None
        count = len(self.blocks)
        self.incoming = [[] for _ in self.blocks]
        for source, block in enumerate(self.blocks):
            for edge in block.edges:
                if edge.block is not None:
                    self.incoming[edge.block].append((source, edge.kind))
        title = f"{count} basic block{'s' if count != 1 else ''}"
        self.heading.configure(text="  ·  ".join(filter(None, (title, coverage))))
        self.detail.configure(text="")
        self._edges()
        self._resize()

    def select(self, row_index):
        if not 0 <= row_index < len(self.rows):
            return
        current = self.graph.block_at(row_index)
        if current != self.current:
            self.current = current
            block = self.blocks[current]
            start, end = self.rows[block.first], self.rows[block.stop-1]
            self.detail.configure(text=f"{self.format_address(start.rva)} – "
                                       f"{self.format_address(end.rva + len(end.raw)-1)} inclusive")
            self._edges()
        self._center()
        self._draw()

    def _edges(self):
        for child in self.exits.winfo_children():
            child.destroy()
        self._sources(0)
        if self.current is None:
            return
        for edge in self.blocks[self.current].edges:
            text = EDGE_NAMES[edge.kind]
            if edge.target is not None:
                text += "  " + self.format_address(edge.target)
            if edge.block is not None:
                widget = ttk.Button(self.exits, text=text, style="Edge.TButton",
                                    command=lambda i=edge.block: self._go(i))
            else:
                widget = ttk.Label(self.exits, text="  ·  ".join(filter(None, (text, edge.reason))),
                                   foreground=MUTED, wraplength=max(160, self.winfo_width()-12))
            widget.pack(fill="x", pady=1)

    def _sources(self, page):
        entries = self.incoming[self.current] if self.current is not None else ()
        if not entries:
            self.sources.grid_remove()
            return
        self.sources.grid()
        self.page = page
        start = page * SOURCE_PAGE
        choices = entries[start:start+SOURCE_PAGE]
        labels = [f"{EDGE_NAMES[kind]} from {self.format_address(self.rows[self.blocks[src].stop-1].rva)}"
                  for src, kind in choices]
        self.source_picker.configure(values=labels)
        self.source_picker.set(f"Incoming ({len(entries)})  ·  {labels[0]}" if len(entries) == 1
                               else f"Incoming {start+1}–{start+len(choices)} of {len(entries)}")
        for col, (button, available) in enumerate(((self.previous, start > 0),
                (self.next, start+len(choices) < len(entries))), 1):
            if len(entries) > SOURCE_PAGE:
                button.grid(row=0, column=col)
                button.state(["!disabled" if available else "disabled"])
            else:
                button.grid_remove()

    def _follow_source(self, _event):
        index = self.source_picker.current()
        if index >= 0 and self.current is not None:
            source, _ = self.incoming[self.current][self.page * SOURCE_PAGE + index]
            self.on_follow(self.rows[self.blocks[source].stop-1].rva)

    def _go(self, index):
        if 0 <= index < len(self.blocks):
            self.canvas.focus_set()
            self.on_follow(self.rows[self.blocks[index].first].rva)
        return "break"

    def _click(self, event):
        x, y = self.canvas.canvasx(event.x), self.canvas.canvasy(event.y)
        for item in reversed(self.canvas.find_overlapping(x, y, x, y)):
            for tag in self.canvas.gettags(item):
                if tag.startswith("block:"):
                    return self._go(int(tag[6:]))

    def _fonts_changed(self, _event):
        self.line = self.mono.metrics("linespace")
        self.pitch = self.line * 4
        self._resize()

    def _resize(self, _event=None):
        self.heading.configure(wraplength=max(80, self.winfo_width()-10))
        self.canvas.configure(scrollregion=(0, 0, self.canvas.winfo_width(), len(self.blocks)*self.pitch))
        self._center()
        self._draw()

    def _center(self):
        if self.current is not None:
            top = (self.current + .5) * self.pitch - self.canvas.winfo_height() / 2
            self.canvas.yview_moveto(max(0, top) / (len(self.blocks)*self.pitch))

    def _wheel(self, event):
        if event.delta:
            self._scroll("scroll", -1 if event.delta > 0 else 1, "units")
        return "break"

    def _scroll(self, *args):
        if args[0] == "scroll" and args[2] == "units":
            args = ("scroll", int(args[1])*self.pitch, "units")
        self.canvas.yview(*args)
        self._draw()

    def _draw(self):
        canvas = self.canvas
        canvas.delete("all")
        width, height = canvas.winfo_width(), canvas.winfo_height()
        if width < 30 or height < 8:
            return
        top = canvas.canvasy(0)
        # Bound paint work to the viewport. The picker can trace every incoming edge.
        first = max(0, int(top // self.pitch)-1)
        stop = min(len(self.blocks), first+64, int((top+height) // self.pitch)+2)
        margin = min(max(16, width//8), self.line*4)
        left, right = margin, width-margin
        def connector(source, target, kind, clipped=False):
            branch = kind != "fallthrough"
            border = right if branch else left
            inset = margin * (1 + source % 3) / 4
            lane = border + inset if branch else border - inset
            begin = (source+.5)*self.pitch - 3
            end = (target+.5)*self.pitch + 3
            color = {"taken": TEAL, "jump": AMBER}.get(
                kind, CRIMSON if len(self.blocks[source].edges)>1 else MUTED)
            points = ([lane, max(top-4, min(top+height+4, begin))] if clipped
                      else [border, begin, lane, begin])
            points.extend((lane, max(top-4, min(top+height+4, end))))
            if top <= end <= top + height:
                points.extend((border, end))
            canvas.create_line(*points, fill=color, arrow="last", dash=(4, 2) if clipped else (),
                               width=2 if self.current in (source, target) else 1,
                               tags=(f"edge:{source}:{target}",))

        for i in range(first, stop):
            for edge in self.blocks[i].edges:
                if edge.block is not None:
                    connector(i, edge.block, edge.kind)
            # One continuation from each end keeps large joins readable. Predecessors
            # are indexed by source order once, so painting does not scan their full list.
            entries = self.incoming[i]
            before = bisect_left(entries, (first,))
            after = bisect_left(entries, (stop,))
            for src, kind in entries[max(0,before-1):before] + entries[after:after+1]:
                connector(src, i, kind, clipped=True)
        for i in range(first, stop):
            block = self.blocks[i]
            entry, end = self.rows[block.first], self.rows[block.stop-1]
            y = (i+.5)*self.pitch
            upper, lower = y-1.35*self.line, y+1.35*self.line
            tags = (f"block:{i}",)
            active = i == self.current
            canvas.create_polygon(left, upper+4, left+4, upper, right, upper, right, lower-4,
                                  right-4, lower, left, lower, fill=SELECTION if active else SURFACE,
                                  outline=CRIMSON if active else LINE, tags=tags)
            canvas.create_text(left+8, y-self.line/2, text=self.format_address(entry.rva), font=MONO,
                               anchor="w", fill=INK, tags=tags)
            text = f"{end.op} {end.args}".rstrip()
            chars = max(1, int((right-left-16)/self.mono.measure("0")))
            if len(text) > chars:
                text = text[:chars-1] + "…"
            canvas.create_text(left+8, y+self.line/2, text=text, font=MONO, anchor="w",
                               fill=MUTED, tags=tags)
