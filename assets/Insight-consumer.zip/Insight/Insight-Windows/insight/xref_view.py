"""Inspect calls and verified data accesses by site or caller."""

import tkinter as tk
from tkinter import ttk

from .appearance import AMBER, CANVAS, MONO, MUTED, UI_HEADING, apply_theme, mono_font


PAGE_SIZE = 150
COLUMNS = (
    ("rva", "Call RVA", 96),
    ("target", "Imported target", 198),
    ("caller", "Caller", 152),
    ("bytes", "Exact bytes", 150),
    ("assembly", "Instruction", 266),
    ("kind", "Route", 94),
    ("module", "Import library", 194),
)


class XrefMatrix(ttk.Frame):
    def __init__(self, parent, on_open, on_close):
        super().__init__(parent, padding=(10, 6))
        self.on_open = on_open
        self.index = None
        self.call_sites = ()
        self.global_range = None
        self.access = tk.StringVar(self, value="Calls")
        self.grouped = tk.BooleanVar(self, value=False)
        self.function_name = lambda r: r.name
        self.matches = []
        self.searchable = []
        self.page = 0
        self.sort_column = "caller"
        self.descending = False
        self.query = tk.StringVar(self)
        self.route = tk.StringVar(self, value="All routes")
        self.summary = tk.StringVar(self)
        self.coverage = tk.StringVar(self)
        self.mono = mono_font(self)
        self.bind("<<InsightFontsChanged>>", lambda _: self._render() if self.index else None)

        header = ttk.Frame(self)
        header.pack(fill="x")
        header.columnconfigure(1, weight=1)
        self.title = ttk.Label(header, text="Cross-references", font=UI_HEADING)
        self.title.grid(row=0, column=0, sticky="w")
        self.back = ttk.Button(header, text="Back to code", command=on_close)
        self.back.grid(row=0, column=2, sticky="e")
        self.mode_bar = ttk.Frame(header)
        self.mode_bar.grid(row=0, column=1, padx=8, sticky="w")
        self.stacked = False
        apply_theme(self)
        self.modes = {}
        for mode in ("Calls", "All data", "Read", "Write"):
            button = ttk.Radiobutton(self.mode_bar, text=mode, value=mode, variable=self.access,
                                     command=self._configure_scope, style="Insight.Switch.TRadiobutton")
            button.pack(side="left")
            self.modes[mode] = button
        filters = ttk.Frame(self)
        filters.pack(fill="x", pady=(4, 5))
        ttk.Label(filters, text="Find target, routine or RVA").pack(side="left")
        self.search = ttk.Entry(filters, textvariable=self.query, width=20, font=MONO)
        self.search.pack(side="left", padx=(6, 8), fill="x", expand=True)
        self.routes = ttk.Combobox(filters, textvariable=self.route, state="readonly",
                                   values=("All routes",), width=12)
        self.routes.pack(side="right")
        self.clear_target = ttk.Button(filters, text="Clear target", command=self.clear_global)

        grid = ttk.Frame(self)
        grid.pack(fill="both", expand=True)
        grid.columnconfigure(0, weight=1)
        grid.rowconfigure(0, weight=1)
        self.table = ttk.Treeview(grid, columns=[key for key, _, _ in COLUMNS],
                                  show="headings", style="Insight.Treeview", selectmode="browse", height=5)
        self.table.grid(row=0, column=0, sticky="nsew")
        self.table.heading("#0", text="Caller", anchor="w")
        self.table.column("#0", width=184, minwidth=96, stretch=False)
        for key, title, width in COLUMNS:
            self.table.heading(key, text=title, anchor="w", command=lambda k=key: self.sort(k))
            self.table.column(key, width=width, minwidth=width, stretch=key in ("target", "caller"))
        self.table.tag_configure("alternate", background="#1b191a")
        self.table.tag_configure("base", background=CANVAS)
        sy = ttk.Scrollbar(grid, orient="vertical", style="Insight.Vertical.TScrollbar", command=self.table.yview)
        sx = ttk.Scrollbar(grid, orient="horizontal", style="Insight.Horizontal.TScrollbar", command=self.table.xview)
        sy.grid(row=0, column=1, sticky="ns")
        sx.grid(row=1, column=0, sticky="ew")
        self.table.configure(yscrollcommand=sy.set, xscrollcommand=sx.set)

        footer = ttk.Frame(self)
        footer.pack(fill="x", pady=(4, 0))
        ttk.Label(footer, textvariable=self.summary).pack(side="left")
        self.group = ttk.Checkbutton(footer, text="Group by caller", variable=self.grouped,
                                     command=self._configure_scope)
        self.group.pack(side="left", padx=6)
        self.pages = ttk.Frame(footer)
        self.previous = ttk.Button(self.pages, text="Previous", command=lambda: self.change_page(-1))
        self.next = ttk.Button(self.pages, text="Next", command=lambda: self.change_page(1))
        self.previous.pack(side="left")
        self.next.pack(side="left", padx=(3, 0))
        self.detail = ttk.Label(self, textvariable=self.coverage, foreground=MUTED, wraplength=700)
        self.detail.pack(fill="x")
        self.bind("<Configure>", lambda _: self._layout())

        self.query.trace_add("write", lambda *_: self.filter())
        self.routes.bind("<<ComboboxSelected>>", lambda _: self.filter())
        self.search.bind("<Down>", self._focus_result)
        self.search.bind("<Return>", self.activate)
        self.table.bind("<Return>", self.activate)
        self.table.bind("<ButtonRelease-1>", self._click)
        def escape(_):
            on_close()
            return "break"
        for widget in (self.search, self.routes, self.table, self.previous, self.next, self.back,
                       self.clear_target, self.group, *self.modes.values()):
            widget.bind("<Escape>", escape)

    def _layout(self):
        width = self.winfo_width() - 20
        self.detail.configure(wraplength=max(120, width))
        needed = sum(w.winfo_reqwidth() for w in (self.title, self.mode_bar, self.back)) + 20
        stacked = width < needed
        if stacked != self.stacked:
            self.stacked = stacked
            if stacked:
                self.mode_bar.grid(row=1, column=0, columnspan=3, padx=0, sticky="w")
            else:
                self.mode_bar.grid(row=0, column=1, columnspan=1, padx=8, sticky="w")

    def focus_search(self):
        self.search.focus_set()
        self.search.selection_range(0, "end")

    def reset(self):
        self.set_status("")
        self.query.set("")
        self.route.set("All routes")
        self.global_range = None
        self.grouped.set(False)
        self.access.set("Calls")
        self._configure_scope()

    def set_status(self, message):
        self.index = None
        self.call_sites = ()
        self.searchable = []
        self.matches = []
        self.page = 0
        self.table.delete(*self.table.get_children())
        self.routes.state(["disabled"])
        self.summary.set(message)
        self.coverage.set("")
        self.pages.pack_forget()

    def set_index(self, index):
        if self.index is index:
            return
        self.index = index
        tree = getattr(index, "call_tree", None)
        self.call_sites = index.calls
        if tree:
            # Import and whole-tree collection have independent bounds. Preserve
            # verified import sites when the larger tree used its budget earlier.
            sites = {s.rva: s for s in index.calls}
            sites.update((s.rva, s) for s in tree.sites)
            self.call_sites = tuple(sites.values())
        routes = ["All routes", *sorted({site.kind for site in self.call_sites})]
        self.routes.configure(values=routes)
        self.routes.state(["!disabled"])
        if self.route.get() not in routes:
            self.route.set(routes[0])
        self.coverage.set(index.coverage)
        self.detail.configure(foreground=AMBER if index.partial or (tree and tree.partial) else MUTED)
        self._configure_scope()

    def select_global(self, rva, size):
        self.global_range = (rva, rva + size)
        self.query.set("")
        self.access.set("All data")
        self._configure_scope()

    def clear_global(self):
        self.global_range = None
        self._configure_scope()

    def _target(self, site):
        if site.symbol:
            return site.symbol.name
        return self.function_name(site.target) if site.target else site.label

    def for_caller(self, rva):
        self.grouped.set(True)
        self.global_range = None
        self.access.set("Calls")
        self.route.set("All routes")
        self.query.set(f"caller:0x{rva:08x}")
        self._configure_scope()

    def for_import(self, symbol):
        self.global_range = None
        self.access.set("Calls")
        self.route.set("All routes")
        self.query.set(f"{symbol.module}!{symbol.name}")
        self._configure_scope()

    def _configure_scope(self):
        mode = self.access.get()
        calls = mode == "Calls"
        self.title.configure(text="Cross-references" if calls or not self.global_range
                             else f"Global 0x{self.global_range[0]:X}")
        self._layout()
        self.clear_target.pack_forget()
        self.routes.pack_forget()
        if calls:
            self.routes.pack(side="right")
        elif self.global_range:
            self.clear_target.pack(side="right")
        columns = (("rva", "target", "caller", "bytes", "assembly", "kind", "module") if calls else
                   ("rva", "target", "caller", "bytes", "kind", "assembly", "module"))
        self.table.configure(show="tree headings" if self.grouped.get() else "headings",
                             displaycolumns=[c for c in columns if not self.grouped.get() or c != "caller"])
        self.table.column("target", stretch=calls)
        self.table.column("caller", width=152, stretch=calls)
        self.table.column("assembly", stretch=not calls)
        for col, width in (("target", 198 if calls else 110), ("module", 194 if calls else 62)):
            self.table.column(col, width=width, minwidth=width)
        self._headings()
        if self.index is None:
            return
        self.searchable = []
        for site in self.call_sites if calls else self.index.data:
            if calls:
                module = site.symbol.module.casefold() if site.symbol else ""
                target = self._target(site).casefold()
                address = f"{module}!{target} {module.removesuffix('.dll')}!{target}"
                dest = getattr(site, "target", None)
                if dest is not None:
                    address += f" 0x{dest.rva:x} 0x{dest.rva:08x}"
            else:
                if mode != "All data" and mode not in site.kind.split("/"):
                    continue
                if self.global_range:
                    low, end = self.global_range
                    if site.target_rva >= end or site.target_rva + site.width <= low:
                        continue
                address = f"0x{site.target_rva:x} 0x{site.target_rva:08x}"
            label = (f"{address} {self.function_name(site.routine).casefold()} {site.routine.name.casefold()} caller:0x{site.routine.rva:08x} "
                     f"0x{site.rva:x} 0x{site.rva:08x}")
            self.searchable.append((site, label))
        self.filter()

    def filter(self):
        if self.index is None:
            return
        terms = self.query.get().casefold().split()
        route = self.route.get() if self.access.get() == "Calls" else "All routes"
        self.matches = [site for site, text in self.searchable
                        if (route == "All routes" or route == site.kind) and all(t in text for t in terms)]
        self.page = 0
        self._sort_matches()
        self._render()

    def sort(self, column):
        self.descending = self.sort_column == column and not self.descending
        self.sort_column = column
        selected = self.table.selection()
        self._sort_matches()
        if selected and selected[0].isdigit():
            site_rva = int(selected[0])
            position = next((i for i, site in enumerate(self.matches) if site.rva == site_rva), 0)
            self.page = position // PAGE_SIZE
        self._render()

    def _sort_matches(self):
        calls = self.access.get() == "Calls"
        keys = {
            "rva": lambda s: s.rva, "target": lambda s: self._target(s).casefold() if calls else s.target_rva,
            "caller": lambda s: (self.function_name(s.routine).casefold(), s.routine.rva),
            "assembly": lambda s: s.assembly, "kind": lambda s: s.kind,
            "bytes": lambda s: s.raw,
            "module": lambda s: (s.symbol.module.casefold() if s.symbol else "") if calls else s.width,
        }
        key = keys[self.sort_column]
        self.matches.sort(key=lambda s: (key(s), s.rva), reverse=self.descending)
        if self.grouped.get() and self.sort_column != "caller":
            self.matches.sort(key=keys["caller"])

    def change_page(self, delta):
        new_page = self.page + delta
        if 0 <= new_page * PAGE_SIZE < len(self.matches):
            self.page = new_page
            self._render()

    def _headings(self):
        headers = {"target": "Call target"} if self.access.get() == "Calls" else {
            "rva": "Site RVA", "target": "Target RVA", "kind": "Access", "module": "Width", "caller": "Routine"}
        for key, title, _ in COLUMNS:
            mark = (" ▼" if self.descending else " ▲") if key == self.sort_column else ""
            self.table.heading(key, text=headers.get(key, title) + mark)

    def _render(self):
        selected = self.table.selection()
        self.table.delete(*self.table.get_children())
        calls = self.access.get() == "Calls"
        self._headings()
        start = self.page * PAGE_SIZE
        last_caller, alternate = None, True
        visible = self.matches[start:start + PAGE_SIZE]
        max_bytes = max((len(site.raw) for site in visible), default=0)
        self.table.column("bytes", width=max(150, self.mono.measure(("FF " * max_bytes).strip()) + 12))
        for site in visible:
            if last_caller != site.routine.rva:
                alternate = not alternate
                last_caller = site.routine.rva
            parent = ""
            if self.grouped.get():
                parent = f"caller:{site.routine.rva}"
                if not self.table.exists(parent):
                    self.table.insert("", "end", iid=parent, open=True,
                                      text=f"{self.function_name(site.routine)}  ·  0x{site.routine.rva:X}")
            target = self._target(site) if calls else f"0x{site.target_rva:08X}"
            detail = (site.symbol.module if site.symbol else "") if calls else f"{site.width} B"
            values = (f"0x{site.rva:08X}", target, self.function_name(site.routine), site.raw.hex(" ").upper(),
                      site.assembly, site.kind, detail)
            self.table.insert(parent, "end", iid=str(site.rva), values=values, tags=("alternate" if alternate else "base",))
        count = len(self.matches)
        if count:
            first = str(self.matches[start].rva)
            active = selected[0] if selected and self.table.exists(selected[0]) else first
            self.table.focus(active)
            self.table.selection_set(active)
            self.table.see(active)
        suffix = ""
        if count > PAGE_SIZE:
            suffix = f" · showing {start+1}–{min(start+PAGE_SIZE, count)}"
            self.pages.pack(side="right")
            self.previous.state(["!disabled" if start else "disabled"])
            self.next.state(["!disabled" if start + PAGE_SIZE < count else "disabled"])
        else:
            self.pages.pack_forget()
        if not calls:
            self.summary.set(f"{count:,} access site{'s' if count != 1 else ''}{suffix}")
        elif count:
            self.summary.set(f"{count:,} call site{'s' if count != 1 else ''}{suffix}")
        elif self.index is not None:
            query = self.query.get().strip().casefold()
            if self.route.get() == "All routes" and any(query == s.name.casefold() for s in self.index.imports):
                self.summary.set("Import found · no resolved call sites")
            else:
                self.summary.set("No matching call sites" if self.call_sites else "No indexed calls")

    def _focus_result(self, _event):
        if self.matches:
            self.table.focus_set()
        return "break"

    def _click(self, event):
        if self.table.identify_region(event.x, event.y) == "cell":
            item = self.table.identify_row(event.y)
            if item:
                self.table.selection_set(item)
                self.activate()

    def activate(self, _event=None):
        selected = self.table.selection()
        if selected:
            if not selected[0].isdigit():
                self.table.item(selected[0], open=not self.table.item(selected[0], "open"))
                return "break"
            start = self.page * PAGE_SIZE
            rva = int(selected[0])
            site = next(s for s in self.matches[start:start + PAGE_SIZE] if s.rva == rva)
            self.on_open(site)
        return "break"
