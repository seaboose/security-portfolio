"""Bounded reads and validation shared by the case and saved-run readers."""

import json
import os
from pathlib import Path
import stat


LIMIT = 64 * 1024


def reserved_name(part):
    """Recognize Windows device names on every supported Python version."""
    if hasattr(os.path, "isreserved"):
        return os.path.isreserved(part)
    return Path(part).is_reserved() or part.endswith((" ", ".")) or any(
        ord(ch) < 32 or ch in '<>:"|?*' for ch in part)


def local_path(path):
    """Reject Windows device, remote and redirected paths before touching their targets."""
    path = Path(path).absolute()
    if os.name == "nt":
        import ctypes
        if (len(path.drive) != 2 or path.drive[0] not in "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz"
                or path.drive[1] != ":" or any(p != ".." and reserved_name(p) for p in path.parts[1:])):
            raise ValueError("Choose an ordinary file on a local drive.")
        if ctypes.windll.kernel32.GetDriveTypeW(path.anchor) not in (2, 3, 5, 6):
            raise ValueError("Choose a file on a local drive.")
        for component in (*reversed(path.parents), path):
            try:
                status = component.lstat()
            except FileNotFoundError:
                continue
            if status.st_reparse_tag & 0x20000000:  # Windows name-surrogate tag (junction or link)
                raise ValueError("Choose a path outside links and redirected folders.")
            # Cloud placeholders can otherwise fetch evidence from a remote provider on open.
            if status.st_file_attributes & (0x1000 | 0x40000 | 0x400000):
                raise ValueError("Make this file available offline before opening it.")
    return path


def read_local(path, limit):
    path = local_path(path)
    if not path.is_file():
        raise ValueError("Expected a regular local file.")
    with path.open("rb") as stream:
        info = os.fstat(stream.fileno())
        if not stat.S_ISREG(info.st_mode) or info.st_size > limit:
            raise ValueError(f"Choose a regular file up to {limit:,} bytes.")
        if os.name == "nt":
            import ctypes
            import msvcrt
            name = ctypes.create_unicode_buffer(32768)
            handle = ctypes.c_void_p(msvcrt.get_osfhandle(stream.fileno()))
            size = ctypes.windll.kernel32.GetFinalPathNameByHandleW(handle, name, len(name), 2)
            if not 0 < size < len(name) or not name.value.casefold().startswith("\\device\\harddiskvolume"):
                raise ValueError("The open file could not be verified as a local disk file.")
        data = stream.read(info.st_size + 1)
    if len(data) != info.st_size:
        raise ValueError("The file changed size while it was being read.")
    return data


def snapshot(path: Path) -> bytes:
    return read_local(path, LIMIT)


def unique_fields(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("duplicate JSON field")
        result[key] = value
    return result


def reject_number(_):
    raise ValueError("records use bounded integers only")


def read_document(data: bytes) -> dict:
    if len(data) > LIMIT:
        raise ValueError("record exceeds 64 KiB")
    try:
        value = json.loads(data.decode("utf-8"), object_pairs_hook=unique_fields,
                           parse_float=reject_number, parse_constant=reject_number)
    except (UnicodeError, json.JSONDecodeError, RecursionError) as error:
        raise ValueError("invalid UTF-8 JSON or excessive nesting") from error

    def check(item, depth):
        if depth > 8:
            raise ValueError("record nesting exceeds eight levels")
        if isinstance(item, str) and len(item) > 256:
            raise ValueError("record string exceeds 256 characters")
        if isinstance(item, (dict, list)):
            if len(item) > 64:
                raise ValueError("record container exceeds 64 entries")
            if isinstance(item, dict):
                for key in item:
                    check(key, depth + 1)
                item = item.values()
            for child in item:
                check(child, depth + 1)

    check(value, 0)
    if not isinstance(value, dict):
        raise ValueError("expected a JSON object")
    return value


def fields(record, *names):
    if type(record) is not dict or record.keys() != set(names):
        raise ValueError("expected exactly these fields: " + ", ".join(names))


def version_one(record):
    if type(record.get("version")) is not int or record["version"] != 1:
        raise ValueError("unsupported record version (expected integer 1)")


def integer(value, low, high):
    if type(value) is not int or not low <= value <= high:
        raise ValueError(f"expected an integer in [{low}, {high}]")
    return value
