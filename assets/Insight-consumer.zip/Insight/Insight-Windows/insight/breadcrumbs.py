"""Show the analyst's visited locations independently of the program's call tree."""

import tkinter as tk
from tkinter import ttk

from .appearance import INK, MONO, MUTED, SELECTION, SURFACE


class Breadcrumbs(ttk.Frame):
    def __init__(self, parent, follow):
        super().__init__(parent)
        self.follow = follow
        self.case, self.trail, self.step = None, (), -1
        visited = ttk.Menubutton(self, text="Visited")
        self.menu = tk.Menu(visited, tearoff=False, postcommand=self._menu, font=MONO,
                            background=SURFACE, foreground=INK, activebackground=SELECTION,
                            activeforeground=INK)
        visited.configure(menu=self.menu)
        visited.pack(side="left", padx=(0, 4))
        self.crumbs = [ttk.Button(self, style="Edge.TButton") for _ in range(2)]
        self.current = ttk.Label(self, font=MONO, foreground=MUTED)
        self.visible_count = 1
        self.bind("<Configure>", self._resize)

    def _resize(self, event):
        count = 2 if event.width >= self.winfo_fpixels("8i") else 1
        if count != self.visible_count:
            self.visible_count = count
            self.refresh(self.case, self.trail, self.step)

    def _location_label(self, index, compact=False):
        key, at = self.trail[index]
        routine = self.case.keys[key]
        name = self.function_name(routine) if hasattr(self, "function_name") else routine.name
        if compact and len(name) > 17:
            name = name[:16] + "…"
        return f"{name}  {'0x' if self.case.image else '+0x'}{at:X}"

    def _visit(self, index):
        return lambda case=self.case, coord=self.trail[index]: self.follow(case, index, coord)

    def refresh(self, case, trail, step):
        self.case, self.trail, self.step = case, trail, step
        for widget in (*self.crumbs, self.current):
            widget.pack_forget()
        if case is None or not 0 <= step < len(trail):
            return
        # A previous routine's last visited instruction is the analyst's departure site.
        previous = []
        key = trail[step][0]
        for i in range(step-1, -1, -1):
            if trail[i][0] != key:
                previous.append(i)
                key = trail[i][0]
                if len(previous) == self.visible_count:
                    break
        if not previous and step:
            previous.append(step-1)
        for button, i in zip(self.crumbs, reversed(previous)):
            button.configure(text=self._location_label(i, True) + "  ›", command=self._visit(i))
            button.pack(side="left", padx=(0, 2))
        self.current.configure(text=self._location_label(step, True))
        self.current.pack(side="left", fill="x", expand=True)

    def _menu(self):
        self.menu.delete(0, "end")
        if self.case is None:
            return
        for index in reversed(range(len(self.trail))):
            self.menu.add_command(label=self._location_label(index), command=self._visit(index),
                                  state="disabled" if index == self.step else "normal")
