"""Bind saved analyst revisions to verified case bytes and export them atomically."""

import os
from pathlib import Path
import json
import re
from tempfile import NamedTemporaryFile

from .byte_transforms import read_range
from .finding_format import (MAX_CITATIONS, MAX_HISTORY, PROVENANCE, _canonical, _hash, _identity, _text,
                             serialize_record, validate_envelope)
from .note_markdown import markdown
from .records import local_path, read_local, unique_fields


def _check_bytes(case, citations):
    mode = "module_rva" if case.image is not None else "routine_relative"
    if case.image is not None:
        if case.data != case.image.data or _hash(case.data)!=case.digest:
            raise ValueError("Snapshot bytes differ from the recorded artifact SHA-256.")
    else:
        from .cooldown import ASSET_DIR, OBJECT_FILES
        from .records import snapshot
        name = case.example["name"]
        if name not in OBJECT_FILES or _hash(snapshot(ASSET_DIR/OBJECT_FILES[name]))!=case.digest:
            raise ValueError("Packaged object SHA-256 mismatch.")
        from .desktop import functions_for
        functions = functions_for(name,case.digest)
    for item in citations:
        key, at = item["routine"],item["address"]
        if key not in case.keys:
            raise ValueError("Cited routine is outside the current verified index.")
        routine = case.keys[key]
        if not routine.rva <= at < at+item["size"] <= routine.end:
            raise ValueError("Cited range exceeds its routine.")
        if case.image is None:
            original = next((r for r in functions[key] if r["at"]==at),None)
            data = bytes.fromhex(original["bytes"]) if original else b""
        else:
            data = read_range(case,key,(),at,item["size"]).data
        if data.hex(" ").upper()!=item["bytes"] or item["provenance"]!=PROVENANCE[mode]:
            raise ValueError("A cited range does not match the selected artifact's original bytes.")


def verify_case(record, case):
    validate_envelope(record)
    if record["sha256"]!=case.digest or (record["coordinate"]=="module_rva")!=(case.image is not None):
        raise ValueError("Finding belongs to a different artifact or coordinate system.")
    _check_bytes(case, record["citations"])
    if record["surge_observation"]:
        from .surge_exchange import verify_observation
        verify_observation(case,record["surge_observation"])
    routines = {}
    for item in record["citations"]:
        key = item["routine"]
        if key not in routines:
            if len(routines)>=8:
                raise ValueError("A finding may cite up to eight routines.")
            routines[key] = {r.rva:r.raw for r in case.instructions(case.keys[key]) if r.flow!="invalid"}
        if routines[key].get(item["address"])!=bytes.fromhex(item["bytes"]):
            raise ValueError("Citation must start and end on the verified instruction.")
    return record


def _refs(body, relative):
    for token,tags in markdown(body):
        if "address" in tags:
            if token.startswith("@+")!=relative:
                raise ValueError("Use @0x for DLL RVAs or @+0x for packaged routine offsets.")
            yield int(token[token.index("0"):],16)


def _citations(case, note, body):
    primary = case.keys.get(note["routine"])
    if primary is None:
        raise ValueError("Follow the pinned citation to recover its routine before reviewing.")
    addresses = dict.fromkeys([note["rva"], *_refs(body,case.image is None)])
    if len(addresses)>MAX_CITATIONS:
        raise ValueError("A finding supports at most 32 distinct citations.")
    found, routines = [], {}
    mode = "module_rva" if case.image is not None else "routine_relative"
    for at in addresses:
        owners = [primary] if primary.rva <= at < primary.end else [
            r for r in case.routines if case.image is not None and r.rva <= at < r.end]
        if len(owners)!=1:
            raise ValueError(f"Citation 0x{at:X} has no unique indexed routine.")
        key = case.key(owners[0])
        if key not in routines:
            if len(routines)>=8:
                raise ValueError("Limit one finding to eight cited routines.")
            routines[key] = {row.rva:row for row in case.instructions(owners[0])}
        row = routines[key].get(at)
        if row is None or row.flow=="invalid" or not 1 <= len(row.raw) <= 15:
            raise ValueError(f"Citation 0x{at:X} must be a verified instruction start.")
        if not found and row.raw!=note["raw"]:
            raise ValueError("Pinned bytes differ from the verified instruction.")
        found.append(dict(routine=key,address=at,size=len(row.raw),bytes=row.raw.hex(" ").upper(),
                          sha256=_hash(row.raw),provenance=PROVENANCE[mode]))
    _check_bytes(case,found)
    return found


def mark_prediction(store, note):
    """Called inside the first note-revision transaction."""
    store.db.execute("INSERT INTO finding_predictions VALUES(?)",(note,))


def prediction_only(store,note,number):
    return number==1 and bool(store.db.execute("SELECT 1 FROM finding_predictions WHERE note=?",(note,)).fetchone())


def details(store,note,number):
    row = store.db.execute("""SELECT tests,limitations FROM finding_reviews WHERE note=? AND rev=?""",
                           (note,number)).fetchone()
    return tuple(row) if row else ("","")


def approve_revision(store, case, note, number, tests="", limitations=""):
    _text(tests,2000,empty=True)
    _text(limitations,2000,empty=True)
    from .casebook import now
    with store.db:
        store.db.execute("BEGIN IMMEDIATE")
        changed = store.db.execute("""UPDATE revisions SET approved=? WHERE note=? AND number=?
            AND approved IS NULL AND number=(SELECT max(number) FROM revisions WHERE note=?)
            AND EXISTS(SELECT 1 FROM notes WHERE id=? AND digest=?)""",
                                   (now(),note,number,note,note,case.digest))
        if changed.rowcount!=1:
            raise ValueError("Review the latest saved revision before approving.")
        store.db.execute("INSERT INTO finding_reviews VALUES(?,?,?,?)",(note,number,tests,limitations))
        build_record(store,case,note,number)


def build_record(store, case, note_id, number, *, draft=False):
    note = store.db.execute("SELECT * FROM notes WHERE id=? AND digest=?",(note_id,case.digest)).fetchone()
    if not note or type(number) is not int or not 1<=number<=MAX_HISTORY:
        raise ValueError("Choose a revision from this artifact's first 256 revisions.")
    rows = store.db.execute("SELECT * FROM revisions WHERE note=? AND number<=? ORDER BY number",
                            (note_id,number)).fetchall()
    if len(rows)!=number or not draft and not rows[-1]["approved"]:
        raise ValueError("Select an approved revision to export.")
    rev = rows[-1]
    is_prediction = store.db.execute("SELECT 1 FROM finding_predictions WHERE note=?",(note_id,)).fetchone()
    if is_prediction and number==1:
        raise ValueError("Save a later interpretation before approving this prediction.")
    citations = _citations(case,note,rev["body"])
    tests, limits = details(store,note_id,number)
    from .surge_exchange import read_saved_observation, verify_observation
    observation = read_saved_observation(store,case.digest,note_id,number)
    if observation:
        verify_observation(case,observation)
    document = dict(schema="insight.finding",version=2, artifact=case.label,sha256=case.digest,
                    coordinate="module_rva" if case.image else "routine_relative",routine=note["routine"],
                    citations=citations,tests=tests,limitations=limits,
                    prediction=dict(body=rows[0]["body"],recorded=rows[0]["created"]) if is_prediction else None,
                    revision={k:rev[k] for k in ("number","body","created","approved")},
                    history=[dict(number=r["number"],body_sha256=_hash(r["body"].encode()),
                                  created=r["created"],approved=r["approved"]) for r in rows],
                    surge_observation=observation)
    document["finding_id"] = _identity(document)
    document["record_sha256"] = _hash(_canonical(document))
    return document if draft and not rev["approved"] else validate_envelope(document)


def _previous_export(path, record):
    """Only replace a previously exported revision of this finding."""
    if path.is_symlink() or path.stat().st_nlink != 1:
        return False
    try:
        existing = read_local(path, 1024 * 1024).decode("utf-8")
        if path.suffix.lower() == ".json":
            prior = validate_envelope(json.loads(existing, object_pairs_hook=unique_fields))
            return prior["finding_id"] == record["finding_id"]
        heading = (f"# Insight finding\n\nFormat insight.finding v2\n\n"
                   f"Finding ID `{record['finding_id']}` · revision ")
        existing = existing.replace("\r\n", "\n")
        return (existing.startswith(heading) and
                re.search(r"\n\nRecord SHA-256 `[a-f0-9]{64}`\n\Z", existing) is not None)
    except (ValueError, RecursionError):
        return False


def write_record(record, destination, case):
    verify_case(record, case)
    path = local_path(destination)
    if path.suffix.lower() not in (".md",".json"):
        raise ValueError("Choose a Markdown or JSON destination.")
    if case.image is not None and path == Path(case.source).absolute():
        raise ValueError("Choose a destination separate from the DLL.")
    replace = path.exists()
    if replace and not _previous_export(path, record):
        raise FileExistsError("Choose a new file or an earlier export of this finding.")
    content = serialize_record(record,path.suffix[1:].lower())
    temp = NamedTemporaryFile(mode="w", encoding="utf-8", newline="\n", dir=path.parent, delete=False)
    tmp = Path(temp.name)
    try:
        with temp:
            temp.write(content)
            temp.flush()
            os.fsync(temp.fileno())
        if replace:
            os.replace(tmp,path)
        elif os.name == "nt":
            os.rename(tmp,path)  # Fail if another writer took the new name.
        else:
            os.link(tmp,path)
    finally:
        tmp.unlink(missing_ok=True)
