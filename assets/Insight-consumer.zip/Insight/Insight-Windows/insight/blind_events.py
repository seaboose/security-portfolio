"""Privacy-preserving CLI event receipts. Only completed public answers retain text."""

from hashlib import sha256
import json
import re

from .records import fields, integer, read_document


ITEMS = ("item.started", "item.updated", "item.completed")
COUNTERS = ("input_tokens", "output_tokens", "reasoning_output_tokens")
LOCAL_OPTIONS = dict(num_ctx=4096, num_predict=384, temperature=0, seed=42, num_thread=4)


def local_request(task,model):
    data = task["packet"] if isinstance(task.get("packet"),dict) else task
    properties = dict(outcome={"enum":["submitted","abstained"]},
        expression={"enum":[a+" "+op+" "+b for a,b in (("now","deadline"),("deadline","now"))
                           for op in ("<","<=",">",">=","==","!=")]+[None]},
        citations={"type":"array","maxItems":12,"items":{"type":"integer","enum":[r["offset"] for r in data["listing"]]}},
        reason={"type":"string","minLength":1,"maxLength":200})
    schema = dict(type="object",properties=properties,required=list(properties),additionalProperties=False)
    content = json.dumps(task,ensure_ascii=True,sort_keys=True,separators=(",",":"),allow_nan=False)
    return dict(model=model,messages=[dict(role="user",content=content)],think=False,
                options=LOCAL_OPTIONS,format=schema,stream=False,keep_alive="60s")


def project(event):
    tag = event.get("type")
    clean = {"type": tag}
    if tag == "thread.started":
        thread = event.get("thread_id")
        if not isinstance(thread, str) or not re.fullmatch(r"[a-fA-F0-9-]{32,48}", thread):
            raise ValueError("Invalid runner thread identity.")
        clean["thread_id"] = thread
    elif tag == "turn.completed":
        usage = event.get("usage")
        if type(usage) is not dict:
            raise ValueError("Invalid runner usage record.")
        clean["usage"] = {key: integer(usage[key], 0, 2**31-1) if usage.get(key) is not None else None
                          for key in COUNTERS}
    elif tag in ITEMS:
        item = event.get("item")
        if type(item) is not dict or item.get("type") not in ("agent_message", "reasoning"):
            raise ValueError("Tool or unsupported runner event.")
        clean["item_type"] = item["type"]
        if tag == "item.completed" and item["type"] == "agent_message":
            if not isinstance(item.get("text"), str):
                raise ValueError("Missing visible response.")
            raw = item["text"].encode("utf-8")
            if len(raw) > 4096:
                raise ValueError("Visible response is too large.")
            clean["raw_chunks"] = [raw[i:i+64].hex() for i in range(0, len(raw), 64)]
    elif tag != "turn.started":
        raise ValueError("Unknown runner event.")
    return clean


def replay(data, usage, timed_out, task=None):
    if len(data) > 65536:
        raise ValueError("Runner receipt is too large.")
    events = [read_document(line) for line in data.splitlines()]
    if events and events[0].get("type")=="local.request":
        return replay_local(events,usage,timed_out,task)
    thread, started, completed, expired, raw, counts = None, False, False, False, None, {}
    for event in events:
        tag = event.get("type")
        if completed or expired:
            raise ValueError("Unexpected event after runner termination.")
        if tag == "thread.started" and thread is None and not started:
            fields(event, "type", "thread_id")
            thread = project(event)["thread_id"]
        elif tag == "turn.started" and thread and not started:
            fields(event, "type")
            started = True
        elif tag in ITEMS and started:
            kind = event.get("item_type")
            if kind not in ("agent_message", "reasoning"):
                raise ValueError("Tool or unsupported item in archived runner events.")
            if tag == "item.completed" and kind == "agent_message":
                fields(event, "type", "item_type", "raw_chunks")
                chunks = event["raw_chunks"]
                if (raw is not None or type(chunks) is not list or len(chunks)>64
                        or any(type(s) is not str or not re.fullmatch(r"(?:[0-9a-f]{2}){1,64}", s) for s in chunks)):
                    raise ValueError("Invalid or repeated archived visible response.")
                raw = bytes.fromhex("".join(chunks))
            else:
                fields(event, "type", "item_type")
        elif tag == "turn.completed" and started and raw is not None:
            fields(event, "type", "usage")
            fields(event["usage"], *COUNTERS)
            counts = project(event)["usage"]
            completed = True
        elif tag == "operator.timeout" and started:
            fields(event, "type")
            expired = True
        else:
            raise ValueError("Invalid order or unsupported archived runner event.")
    if (not thread or not started or expired != timed_out or not (expired or completed)
            or usage["calls"] != 1 or usage["tool_calls"] != 0
            or not usage["provenance"].startswith("Fresh CLI thread "+thread+".")):
        raise ValueError("Archived execution differs from the sealed session.")
    for source, key in zip(COUNTERS, ("input_tokens", "output_tokens", "reasoning_tokens")):
        if usage[key] != counts.get(source):
            raise ValueError("Archived token counts differ from the sealed usage.")
    visible = b"" if expired else raw
    if len(visible) != usage["reply_bytes"] or sha256(visible).hexdigest() != usage["raw_reply_sha256"]:
        raise ValueError("Archived visible response differs from the sealed reply.")
    return thread


def replay_local(events,usage,timed_out,task):
    if len(events)!=2:
        raise ValueError("Expected a single local model request and terminal event.")
    request,end = events
    fields(request,"type","model","model_sha256","request_sha256","request_id")
    identity, weights = request["request_id"],request["model_sha256"]
    if (not isinstance(identity,str) or not re.fullmatch(r"[0-9a-f]{32}",identity) or
            any(type(request[k]) is not str or not re.fullmatch(r"[0-9a-f]{64}",request[k]) for k in ("model_sha256","request_sha256")) or
            request["model"]!=usage["model"] or usage["calls"]!=1 or usage["tool_calls"]!=0 or
            usage["budget_status"]!="enforced" or usage["reasoning_tokens"] is not None or
            not usage["provenance"].endswith(f"Request {identity}. Model SHA-256 {weights}.")):
        raise ValueError("Invalid local model request or provenance.")
    if task is None:
        raise ValueError("Missing anonymous task for replay.")
    outbound = json.dumps(local_request(task,usage["model"]),ensure_ascii=True,sort_keys=True,
                          separators=(",",":"),allow_nan=False).encode("ascii")
    if sha256(outbound).hexdigest()!=request["request_sha256"]:
        raise ValueError("The local request differed from its declared packet and settings.")
    raw = b""
    if timed_out:
        fields(end,"type")
        if end["type"]!="operator.timeout" or any(usage[k] is not None for k in ("input_tokens","output_tokens")):
            raise ValueError("Local timeout counters differ from the sealed record.")
    else:
        fields(end,"type","reply_chunks","done_reason","input_tokens","output_tokens","tool_calls")
        if (end["type"]!="local.completed" or end["done_reason"] not in ("stop","length") or end["tool_calls"]!=0 or
                any(integer(end[k],1,2**31-1)!=usage[k] for k in ("input_tokens","output_tokens"))):
            raise ValueError("Local execution counters differ from the sealed usage.")
        chunks = end["reply_chunks"]
        if (type(chunks) is not list or len(chunks)>64 or
                any(type(s) is not str or not re.fullmatch(r"(?:[0-9a-f]{2}){1,64}",s) for s in chunks)):
            raise ValueError("Invalid local event response bytes.")
        raw = bytes.fromhex("".join(chunks))
    if len(raw)!=usage["reply_bytes"] or sha256(raw).hexdigest()!=usage["raw_reply_sha256"]:
        raise ValueError("Local model output differs from the sealed reply.")
    return identity
