"""Explicit review and execution of local evidence queries in the native workbench."""

from concurrent.futures import ThreadPoolExecutor
from hashlib import sha256
from pathlib import Path
import re
from threading import Event
import tkinter as tk
from tkinter import filedialog, ttk

from . import dialogs
from .appearance import AMBER, CANVAS, INK, MONO, MUTED, SELECTION, TEAL, scrollable
from .script_runner import Favorites, MAX_SOURCE, SIGNATURES, Snapshot, execute, read_source, review, validate_source


class _Source(tk.Text):
    """Cap inserts, including clipboard paste, before handing them to the text buffer."""
    def __init__(self, parent, **kwargs):
        super().__init__(parent, undo=False, **kwargs)
        self.original = self._w+"-source"
        self.tk.call("rename", self._w, self.original)
        self.tk.createcommand(self._w,self._command)
        self.bind("<Destroy>", self._cleanup)

    def _cleanup(self, _event):
        self.tk.deletecommand(self._w)

    def _command(self, command, *args):
        if command in ("insert","replace"):
            current = str(self.tk.call(self.original,"get","1.0","end-1c"))
            replacing = str(self.tk.call(self.original,"get",args[0],args[1])) if command=="replace" else ""
            text = args[2 if command=="replace" else 1::2]
            if len(current)-len(replacing)+sum(map(len,text))>MAX_SOURCE:
                self.event_generate("<<ScriptLimit>>",when="tail")
                return ""
        return self.tk.call(self.original,command,*args)


def open_scripts(app):
    window = getattr(app,"script_window",None)
    if window and window.winfo_exists():
        window.lift()
        return window
    if not app.case:
        app.status.set("Open a DLL or packaged example before using evidence scripts.")
        return
    app.script_window = ScriptWindow(app)
    return app.script_window


class ScriptWindow(tk.Toplevel):
    def __init__(self, app):
        super().__init__(app.root)
        self.title("Evidence scripts — Insight")
        self.geometry("800x640")
        self.minsize(530,440)
        self.app = app
        self.opened_scope = self.current_scope()
        self.favorites = Favorites(app.store)
        self.pool = ThreadPoolExecutor(max_workers=1, thread_name_prefix="evidence-script")
        self.approved = self.future = self.poll = self.paint = None
        self.stop = Event()
        self.protocol("WM_DELETE_WINDOW", self.close)
        self.columnconfigure(0,weight=1)
        self.rowconfigure(2,weight=1)
        tools = ttk.Frame(self,padding=(8,5))
        tools.grid(row=0,column=0,sticky="ew")
        ttk.Button(tools,text="Open script…",command=self.open_file).pack(side="left")
        self.picker = ttk.Combobox(tools,state="readonly",width=17)
        self.picker.pack(side="left",padx=4)
        self.picker.bind("<<ComboboxSelected>>",self.load_favorite)
        ttk.Button(tools,text="Save favorite…",command=self.save_favorite).pack(side="left")
        self.remove = ttk.Button(tools,text="Remove favorite",command=self.remove_favorite)
        self.remove.pack(side="left",padx=4)
        scope = ttk.Frame(self,padding=(8,0))
        scope.grid(row=1,column=0,sticky="ew")
        self.scope = ttk.Label(scope, font=MONO)
        self.scope.pack(fill="x")
        self.scope.bind("<Configure>",lambda e:self.scope.configure(wraplength=max(100,e.width-4)))
        panes = tk.PanedWindow(self,orient="vertical",bg=CANVAS,sashwidth=5,borderwidth=0,opaqueresize=True)
        panes.grid(row=2,column=0,sticky="nsew")
        editing = ttk.Frame(panes)
        editing.columnconfigure(0,weight=1)
        editing.rowconfigure(0,weight=1)
        panes.add(editing,minsize=105,stretch="always")
        parts = ttk.Frame(editing,padding=(8,4))
        parts.grid(row=0,column=0,sticky="nsew")
        self.editor = _Source(parts,font=MONO,background=CANVAS,foreground=INK,insertbackground=AMBER,
                              selectbackground=SELECTION,wrap="none",width=30,height=6)
        scrollable(parts,self.editor)
        self.editor.tag_configure("api",foreground=TEAL)
        self.editor.tag_configure("value",foreground=AMBER)
        self.editor.tag_configure("comment",foreground=MUTED)
        self.editor.bind("<<Modified>>",self.edited)
        self.editor.bind("<<ScriptLimit>>",lambda _:self.status.configure(text="Script limit: 8192 bytes."))
        self.editor.bind("<Control-space>",lambda _:self.complete())
        bar = ttk.Frame(editing,padding=(8,2))
        bar.grid(row=1,column=0,sticky="ew")
        ttk.Label(bar,text="API").pack(side="left")
        self.api = ttk.Combobox(bar,values=tuple(SIGNATURES),state="readonly",width=14)
        self.api.current(0)
        self.api.pack(side="left",padx=(4,0))
        ttk.Button(bar,text="Insert call",command=lambda:self.complete(self.api.get())).pack(side="left")
        self.cancel = ttk.Button(bar,text="Cancel",command=self.stop_run)
        self.run = ttk.Button(bar,text="Run reviewed script",command=self.run_script)
        self.review = ttk.Button(bar,text="Review",command=self.review_script)
        for button in (self.cancel,self.run,self.review):
            button.pack(side="right",padx=(3,0))
        self.status = ttk.Label(editing,padding=(8,3),foreground=AMBER)
        self.status.grid(row=2,column=0,sticky="ew")
        self.status.bind("<Configure>", lambda e:self.status.configure(wraplength=max(100,e.width-16)))
        box = ttk.Frame(panes,padding=(8,3))
        panes.add(box,minsize=65,stretch="always")
        self.output = tk.Text(box,font=MONO,background=CANVAS,foreground=INK,wrap="none",
                              state="disabled",width=35,height=6)
        scrollable(box,self.output)
        self.limits = ttk.Label(self,text="Insight queries · file-backed or packaged bytes and existing Ghidra mappings · "
                                "64 calls · 2 seconds · 32 KiB output · Ctrl+Space completes a call",padding=(8,4))
        self.limits.grid(row=3,column=0,sticky="ew")
        self.limits.bind("<Configure>",lambda e:self.limits.configure(wraplength=max(100,e.width-16)))
        self.refresh_favorites()
        self.replace("info()\ninstructions(cursor, 1)\npseudocode(cursor)\n", "Starter script")
        self.cancel.state(["disabled"])

    def current_scope(self):
        case, cite = self.app.case, self.app.citation()
        return (case.digest, cite[0], cite[1].rva) if case and cite else None

    def sync_scope(self):
        scope = self.current_scope()
        if not scope:
            self.scope.configure(text="No selected evidence.")
            return
        digest, key, at = scope
        label = "RVA" if self.app.case.image else "Offset"
        text = f"{self.app.case.label[:100]} · {digest} · {key[:100]} · {label} 0x{at:X}"
        if self.opened_scope and self.opened_scope!=scope:
            old_digest, old_key, old_at = self.opened_scope
            text += f"\nOpened at {old_digest[:12]} · {old_key[:100]} · 0x{old_at:X}"
        self.scope.configure(text=text)

    def replace(self,text,origin):
        self.origin = origin
        self.editor.delete("1.0","end")
        self.editor.insert("1.0",text)
        self.editor.edit_modified(False)
        self.invalidate()
        self.sync_scope()
        self.highlight()

    def invalidate(self):
        self.approved = None
        self.run.state(["disabled"])
        self.status.configure(text=f"{self.origin} · review the source and current selection before running.")

    def edited(self,_event=None):
        if self.editor.edit_modified():
            self.editor.edit_modified(False)
            self.invalidate()
            if self.paint is None:
                self.paint = self.after_idle(self.highlight)

    def highlight(self):
        self.paint = None
        source = self.editor.get("1.0","end-1c")
        for tag in ("api","value","comment"):
            self.editor.tag_remove(tag,"1.0","end")
        for match in re.finditer(r'#[^\n]*|"[^"\n]*"|\b(?:0x[\da-fA-F]+|\d+|[a-z_]+)\b',source):
            word = match[0]
            tag = "comment" if word.startswith("#") else "api" if word in SIGNATURES else "value"
            if tag=="value" and not (word=="cursor" or word.startswith('"') or word[0].isdigit()):
                continue
            self.editor.tag_add(tag,f"1.0+{match.start()}c",f"1.0+{match.end()}c")

    def complete(self, name=None):
        if name is None:
            prefix = re.search(r"[a-z_]*$",self.editor.get("insert linestart","insert"))
            word = prefix[0]
            matches = [s for s in SIGNATURES if s.startswith(word)]
            if len(matches)!=1:
                self.status.configure(text="Completions: "+(", ".join(matches) or "No matching call"))
                return "break"
            name = matches[0]
            self.editor.delete(f"insert-{len(word)}c","insert")
        self.editor.insert("insert", SIGNATURES[name])
        self.editor.focus_set()
        return "break"

    def _source(self):
        return validate_source(self.editor.get("1.0","end-1c"))

    def review_script(self):
        self.invalidate()
        self.sync_scope()
        try:
            source = self._source()
            commands = review(source)
            snapshot = Snapshot.capture(self.app)
        except ValueError as exc:
            self.status.configure(text=str(exc))
            return
        self.approved = source, snapshot
        self.run.state(["!disabled"])
        digest = sha256(source.encode("ascii")).hexdigest()
        self.status.configure(text=f"Reviewed {len(commands)} calls · source {digest[:16]} · "
                              f"{self.origin} · Run uses the evidence shown above.")

    def run_script(self):
        if self.future is not None or self.approved is None:
            return
        source,snapshot = self.approved
        if source!=self.editor.get("1.0","end-1c") or self.current_scope()!=snapshot.scope:
            self.invalidate()
            self.sync_scope()
            self.status.configure(text="Source or selection changed. Review again.")
            return
        self.stop = Event()
        self.future = self.pool.submit(execute,source,snapshot,self.stop)
        self.approved = None
        for button in (self.review,self.run):
            button.state(["disabled"])
        self.cancel.state(["!disabled"])
        self.status.configure(text="Running reviewed evidence queries…")
        self._output("")
        self.poll = self.after(30,self._finish,snapshot,sha256(source.encode()).hexdigest())

    def _output(self,value):
        self.output.configure(state="normal")
        self.output.delete("1.0","end")
        self.output.insert("1.0",value)
        self.output.configure(state="disabled")

    def _finish(self,snapshot,digest):
        self.poll = None
        if not self.future.done():
            self.poll = self.after(30,self._finish,snapshot,digest)
            return
        try:
            value = self.future.result()
            if self.stop.is_set():
                raise ValueError("Script cancelled.")
        except ValueError as exc:
            self.status.configure(text=str(exc))
        else:
            self._output(f"{snapshot.label[:100]} · {snapshot.digest}\nRoutine {snapshot.routine[:100]} · "
                         f"0x{snapshot.cursor:X} · script {digest}\n\n"+value)
            self.status.configure(text="Completed against the reviewed snapshot.")
        finally:
            self.future = None
            self.cancel.state(["disabled"])
            self.review.state(["!disabled"])

    def stop_run(self):
        self.stop.set()
        self.status.configure(text="Cancelling evidence queries…")

    def open_file(self):
        def browse(parent,_):
            return filedialog.askopenfilename(parent=parent,title="Open evidence script as text",
                filetypes=(("Evidence scripts","*.insight *.txt *.py"),("All files","*.*")))
        path = dialogs.input_value(self,"Open evidence script","Read local script source","Open as text",browse=browse)
        if path:
            try:
                file = Path(path.strip('"'))
                source = read_source(file)
            except (OSError,ValueError) as exc:
                self.status.configure(text=str(exc))
                return
            self.replace(source, "Local text · "+file.name[:100])

    def refresh_favorites(self):
        self.saved = self.favorites.entries()
        self.picker.configure(values=[f"{label} · {digest[:8]}" for digest,label in self.saved])
        self.picker.set("Favorites")
        self.remove.state(["disabled"])

    def save_favorite(self):
        name = dialogs.input_value(self,"Save script favorite","Name for this exact source","Save favorite")
        if name:
            try:
                digest = self.favorites.save(name,self._source())
            except ValueError as exc:
                self.status.configure(text=str(exc))
                return
            self.refresh_favorites()
            self.status.configure(text=f"Saved source {digest[:16]} to favorites.")

    def load_favorite(self,_event=None):
        i = self.picker.current()
        if i < 0:
            return
        digest,name = self.saved[i]
        try:
            text = self.favorites.load(digest)
        except ValueError as exc:
            self.status.configure(text=str(exc))
            return
        self.replace(text,"Favorite · "+name)
        self.remove.state(["!disabled"])

    def remove_favorite(self):
        i = self.picker.current()
        if i>=0:
            self.favorites.remove(self.saved[i][0])
            self.refresh_favorites()

    def close(self):
        self.stop.set()
        for job in (self.paint,self.poll):
            if job is not None:
                self.after_cancel(job)
        self.pool.shutdown(wait=False,cancel_futures=True)
        self.app.script_window = None
        self.destroy()
