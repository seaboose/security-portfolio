"""Recovered stack storage and its instruction-level evidence in the desktop reader."""

import tkinter as tk
from tkinter import ttk

from .appearance import AMBER, CANVAS, CRIMSON, LINE, MUTED, SELECTION, SURFACE, TEAL, mono_font, scrollable


def signed_offset(value):
    return f"{'−' if value < 0 else '+'}0x{abs(value):X}"


class FrameMap(tk.Canvas):
    """An interval view in entry-RSP coordinates, with five neighboring rows at most."""
    def __init__(self, parent, select, mono):
        self.line = mono.metrics("linespace")
        self.max_rows = 5
        super().__init__(parent, width=1, height=self.line*6, bg=CANVAS, highlightthickness=0)
        self.select, self.mono = select, mono
        self.order, self.positions, self.bands = (), {}, ()
        self.region_coordinates = set()
        self.current = None
        self.bind("<Configure>", lambda _: self.draw())
        self.bind("<ButtonRelease-1>", self.click)

    def load(self, slots, regions=()):
        self.order = sorted((*slots, *regions), key=lambda s: (s.offset, s.size))
        self.region_coordinates = {(s.offset, s.size) for s in regions}
        self.positions = {(s.offset, s.size): i for i, s in enumerate(self.order)}
        events = {}
        for slot in slots:
            for at, delta in ((slot.offset, 1), (slot.offset+slot.size, -1)):
                events[at] = events.get(at, 0) + delta
        active = 0
        bands = []
        points = sorted(events)
        for at, end in zip(points, points[1:]):
            active += events[at]
            bands.append((at, end, active))
        self.bands = bands
        self.current = None
        self.draw()

    def show_slot(self, slot):
        self.current = slot
        self.draw()

    def fit_height(self, height):
        rows = 1 if height < self.line*16 else 3 if height < self.line*24 else 5
        if rows != self.max_rows:
            self.max_rows = rows
            self.configure(height=(rows+1)*self.line)
            self.draw()

    def draw(self):
        self.delete("all")
        slot, width = self.current, self.winfo_width()
        if slot is None or width < 100:
            return
        ix = self.positions[(slot.offset, slot.size)]
        start = max(0, min(ix-self.max_rows//2, len(self.order)-self.max_rows))
        visible = self.order[start:start+self.max_rows]
        lo = visible[0].offset
        hi = max(s.offset+s.size for s in visible)
        labels = []
        for item in visible:
            label = f"{signed_offset(item.offset)}  {item.size} B"
            if (item.offset, item.size) in self.region_coordinates:
                label = "Analyst range  " + label
            labels.append(label)
        x0 = min(width-48, max(self.mono.measure(label) for label in ["Entry RSP · size", *labels])+7)
        x1 = max(x0+1, width-4)
        def coord(at):
            return x0 + (at-lo) * (x1-x0) // (hi-lo)
        self.create_text(3, 0, anchor="nw", text="Entry RSP · size", font=self.mono, fill=MUTED)
        # Project intervals to screen pixels first. Even thousands of overlapping
        # ranges in one pixel produce one coverage stripe, independent of byte size.
        runs = []
        for at, end, active in self.bands:
            if at >= hi:
                break
            if end <= lo:
                continue
            a, b = coord(max(at, lo)), coord(min(end, hi))
            if a == b:
                continue
            level = min(active, 2)
            if runs and runs[-1][2] == level and runs[-1][1] == a:
                runs[-1] = (runs[-1][0], b, level)
            else:
                runs.append((a, b, level))
        for a, b, level in runs:
            self.create_rectangle(a, 3, b, self.line-3, width=0, fill=(LINE, TEAL, AMBER)[level],
                                  tags=("gap", "covered", "overlap")[level])
        pitch = self.line
        for i, item in enumerate(visible):
            y = self.line + i*pitch
            tag = f"slot:{start+i}"
            region = (item.offset, item.size) in self.region_coordinates
            tags = (tag, "region") if region else (tag,)
            color = AMBER if region else CRIMSON if item is slot else MUTED
            self.create_text(3, y+pitch//2, text=labels[i], font=self.mono, anchor="w", fill=color, tags=tags)
            x = coord(item.offset)
            self.create_rectangle(x, y+2, max(x+2, coord(item.offset+item.size)), y+pitch-2,
                                  fill=SELECTION if item is slot else SURFACE, outline=color,
                                  dash=(3, 2) if region else (), tags=tags)

    def click(self, event):
        for item in reversed(self.find_overlapping(event.x, event.y, event.x, event.y)):
            for tag in self.gettags(item):
                if tag.startswith("slot:"):
                    slot = self.order[int(tag[5:])]
                    self.select(slot.offset, slot.size)
                    return


class StackFrame(ttk.Frame):
    """The recovered native_slots and projected regions share the same entry-RSP coordinates."""
    def __init__(self, parent, run, on_slot, open_layout):
        super().__init__(parent, padding=6)
        self.on_follow = None
        self.on_define = self.on_remove_region = None
        self.on_slot = on_slot
        self.current_slot = None
        self.native_slots = self.regions = ()
        self.region_coordinates = set()
        self.mono = mono_font(self)
        self.bind("<<InsightFontsChanged>>", self._fonts_changed)
        self.by_slot, self.rows, self.sites = {}, {}, {}
        self.columnconfigure(0, weight=1)
        self.rowconfigure(2, weight=1)
        self.rowconfigure(4, weight=2)

        header = ttk.Frame(self)
        header.grid(row=0, column=0, sticky="ew")
        actions = ttk.Frame(header)
        actions.pack(side="top", anchor="w")
        self.run = ttk.Button(actions, text="Recover frame", command=run)
        self.run.pack(side="left")
        self.open_layout = ttk.Button(actions, command=open_layout)
        self.define_range = ttk.Button(actions, text="Define range…", command=lambda: self.on_define())
        self.remove_region = ttk.Button(actions, text="Remove range…", command=lambda: self.on_remove_region())
        self.status = ttk.Label(header, text="Stack offsets are relative to RSP on entry.")
        self.status.pack(fill="x")
        self.status.bind("<Configure>", lambda e: self.status.configure(wraplength=max(50, e.width-4)))
        self.map = FrameMap(self, self.select_slot, self.mono)
        self.bind("<Configure>", lambda e: self.map.fit_height(e.height))
        self.slots = self._table(2, (("offset", "Entry RSP", 94), ("size", "Size", 60),
                                     ("name", "Stack variable", 150)))
        self.slots.bind("<<TreeviewSelect>>", self._select)
        self.slots.tag_configure("region", foreground=AMBER)

        bar = ttk.Frame(self)
        bar.grid(row=3, column=0, sticky="ew", pady=(5, 2))
        ttk.Label(bar, text="Accesses", style="DockTitle.TLabel").pack(side="left")
        self.mode = tk.StringVar(self, "All")
        self.modes = {}
        for mode in ("All", "Read", "Write"):
            self.modes[mode] = ttk.Radiobutton(bar, text=mode, value=mode, variable=self.mode,
                                               command=self._render, style="Insight.Switch.TRadiobutton")
            self.modes[mode].pack(side="left", padx=(5, 0))

        self.refs = self._table(4, (("access", "Access", 110), ("rva", "RVA", 70),
                                    ("bytes", "Exact bytes", 94), ("width", "Span", 48),
                                    ("instruction", "Instruction", 180)))
        self.refs.bind("<ButtonRelease-1>", lambda e: self._follow(self.refs.identify_row(e.y)))
        self.refs.bind("<Return>", lambda _: self._follow(self.refs.focus()))
        self.detail = ttk.Label(self)
        self.detail.grid(row=5, column=0, sticky="ew", pady=(4, 0))
        self.detail.bind("<Configure>", lambda e: self.detail.configure(wraplength=max(50, e.width-4)))

    def _fonts_changed(self, _event):
        self.map.line = self.mono.metrics("linespace")
        self.map.fit_height(self.winfo_height())
        self.map.configure(height=(self.map.max_rows+1)*self.map.line)
        self.map.draw()
        self._render()

    def _table(self, row, columns):
        box = ttk.Frame(self)
        box.grid(row=row, column=0, sticky="nsew", pady=(3, 0))
        table = ttk.Treeview(box, columns=tuple(key for key, _, _ in columns), show="headings",
                             selectmode="browse", height=3, style="Insight.Treeview")
        for key, title, width in columns:
            table.heading(key, text=title, anchor="w")
            table.column(key, width=width, minwidth=width, stretch=key == columns[-1][0])
        scrollable(box, table)
        return table

    def reset(self, message, busy=False):
        self.by_slot.clear()
        self.rows.clear()
        self.current_slot = None
        self.native_slots = self.regions = ()
        self.region_coordinates.clear()
        self.map.load(())
        self.map.grid_remove()
        self.open_layout.pack_forget()
        self.define_range.pack_forget()
        self.remove_region.pack_forget()
        self.on_slot(None)
        self.slots.delete(*self.slots.get_children())
        self.mode.set("All")
        self._render()
        self.run.configure(text="Cancel" if busy else "Recover frame")
        self.run.pack(side="left")
        self.status.configure(text=message)

    def populate(self, slots, rows, at=None, *, regions=()):
        self.reset("Recovered coverage · gray gap · teal storage · amber overlap"
                   if slots or regions else "Ghidra recovered no stack variables.")
        self.run.pack_forget()
        self.native_slots, self.regions = tuple(slots), tuple(regions)
        self.region_coordinates = {(slot.offset, slot.size) for slot in self.regions}
        if self.native_slots and self.on_define:
            self.define_range.pack(side="left", padx=(0, 3))
        self.rows = {r.rva: r for r in rows}
        self.map.load(self.native_slots, self.regions)
        for slot in self.map.order:
            region = (slot.offset, slot.size) in self.region_coordinates
            item = self.slots.insert("", "end", tags=("region",) if region else (),
                                     values=(signed_offset(slot.offset), f"{slot.size} B", slot.name))
            self.by_slot[item] = slot
        if self.map.order:
            self.map.grid(row=1, column=0, sticky="ew", pady=(3, 0))
            if not self.select_call(at):
                first = self.map.order[0]
                self.select_slot(first.offset, first.size)

    def select_call(self, at):
        slot = next((s for s in self.by_slot.values() if at in s.layout_calls), None)
        return slot is not None and self.select_slot(slot.offset, slot.size)

    def select_slot(self, offset, size):
        for item, slot in self.by_slot.items():
            if (slot.offset, slot.size) == (offset, size):
                self.slots.selection_set(item)
                self.slots.focus(item)
                self.slots.see(item)
                self._select()
                return True
        return False

    def _select(self, _event=None):
        selection = self.slots.selection()
        slot = self.by_slot.get(selection[0]) if selection else None
        if slot is not self.current_slot:
            self.current_slot = slot
            self.map.show_slot(slot)
            if slot:
                self.open_layout.configure(text=f"Open {slot.layout.name} layout" if slot.layout else "View layout")
                if self.define_range.winfo_manager():
                    self.open_layout.pack(side="left", before=self.define_range, padx=(0, 3))
                else:
                    self.open_layout.pack(side="left", padx=(0, 3))
            else:
                self.open_layout.pack_forget()
            if slot and (slot.offset, slot.size) in self.region_coordinates and self.on_remove_region:
                self.remove_region.pack(side="left")
            else:
                self.remove_region.pack_forget()
            self.on_slot(slot)
            self.mode.set("All")
            self._render()

    def _render(self):
        self.refs.delete(*self.refs.get_children())
        self.sites.clear()
        slot = self.current_slot
        if slot is None:
            self.detail.configure(text="")
            return
        mode = self.mode.get()
        call_output = False
        longest = {key: self.refs.heading(key, "text") for key in self.refs["columns"]}
        for access in slot.accesses:
            row = self.rows.get(access.rva)
            if row is None:
                continue
            span = f"{access.size} B" if access.size else "—"
            if access.offset != slot.offset:
                span += f" @ {signed_offset(access.offset - slot.offset)}"
            values = (access.kind, f"0x{row.rva:X}", row.raw.hex(" ").upper(), span,
                      f"{row.op} {row.args}".rstrip())
            for column, value in zip(longest, values):
                if len(value) > len(longest[column]):
                    longest[column] = value
            if mode != "All" and mode != access.kind.split()[0]:
                continue
            item = self.refs.insert("", "end", values=values)
            self.sites[item] = row
            call_output |= access.kind == "Write via call"
        for column, value in longest.items():
            width = self.mono.measure(value) + self.winfo_pixels("10p")
            self.refs.column(column, width=width, minwidth=width)
        if call_output:
            message = "Write via call shows the caller’s bytes. The callee writes through the output pointer."
        elif self.sites:
            message = "Select an access to inspect its instruction and bytes."
        else:
            message = "No verified accesses for this selection."
        self.detail.configure(text=message)

    def _follow(self, item):
        if self.on_follow and item in self.sites:
            self.on_follow(self.sites[item])
        return "break"
