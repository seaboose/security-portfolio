"""Modal prompts that share the investigation's fonts, colors and keyboard behavior."""

from pathlib import Path
import tkinter as tk
from tkinter import filedialog, ttk


from .appearance import INK, MONO, SELECTION, SURFACE, UI, apply_theme
from .records import local_path


class Prompt(tk.Toplevel):
    def __init__(self, parent, title):
        owner = parent.winfo_toplevel()
        super().__init__(owner, background=SURFACE)
        self.withdraw()
        if owner.winfo_viewable():
            self.transient(owner)
        self.title(title + " — Insight")
        self.resizable(True, False)
        self.body = ttk.Frame(self, padding=(14, 12))
        self.body.pack(fill="both", expand=True)
        self.actions = ttk.Frame(self, padding=(14, 8))
        ttk.Separator(self).pack(fill="x")
        self.actions.pack(fill="x")
        self.value = None

    def finish(self, value=None):
        self.value = value
        self.destroy()

    def show(self, accept, action, focus=None, cancel="Cancel", safe_default=False):
        button = ttk.Button(self.actions, text=action, command=accept)
        button.pack(side="right")
        dismiss = None
        if cancel:
            dismiss = ttk.Button(self.actions, text=cancel, command=self.finish)
            dismiss.pack(side="right", padx=(0, 6))
        self.bind("<Escape>", lambda _: self.finish())
        def enter(_):
            selected = self.focus_get()
            if isinstance(selected, ttk.Button):
                selected.invoke()
            elif safe_default:
                self.finish()
            else:
                accept()
            return "break"
        self.bind("<Return>", enter)
        for control in self.actions.winfo_children():
            control.bind("<Return>", enter)
        self.protocol("WM_DELETE_WINDOW", self.finish)
        previous_grab, previous_focus = self.grab_current(), self.master.focus_get()
        self.tk.call("tk::PlaceWindow", self._w, "widget", self.master._w)
        self.wait_visibility()
        self.grab_set()
        (focus or (dismiss if safe_default else button)).focus_set()
        self.wait_window()
        if previous_grab and previous_grab.winfo_exists():
            previous_grab.grab_set()
        if previous_focus and previous_focus.winfo_exists():
            previous_focus.focus_set()
        return self.value


def inform(parent, title, message):
    prompt = Prompt(parent, title)
    text = tk.Text(prompt.body, wrap="word", width=66, height=3, borderwidth=0,
                   background=SURFACE, foreground=INK, font=UI,
                   selectbackground=SELECTION, highlightthickness=0)
    text.insert("1.0", message)
    text.configure(state="disabled")
    text.pack(side="left", expand=True, fill="both")
    prompt.update_idletasks()
    lines = int(text.count("1.0", "end", "displaylines")[0])
    text.configure(height=min(14, max(2, lines)))
    if lines > 14:
        scroll = ttk.Scrollbar(prompt.body, command=text.yview, style="Insight.Vertical.TScrollbar")
        scroll.pack(side="right", fill="y")
        text.configure(yscrollcommand=scroll.set)
    prompt.show(prompt.finish, "Close", cancel=None)


def confirm(parent, title, message, action, cancel):
    prompt = Prompt(parent, title)
    ttk.Label(prompt.body, text=message, wraplength=440, justify="left").pack(anchor="w")
    return prompt.show(lambda: prompt.finish(True), action, cancel=cancel, safe_default=True)


def input_value(parent, title, label, action, initial="", browse=None):
    prompt = Prompt(parent, title)
    ttk.Label(prompt.body, text=label).pack(anchor="w", pady=(0, 5))
    row = ttk.Frame(prompt.body)
    row.pack(fill="x")
    value = tk.StringVar(prompt, value=initial)
    entry = ttk.Entry(row, textvariable=value, width=38, font=MONO)
    if browse:
        def choose():
            selection = browse(prompt, value.get())
            if selection:
                value.set(selection)
                entry.icursor("end")
                entry.xview_moveto(1)
            entry.focus_set()
        ttk.Button(row, text="Browse in Windows…", command=choose).pack(side="right", padx=(6, 0))
    entry.pack(side="left", fill="x", expand=True)
    entry.selection_range(0, "end")
    return prompt.show(lambda: prompt.finish(value.get().strip()), action, entry)


def choose_file(parent, initial=None):
    saving = initial is not None
    title = "Export approved finding" if saving else "Open x64 DLL read-only"
    def browse(dialog, value):
        path = local_path(Path(value.strip('"')).expanduser() if value else Path.home())
        options = dict(parent=dialog, title=title, initialdir=path if path.is_dir() else path.parent)
        if saving:
            return filedialog.asksaveasfilename(**options, initialfile=path.name,
                defaultextension=".md", confirmoverwrite=False, filetypes=[("Markdown", "*.md"), ("JSON", "*.json")])
        return filedialog.askopenfilename(**options, filetypes=[("Windows DLL", "*.dll"), ("All files", "*.*")])

    filename = str(Path.home() / initial) if saving else ""
    while True:
        filename = input_value(parent, title, "Markdown or JSON path" if saving else "DLL path",
                               "Export" if saving else "Open", filename, browse)
        if not filename:
            return None
        path = local_path(Path(filename.strip('"')).expanduser())
        if saving and not path.suffix:
            path = path.with_suffix(".md")
        if not saving or not path.exists() or confirm(parent, "Replace finding",
                f"Replace {path} with this approved revision?", "Replace", "Choose another path"):
            return path


def choose_recent(parent, records):
    prompt = Prompt(parent, "Recent cases")
    box = ttk.Treeview(prompt.body, columns=("name", "hash"), show="headings", selectmode="browse",
                       height=min(9, len(records)), style="Insight.Treeview")
    for column, title, width in (("name", "Artifact", 250), ("hash", "SHA-256 prefix", 165)):
        box.heading(column, text=title, anchor="w")
        box.column(column, width=width, minwidth=100)
    scroll = ttk.Scrollbar(prompt.body, command=box.yview, style="Insight.Vertical.TScrollbar")
    scroll.pack(side="right", fill="y")
    box.configure(yscrollcommand=scroll.set)
    box.pack(fill="both", expand=True)
    for record in records:
        box.insert("", "end", iid=record["digest"], values=(record["label"], record["digest"][:16]))
    first = box.get_children()[0]
    box.selection_set(first)
    box.focus(first)
    def reopen():
        if box.selection():
            prompt.finish(box.selection()[0])
    box.bind("<Double-1>", lambda e: reopen() if box.identify_row(e.y) else None)
    return prompt.show(reopen, "Reopen snapshot", box)


def choose_builds(parent, case):
    """Pick two files or compare the open, fingerprinted snapshot to a second build."""
    prompt = Prompt(parent, "Compare DLL builds")
    snapshot = f"<Open snapshot>  {case.label}  ·  {case.digest[:12]}" if case and case.image else ""
    inputs = []

    def browse(value, title):
        selection = filedialog.askopenfilename(parent=prompt, title=title,
            filetypes=[("Windows DLL", "*.dll"), ("All files", "*.*")])
        if selection:
            value.set(selection)

    for label, initial in (("Build A · baseline", snapshot), ("Build B · comparison", "")):
        ttk.Label(prompt.body, text=label).pack(anchor="w", pady=(4, 2))
        row = ttk.Frame(prompt.body)
        row.pack(fill="x", pady=(0, 5))
        value = tk.StringVar(prompt, value=initial)
        ttk.Button(row, text="Browse…", command=lambda v=value, t=label: browse(v, t)).pack(side="right", padx=(6, 0))
        entry = ttk.Entry(row, textvariable=value, width=47)
        entry.pack(fill="x", expand=True)
        inputs.append((entry, value))

    def accept():
        paths = []
        for entry, value in inputs:
            name = value.get().strip().strip('"')
            if not name:
                entry.focus_set()
                return
            paths.append(None if not paths and name == snapshot else Path(name).expanduser())
        prompt.finish(tuple(paths))

    return prompt.show(accept, "Compare read-only", inputs[int(bool(snapshot))][0])
