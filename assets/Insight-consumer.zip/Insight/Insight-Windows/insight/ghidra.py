"""Read-only, per-routine Ghidra decompilation and checked instruction associations."""

from dataclasses import dataclass
from hashlib import sha256
import json
import os
from pathlib import Path
import shutil
from tempfile import TemporaryDirectory

from .pe import MAX_FILE_SIZE, MAX_ROUTINE_BYTES, inspect_image
from .call_tree import direct_target
from .stack_frame import StackSlot, StackToken, stack_frame, stack_tokens

# Raw-data pseudo-ops and decode failures cannot corroborate an instruction boundary.
NON_INSTRUCTIONS = frozenset((
    "", "?", "??", "(bad)", "(undecoded)", "db", "dw", "dd", "df", "dq", "dt", "do", "dy", "dz",
    "byte", "sbyte", "word", "sword", "dword", "sdword", "fword", "qword", "sqword", "tbyte",
    "oword", "mmword", "xmmword", "ymmword", "zmmword", "real4", "real8", "real10",
    ".byte", ".short", ".word", ".long", ".quad",
))


@dataclass(frozen=True)
class GlobalToken:
    start: int
    end: int
    rva: int
    size: int


@dataclass(frozen=True)
class FunctionToken:
    start: int
    end: int
    rva: int


@dataclass(frozen=True)
class Line:
    text: str
    rvas: tuple[int, ...]
    unmatched: tuple[int, ...]
    globals: tuple[GlobalToken, ...] = ()
    stack: tuple[StackToken, ...] = ()
    functions: tuple[FunctionToken, ...] = ()


@dataclass(frozen=True)
class Decompilation:
    version: str
    lines: tuple[Line, ...]
    stack: tuple[StackSlot, ...] = ()


def find_runtime():
    local = os.environ.get("LOCALAPPDATA")
    if not local or not Path(local).is_absolute():
        raise ValueError("Insight's local Ghidra runtime folder is unavailable.")
    runtime = Path(local) / "Insight" / "runtime"
    ghidra = Path(os.environ.get("GHIDRA_INSTALL_DIR") or runtime / "ghidra_12.2_PUBLIC")
    java = Path(os.environ.get("JAVA_HOME") or runtime / "jdk-25.0.5+8") / "bin/java.exe"
    if not (ghidra.is_absolute() and (ghidra / "Ghidra/Framework/Utility/lib/Utility.jar").is_file()):
        raise ValueError("Ghidra 12.2 is missing. Install it in Insight's runtime folder or set GHIDRA_INSTALL_DIR.")
    if not java.is_absolute() or not java.is_file():
        raise ValueError("Ghidra requires JDK 25. Install the Insight runtime or set JAVA_HOME.")
    return ghidra, java


def _global_tokens(line, image):
    spans = line.get("globals", [])
    if not isinstance(spans, list):
        raise ValueError("Malformed Ghidra global symbol map.")
    previous = 0
    tokens = []
    for span in spans:
        if not isinstance(span, dict) or any(type(span.get(k)) is not int
                                              for k in ("start", "end", "rva", "size")):
            raise ValueError("Malformed Ghidra global token.")
        token = GlobalToken(span["start"], span["end"], span["rva"], span["size"])
        stop = token.rva + token.size
        if not (previous <= token.start < token.end <= len(line["text"])
                and 0 <= token.rva < stop <= 2**32):
            raise ValueError("Invalid Ghidra global symbol range.")
        previous = token.end
        if image is None or any(s.rva <= token.rva and stop <= s.rva + s.size for s in image.sections):
            tokens.append(token)
    return tuple(tokens)


def _function_tokens(line, entry, hits, direct, image, verified_entry):
    spans = line.get("functions", [])
    if not isinstance(spans, list) or len(spans) > len(line["text"]):
        raise ValueError("Malformed Ghidra function map.")
    tokens = []
    previous = 0
    for span in spans:
        if (not isinstance(span, dict) or any(type(span.get(k)) is not int for k in ("start", "end", "rva"))
                or span.get("kind") not in ("call", "definition")):
            raise ValueError("Malformed Ghidra function token.")
        token = FunctionToken(span["start"], span["end"], span["rva"])
        if not (previous <= token.start < token.end <= len(line["text"]) and 0 <= token.rva <= 0xffffffff):
            raise ValueError("Invalid Ghidra function token range.")
        previous = token.end
        if span["kind"] == "definition":
            if token.rva == entry and verified_entry:
                tokens.append(token)
            continue
        site = span.get("site")
        if type(site) is not int or not 0 <= site <= 0xffffffff:
            raise ValueError("Invalid Ghidra call-site RVA.")
        if (site in hits and direct.get(site) == token.rva and image is not None
                and token.rva in image.function_entries):
            tokens.append(token)
    return tuple(tokens)


def checked_output(doc, digest, entry, rows, expected_version, image=None):
    if (not isinstance(doc, dict) or doc.get("digest") != digest
            or type(doc.get("entry")) is not int or doc["entry"] != entry):
        raise ValueError("The Ghidra result refers to a different image or routine.")
    version, lines, raw = doc.get("version"), doc.get("lines"), doc.get("instructions")
    if (not isinstance(version, str) or version != expected_version or not 1 <= len(version) <= 64
            or not isinstance(raw, dict)
            or not isinstance(lines, list) or not 1 <= len(lines) <= 8192):
        raise ValueError("Malformed Ghidra line map.")
    listing = {row.rva: row.raw.hex() for row in rows if row.op.lower() not in NON_INSTRUCTIONS}
    verified_entry = entry in listing and listing[entry] == raw.get(str(entry))
    direct = {row.rva: direct_target(row) for row in rows if getattr(row, "flow", None) == "call"}
    frame = stack_frame(doc, raw, listing, rows, image)
    regions = {(slot.offset, slot.size) for slot in frame}
    checked = []
    for line in lines:
        if (not isinstance(line, dict) or not isinstance(line.get("text"), str)
                or len(line["text"]) > 32768 or not isinstance(line.get("rvas"), list)):
            raise ValueError("Malformed Ghidra pseudocode line.")
        if any(not c.isprintable() and c != "\t" for c in line["text"]):
            raise ValueError("A pseudocode line contains an embedded control character.")
        locations = line["rvas"]
        if not all(type(at) is int and 0 <= at <= 0xffffffff for at in locations):
            raise ValueError("Invalid Ghidra instruction address.")
        hits, unmatched = [], []
        for at in sorted(set(locations)):
            code = raw.get(str(at))
            if at not in listing or code is None:
                unmatched.append(at)
            elif listing[at] != code:
                raise ValueError(f"Ghidra and the snapshot disagree on the bytes at RVA 0x{at:X}.")
            else:
                hits.append(at)
        globals_ = _global_tokens(line, image)
        stack = stack_tokens(line, regions)
        functions = _function_tokens(line, entry, set(hits), direct, image, verified_entry)
        # A Ghidra spelling denotes one semantic token. Reject ambiguous identity
        # instead of letting a rename depend on which view first inserted its tag.
        stop = 0
        for token in sorted((*globals_, *stack, *functions), key=lambda t: t.start):
            if token.start < stop:
                raise ValueError("Ghidra symbol token ranges overlap.")
            stop = token.end
        checked.append(Line(line["text"], tuple(hits), tuple(unmatched), globals_, stack, functions))
    return Decompilation(version, tuple(checked), frame)


def decompile(data, digest, routine, rows, cancel=None):
    if not 0 < len(data) <= MAX_FILE_SIZE or sha256(data).hexdigest() != digest:
        raise ValueError("The DLL snapshot does not match its recorded fingerprint.")
    if not rows or rows[0].rva != routine.rva or not 0 < routine.end-routine.rva <= MAX_ROUTINE_BYTES:
        raise ValueError("Select a decoded routine before requesting pseudocode.")
    if cancel is not None and cancel.is_set():
        raise ValueError("Decompilation cancelled.")
    from .win_job import run_job
    ghidra, java = find_runtime()
    image = inspect_image(data)
    with TemporaryDirectory(prefix="insight-ghidra-") as temp:
        root = Path(temp).resolve()
        snapshot = root / "snapshot.dll"
        snapshot.write_bytes(data)
        # A direct terminal jump between two PE-indexed functions is a tail call.
        # Do not infer a boundary from the preview limit or an estimated extent.
        tail = rows[-1]
        tail_target = "none"
        if (routine.extent == "x64 unwind table" and tail.flow == "jump" and tail.target is not None
                and tail.rva + len(tail.raw) == routine.end and not routine.rva <= tail.target < routine.end
                and any(r.rva == tail.target and not r.name.startswith("Executable section ")
                        for r in image.routines)):
            tail_target = f"{tail.target:x}"
        projects, scripts = root / "project", root / "scripts"
        projects.mkdir()
        scripts.mkdir()
        script = "InsightDecompile.java"
        shutil.copyfile(Path(__file__).with_name("ghidra_scripts") / script, scripts / script)
        output = root / "lines.json"
        command = [java, "-Xmx768m", "-Xshare:off", "-XX:ActiveProcessorCount=2",
            "-Djava.system.class.loader=ghidra.GhidraClassLoader", "-Djava.awt.headless=true",
            "-Dfile.encoding=UTF-8", "--enable-native-access=ALL-UNNAMED",
            "--sun-misc-unsafe-memory-access=allow", "-Djavax.xml.accessExternalDTD=",
            "-Djavax.xml.accessExternalSchema=", "-Djavax.xml.accessExternalStylesheet=",
            f"-Duser.home={root}", f"-Dapplication.settingsdir={root / 'settings'}",
            f"-Dapplication.cachedir={root / 'cache'}", f"-Dapplication.tempdir={root / 'temp'}",
            f"-Djava.io.tmpdir={root}", "-cp", ghidra / "Ghidra/Framework/Utility/lib/Utility.jar",
            "ghidra.Ghidra", "ghidra.app.util.headless.AnalyzeHeadless", projects, "inspection",
            "-import", snapshot, "-loader", "PeLoader", "-loader-loadLibraries", "false",
            "-loader-libraryLoadDepth", "0", "-loader-linkExistingProjectLibraries", "false",
            "-readOnly", "-noanalysis", "-max-cpu", "2", "-scriptPath", scripts, "-postScript",
            script, f"{routine.rva:x}", f"{routine.end:x}", output, tail_target, "-log", root / "ghidra.log",
            "-scriptlog", root / "script.log"]
        # No inherited JVM, debugger, symbol-server or compiler flags. The analysis
        # directory contains no files supplied by the user other than the snapshot.
        windows = os.environ["SystemRoot"]
        env = {"SystemRoot": windows, "WINDIR": windows, "PATH": str(Path(windows) / "System32"),
               "TEMP": str(root), "TMP": str(root), "USERPROFILE": str(root),
               "APPDATA": str(root), "LOCALAPPDATA": str(root)}
        status = run_job(command, root, env, cancel)
        if status or not output.is_file():
            raise ValueError("Ghidra could not decompile this routine. The instruction listing is still available.")
        with output.open("rb") as stream:
            content = stream.read(4 * 1024**2 + 1)
        if len(content) > 4 * 1024**2:
            raise ValueError("The pseudocode map exceeds the supported size.")
        properties = (ghidra / "Ghidra/application.properties").read_text(encoding="utf-8")
        version = next((s.split("=", 1)[1].strip() for s in properties.splitlines()
                        if s.startswith("application.version=")), None)
        return checked_output(json.loads(content), digest, routine.rva, rows, version, image)
