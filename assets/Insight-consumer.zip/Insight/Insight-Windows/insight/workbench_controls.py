"""Workspace shortcuts dispatch to fixed application actions. Preferences contain only data."""

import re
import tkinter as tk
from tkinter import ttk

from .appearance import AMBER, MONO, available_code_fonts, set_fonts
from .dialogs import Prompt


ACTIONS = {"open": "Open DLL", "palette": "Command palette", "goto": "Find address or symbol",
           "diff": "Compare builds", "decompile": "Decompile routine", "xrefs": "XREF matrix",
           "rename": "Rename symbol", "retype": "Retype symbol", "save_note": "Save pinned note",
           "back": "Go back", "forward": "Go forward"}
_DEFAULT = {"open": "Ctrl+O", "palette": "Ctrl+K", "goto": "", "diff": "Ctrl+Shift+D",
            "decompile": "F5", "xrefs": "Ctrl+Shift+X", "rename": "L", "retype": "T",
            "save_note": "Ctrl+S", "back": "Alt+Left", "forward": "Alt+Right"}
# NSA's Ghidra Cheat Sheet, Hex-Rays Basic Usage, the Binary Ninja User Guide, and
# Vim's motion.txt/pattern.txt document these navigation and symbol-editing keys.
PROFILES = {"Insight": {}, "Ghidra": {"goto": "G"},
            "IDA Pro": {"goto": "G", "xrefs": "X", "rename": "N", "back": "Escape", "forward": "Ctrl+Enter"},
            "Binary Ninja": {"goto": "G", "rename": "N", "retype": "Y"},
            "Vim": {"goto": "/", "open": "", "back": "Ctrl+O", "forward": "Ctrl+I"}}
_DETAIL = {"Insight": "Original Insight shortcuts.",
           "Ghidra": "G opens Go To, L labels a symbol, and Alt+Left/Right navigate history.",
           "IDA Pro": "G, X, N and F5 address, reference, rename and decompile. Esc and Ctrl+Enter navigate history.",
           "Binary Ninja": "G goes to an address, N renames and Y changes a type.",
           "Vim": "Ctrl+O/I move through jump history. / opens Insight search. Open DLL stays in the File menu."}
_MODS = ("Ctrl", "Alt", "Shift")
_KEY = re.compile(r"[A-Z0-9]|F(?:[1-9]|1[0-2])|Left|Right|Up|Down|Home|End|Enter|Escape|Tab|/")
_NAMED = {key.lower():key for key in ("Left","Right","Up","Down","Home","End","Enter","Escape","Tab")}
# Preserve pane-local navigation, editing, modifier aliases and Windows system commands.
_RESERVED = {"Tab","Shift+Tab","Enter","Left","Right","Up","Down","Home","End","F1","F10",
             "Ctrl+A","Ctrl+C","Ctrl+V","Ctrl+X","Ctrl+Z","Ctrl+Y","Alt+F4","Alt+Space",
             "Ctrl+Tab","Ctrl+Shift+Tab","Alt+G","Alt+L","Alt+F","Ctrl+M","Ctrl+H"}


def canonical_chord(value):
    if not isinstance(value,str) or len(value)>32 or not value.isascii():
        raise ValueError("Use a single shortcut up to 32 ASCII characters.")
    if not value.strip():
        return ""
    parts = [s.strip().lower() for s in value.split("+")]
    modifiers = [m for m in _MODS if m.lower() in parts[:-1]]
    if len(modifiers) != len(parts)-1 or ("Ctrl" in modifiers and "Alt" in modifiers):
        raise ValueError("Use Ctrl, Alt or Shift once. Ctrl+Alt is reserved for international keyboards.")
    base = _NAMED.get(parts[-1], parts[-1].upper())
    if not _KEY.fullmatch(base):
        raise ValueError("Use a letter, digit, F1–F12, / or a named navigation key.")
    chord = "+".join((*modifiers, base))
    if chord in _RESERVED or ("Alt" in modifiers and len(modifiers)==1 and base.isalpha() and len(base)==1):
        raise ValueError(f"{chord} is reserved for editing, menus or pane navigation.")
    if base == "Tab":
        raise ValueError("Tab is reserved for moving between controls and panes.")
    return chord


def validate_bindings(profile, overrides):
    if not isinstance(profile,str) or profile not in PROFILES or not isinstance(overrides,dict):
        raise ValueError("Unknown shortcut profile.")
    if len(overrides) > len(ACTIONS) or any(a not in ACTIONS for a in overrides):
        raise ValueError("Unknown shortcut action.")
    bindings = {**_DEFAULT, **PROFILES[profile], **{a:canonical_chord(c) for a,c in overrides.items()}}
    used = {}
    for action, chord in bindings.items():
        if not chord:
            continue
        if chord in used:
            raise ValueError(f"{chord} is assigned to both {ACTIONS[used[chord]]} and {ACTIONS[action]}.")
        used[chord] = action
    return bindings


def _event_chord(event):
    base = {"slash": "/", "question": "/", "Return": "Enter", "KP_Enter": "Enter"}.get(event.keysym, event.keysym)
    if event.state & 1 and 0x30 <= event.keycode <= 0x39:
        base = chr(event.keycode)
    if len(base) == 1:
        base = base.upper()
    if not _KEY.fullmatch(base):
        return ""
    modifiers = []
    for flag, name in ((0x4,"Ctrl"), (0x20008,"Alt"), (0x1,"Shift")):
        if event.state & flag:
            modifiers.append(name)
    return "+".join((*modifiers,base))


class WorkbenchControls:
    def __init__(self, root, settings, actions, on_change=None, *, note_editor=None):
        self.root, self.settings, self.actions = root, settings, actions
        self.on_change, self.note_editor = on_change, note_editor
        self.windows = set()
        self.tag = f"InsightKeys{id(self)}"
        self._apply(settings.load(), notify=False)
        root.bind_class(self.tag, "<KeyPress>", self._dispatch)
        root.bind_all("<Map>", lambda e:self._tag(e.widget), add="+")
        self.attach(root)

    def _apply(self, values, notify=True):
        self.bindings = validate_bindings(values["keymap"], values["shortcuts"].get(values["keymap"], {}))
        self.by_key = {c:a for a,c in self.bindings.items() if c}
        set_fonts(self.root, values["code_size"], values["ui_size"], values["code_font"])
        if notify and self.on_change:
            self.on_change()

    def accelerator(self, action):
        return self.bindings.get(action, "")

    def _tag(self, widget):
        if not isinstance(widget, tk.Misc) or widget.winfo_toplevel() not in self.windows:
            return
        tags = widget.bindtags()
        if self.tag not in tags:
            widget.bindtags((self.tag,*tags))

    def attach(self, window):
        self.windows.add(window)
        pending = [window]
        while pending:
            widget = pending.pop()
            self._tag(widget)
            pending.extend(widget.children.values())

    def detach(self, window):
        self.windows.discard(window)

    def _dispatch(self, event):
        widget = event.widget
        if (not isinstance(widget, tk.Misc) or widget.winfo_toplevel() not in self.windows
                or self.root.grab_current() is not None):
            return
        chord = _event_chord(event)
        action = self.by_key.get(chord)
        if not action or action not in self.actions:
            return
        editor = isinstance(widget, (tk.Entry, ttk.Entry, ttk.Combobox, tk.Spinbox, ttk.Spinbox))
        editor |= isinstance(widget, tk.Text) and widget.cget("state") == "normal"
        if editor and (widget is not self.note_editor or action != "save_note" or "+" not in chord):
            return
        if chord == "Escape" and widget.bind("<Escape>"):
            return  # A local dismiss action takes precedence over history.
        self.actions[action]()
        return "break"

    def show(self):
        values = self.settings.load()
        dialog = Prompt(self.root, "Keyboard and type")
        body = dialog.body
        body.columnconfigure(1, weight=1)
        chosen = tk.StringVar(dialog, value=values["keymap"])
        ttk.Label(body, text="Shortcut profile").grid(row=0, column=0, sticky="w", padx=(0,8))
        profiles = ttk.Combobox(body, state="readonly", textvariable=chosen, values=tuple(PROFILES))
        dialog.profile_choice = profiles
        profiles.grid(row=0, column=1, sticky="ew")
        description = ttk.Label(body, wraplength=420)
        description.grid(row=1, column=0, columnspan=2, sticky="w", pady=(3,5))
        rows = ttk.Treeview(body, columns=("action","chord"), show="headings", selectmode="browse",
                            style="Insight.Treeview", height=6)
        rows.heading("action",text="Action")
        rows.heading("chord",text="Shortcut")
        rows.column("action",width=200)
        rows.column("chord",width=135)
        rows.grid(row=2,column=0,columnspan=2,sticky="nsew")
        bar = ttk.Scrollbar(body, orient="vertical", command=rows.yview)
        bar.grid(row=2,column=2,sticky="ns")
        rows.configure(yscrollcommand=bar.set)
        edit = ttk.Frame(body)
        edit.grid(row=3,column=0,columnspan=2,sticky="ew",pady=(4,2))
        edit.columnconfigure(0,weight=1)
        entry = ttk.Entry(edit,font=MONO, width=16)
        dialog.shortcut_table, dialog.shortcut_entry = rows, entry
        entry.grid(row=0,column=0,sticky="ew")
        message = ttk.Label(body, foreground=AMBER, wraplength=410)
        message.grid(row=4,column=0,columnspan=2,sticky="w")
        overrides = {p:dict(mapping) for p,mapping in values["shortcuts"].items()}

        def selected(_event=None):
            selected_rows = rows.selection()
            if selected_rows:
                entry.delete(0,"end")
                entry.insert(0,rows.set(selected_rows[0],"chord"))

        def refresh(_event=None):
            profile = chosen.get()
            active = rows.focus() or "palette"
            bindings = validate_bindings(profile,overrides.get(profile,{}))
            rows.delete(*rows.get_children())
            for action,label in ACTIONS.items():
                rows.insert("","end",iid=action,values=(label,bindings[action]))
            rows.selection_set(active)
            rows.focus(active)
            rows.see(active)
            selected()
            description.configure(text=_DETAIL[profile] + (" Other actions retain Insight bindings." if profile != "Insight" else ""))
            message.configure(text="")

        def assign():
            action = rows.focus()
            if not action:
                return
            profile = chosen.get()
            candidate = dict(overrides.get(profile, {}))
            try:
                candidate[action] = canonical_chord(entry.get())
                validate_bindings(profile,candidate)
            except ValueError as error:
                message.configure(text=str(error))
                return False
            if candidate[action] == validate_bindings(profile,{})[action]:
                candidate.pop(action)
            if candidate:
                overrides[profile] = candidate
            else:
                overrides.pop(profile,None)
            refresh()
            return True

        def defaults():
            overrides.pop(chosen.get(), None)
            refresh()

        ttk.Button(edit,text="Assign",command=assign).grid(row=0,column=1,padx=3)
        ttk.Button(edit,text="Reset profile",command=defaults).grid(row=0,column=2)
        rows.bind("<<TreeviewSelect>>",selected)
        profiles.bind("<<ComboboxSelected>>",refresh)
        refresh()
        field = ttk.Frame(body)
        field.grid(row=5,column=0,columnspan=2,sticky="ew",pady=(5,0))
        fonts = available_code_fonts(self.root)
        ttk.Label(field,text="Technical typeface").grid(row=0,column=0,sticky="w")
        family = ttk.Combobox(field,state="readonly",width=16,values=("Automatic", *fonts))
        dialog.code_family = family
        family.set(values["code_font"])
        family.grid(row=1,column=0,sticky="w",padx=(0,6))
        sizes = []
        for i,(label,key) in enumerate((("Code (pt)","code_size"),("Interface (pt)","ui_size")),1):
            ttk.Label(field,text=label).grid(row=0,column=i,sticky="w")
            size = ttk.Spinbox(field, from_=8,to=24,width=5)
            size.set(values[key])
            size.grid(row=1,column=i,sticky="w",padx=(0,6))
            sizes.append(size)
        dialog.code_size, dialog.ui_size = sizes

        def accept():
            if entry.get() != rows.set(rows.focus(),"chord") and not assign():
                return
            try:
                if not all(re.fullmatch(r"[0-9]{1,2}",s.get()) for s in sizes):
                    raise ValueError("Enter whole-number font sizes from 8 to 24 points.")
                saved = self.settings.update(keymap=chosen.get(),shortcuts=overrides,code_font=family.get(),
                                             code_size=int(sizes[0].get()), ui_size=int(sizes[1].get()))
            except ValueError as error:
                message.configure(text=str(error))
                return
            dialog.finish(saved)

        result = dialog.show(accept, "Apply settings", profiles)
        if result:
            self._apply(result)
