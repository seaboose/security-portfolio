"""Inspect file-backed strings, import slots and the bytes underlying their heatmap."""

import tkinter as tk
from tkinter import ttk

from .appearance import CANVAS, INK, MONO, MUTED, scrollable
from .workspace_evidence import entropy_windows


class TriageOverview(ttk.Frame):
    PAGE = 60

    def __init__(self, parent, follow):
        super().__init__(parent, padding=5)
        self.follow, self.case = follow, None
        self.entries, self.matches = (), []
        self.mode = tk.StringVar(self, "Strings")
        self.query = tk.StringVar(self)
        self.coverage = ""
        self.columnconfigure(0, weight=1)
        self.rowconfigure(1, weight=1)
        bar = ttk.Frame(self)
        bar.grid(row=0, column=0, sticky="ew")
        for mode in ("Strings", "Imports"):
            ttk.Radiobutton(bar, text=mode, variable=self.mode, value=mode,
                            style="Insight.Switch.TRadiobutton", command=self.filter).pack(side="left")
        ttk.Label(bar, text="Find").pack(side="left", padx=(8, 3))
        ttk.Entry(bar, textvariable=self.query, width=10).pack(side="left", fill="x", expand=True)
        box = ttk.Frame(self)
        box.grid(row=1, column=0, sticky="nsew")
        self.table = ttk.Treeview(box, columns=("at","value","kind"), show="headings",
                                  selectmode="browse", height=5, style="Insight.Treeview")
        for key, title, width in (("at","RVA",90), ("value","Text or import",220), ("kind","Encoding",125)):
            self.table.heading(key, text=title, anchor="w")
            self.table.column(key, width=width, minwidth=60, stretch=(key=="value"))
        scrollable(box, self.table)
        self.table.bind("<<TreeviewSelect>>", lambda _:self.preview())
        self.table.bind("<Return>", lambda _:self.open())
        self.table.bind("<Double-Button-1>", lambda e:self.open() if self.table.identify_row(e.y) else None)
        row = ttk.Frame(self)
        row.grid(row=2, column=0, sticky="ew")
        self.count = ttk.Label(row, foreground=MUTED)
        self.count.pack(side="left", fill="x", expand=True)
        self.prev = ttk.Button(row, text="Previous", command=lambda:self.page(self.number-1))
        self.next = ttk.Button(row, text="Next", command=lambda:self.page(self.number+1))
        self.prev.pack(side="left")
        self.next.pack(side="left")
        self.refs = ttk.Button(row, text="References…", command=self.open)
        self.refs.pack(side="right")
        self.caption = ttk.Label(self, font=MONO)
        self.caption.grid(row=3, column=0, sticky="ew", pady=(3,0))
        self.caption.bind("<Configure>", lambda e:self.caption.configure(wraplength=max(48,e.width-4)))
        self.hex = tk.Text(self, height=4, width=20, wrap="none", state="disabled", font=MONO,
                           background=CANVAS, foreground=INK, borderwidth=0, padx=4)
        self.hex.grid(row=4, column=0, sticky="ew")
        for i, color in enumerate(("#262122", "#422c25", "#673c28", "#935329")):
            self.hex.tag_configure(str(i), background=color)
        self.hex.tag_configure("zero", background="#222022")
        self.source = ttk.Label(self, foreground=MUTED)
        self.source.grid(row=5, column=0, sticky="ew")
        self.source.bind("<Configure>", lambda e:self.source.configure(wraplength=max(100,e.width-4)))
        self.query.trace_add("write", lambda *_:self.filter())
        self.clear(None)

    def clear(self, case):
        self.case = case
        self.strings, self.imports = (), ()
        self.coverage = "Indexing file-backed bytes…" if case and case.image else "Open an x64 DLL to inspect strings and imports."
        self.filter()

    def load(self, case, strings, imports, coverage):
        if self.case is case:
            self.strings, self.imports, self.coverage = strings, imports, coverage
            self.filter()

    def filter(self):
        strings = self.mode.get() == "Strings"
        self.table.heading("kind", text="Encoding" if strings else "Module")
        self.table.heading("value", text="String" if strings else "Import name")
        self.entries = self.strings if strings else self.imports
        query = self.query.get().strip().casefold()
        if query:
            self.matches = [i for i,item in enumerate(self.entries) if query in
                            (item.text if strings else f"{item.module}!{item.name}").casefold()]
        else:
            self.matches = range(len(self.entries))
        self.source.configure(text=self.coverage)
        self.page(0)

    def page(self, n):
        self.number = max(0, min(n, (len(self.matches)-1)//self.PAGE))
        at = self.number*self.PAGE
        self.table.delete(*self.table.get_children())
        strings = self.mode.get() == "Strings"
        for i in self.matches[at:at+self.PAGE]:
            entry = self.entries[i]
            values = ((hex(entry.rva), entry.text[:150], entry.encoding) if strings else
                      (hex(entry.iat_rva), entry.name[:130], entry.module))
            self.table.insert("", "end", iid=str(i), values=values)
        rows = self.table.get_children()
        if rows:
            self.table.selection_set(rows[0])
            self.table.focus(rows[0])
        self.prev.state(["!disabled" if at else "disabled"])
        self.next.state(["!disabled" if at+self.PAGE<len(self.matches) else "disabled"])
        self.count.configure(text=f"{at+1}–{at+len(rows)} of {len(self.matches)}" if rows else "No matches")
        self.preview()

    def selected(self):
        selected = self.table.selection()
        return self.entries[int(selected[0])] if selected else None

    def preview(self):
        entry = self.selected()
        self.refs.state(["!disabled" if entry else "disabled"])
        self.hex.configure(state="normal")
        self.hex.delete("1.0","end")
        self.caption.configure(text="")
        if entry and self.case and self.case.image:
            image = self.case.image
            at, size = (entry.rva,entry.size) if self.mode.get()=="Strings" else (entry.iat_rva,8)
            start = image.offset(at, size)
            raw = image.data[start:start+min(size,32)]
            samples = entropy_windows(image, at, at+len(raw))
            score, length = samples.get(at, (0,0))
            detail = f"H {score:.2f} in {length} B" if length else "No section sample"
            self.caption.configure(text=f"File RVA 0x{at:X} · {size} B · {detail}")
            for i,b in enumerate(raw):
                if i%8 == 0:
                    self.hex.insert("end", ("\n" if i else "")+f"{at+i:08X}  ")
                strength = samples.get(at+i)
                tag = str(min(3,int(strength[0]/1.5))) if strength else ""
                if b == 0:
                    tag = "zero"
                self.hex.insert("end", f"{b:02X} ", tag)
        self.hex.configure(state="disabled")

    def open(self):
        if (entry := self.selected()) is not None:
            self.follow(self.case, self.mode.get(), entry)
        return "break"
