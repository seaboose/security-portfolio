// Decompile one function in an ephemeral program and export Ghidra's direct source associations.
//@category Insight
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HexFormat;
import java.util.Set;
import java.util.TreeSet;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import ghidra.app.cmd.disassemble.DisassembleCommand;
import ghidra.app.decompiler.*;
import ghidra.app.script.GhidraScript;
import ghidra.framework.Application;
import ghidra.program.model.address.*;
import ghidra.program.model.listing.*;
import ghidra.program.model.pcode.PcodeOp;
import ghidra.program.model.pcode.HighFunction;
import ghidra.program.model.pcode.HighGlobal;
import ghidra.program.model.pcode.HighSymbol;
import ghidra.program.model.pcode.HighFunctionDBUtil;
import ghidra.program.model.pcode.Varnode;
import ghidra.program.model.symbol.RefType;
import ghidra.program.util.ContextEvaluatorAdapter;
import ghidra.program.util.SymbolicPropogator;

public class InsightDecompile extends GhidraScript {
    private static final Set<String> FRAME_BASES =
        Set.of("RSP", "RBP", "RBX", "RSI", "RDI", "R12", "R13", "R14", "R15");

    private static JsonObject stackStorage(HighSymbol symbol) {
        if (symbol == null || symbol.isGlobal()) {
            return null;
        }
        // A symbol with no mapping has no public storage in Ghidra 12.2.
        // getStorage() indexes the first mapping even when its array is null.
        VariableStorage storage;
        try {
            storage = symbol.getStorage();
        } catch (NullPointerException | IndexOutOfBoundsException unmapped) {
            return null;
        }
        if (storage == null || !storage.isStackStorage()) {
            return null;
        }
        JsonObject item = new JsonObject();
        item.addProperty("offset", storage.getStackOffset());
        item.addProperty("size", storage.size());
        return item;
    }

    // Trace a single machine instruction's address expression back to its incoming
    // frame register. Other arithmetic, partial register writes and unknown depths
    // have no proven stack offset. High p-code alone would optimize away AND [mem],0.
    private Long stackOffset(Instruction instruction, PcodeOp[] ops, int before,
            Varnode value, SymbolicPropogator depth, int remaining) {
        if (remaining == 0 || value.getSize() != 8) {
            return null;
        }
        for (int i = before - 1; i >= 0; --i) {
            PcodeOp def = ops[i];
            Varnode out = def.getOutput();
            if (out == null || !value.intersects(out)) {
                continue;
            }
            if (!out.equals(value)) {
                return null;
            }
            int op = def.getOpcode();
            if (op == PcodeOp.COPY) {
                return stackOffset(instruction, ops, i, def.getInput(0), depth, remaining - 1);
            }
            if ((op == PcodeOp.INT_ADD || op == PcodeOp.INT_SUB) && def.getInput(1).isConstant()) {
                Long base = stackOffset(instruction, ops, i, def.getInput(0), depth, remaining - 1);
                long delta = def.getInput(1).getOffset();
                return base == null ? null : base + (op == PcodeOp.INT_ADD ? delta : -delta);
            }
            return null;
        }
        if (!value.isRegister()) {
            return null;
        }
        var reg = currentProgram.getRegister(value.getAddress(), value.getSize());
        // A call without a prototype may leave a stale volatile-register value
        // in symbolic propagation. Use only Win64 callee-preserved frame bases.
        if (reg == null || !FRAME_BASES.contains(reg.getName())) {
            return null;
        }
        var incoming = depth.getRegisterValue(instruction.getAddress(), reg);
        return incoming != null && currentProgram.getCompilerSpec().getStackPointer().equals(
            incoming.getRelativeRegister()) ? incoming.getValue() : null;
    }

    private static void access(JsonArray sites, Instruction instruction, Address base,
            JsonObject instructions, String kind, long offset, int size) throws Exception {
        if (offset < Integer.MIN_VALUE || offset > Integer.MAX_VALUE) {
            return;
        }
        JsonObject item = new JsonObject();
        long rva = instruction.getAddress().subtract(base);
        item.addProperty("rva", rva);
        item.addProperty("kind", kind);
        item.addProperty("offset", offset);
        item.addProperty("size", size);
        if (sites.size() >= 32768) {
            throw new IllegalArgumentException("Stack reference count exceeds the display limit.");
        }
        sites.add(item);
        instructions.addProperty(Long.toString(rva), HexFormat.of().formatHex(instruction.getBytes()));
    }

    private void stackAccesses(JsonArray sites, JsonObject instructions, Function function,
            HighFunction high, AddressSet range, Address base) throws Exception {
        var depth = new SymbolicPropogator(currentProgram, true);
        depth.setParamRefCheck(false);
        depth.setReturnRefCheck(false);
        depth.setStoredRefCheck(false);
        depth.setRegister(function.getEntryPoint(), currentProgram.getCompilerSpec().getStackPointer());
        AddressSet body = depth.flowConstants(function.getEntryPoint(), range,
            new ContextEvaluatorAdapter(), true, monitor);
        for (Instruction ix : currentProgram.getListing().getInstructions(body, true)) {
            monitor.checkCancelled();
            PcodeOp[] ops = ix.getPcode();
            for (int i = 0; i < ops.length; ++i) {
                PcodeOp op = ops[i];
                int code = op.getOpcode();
                if (code == PcodeOp.CBRANCH || code == PcodeOp.BRANCH || code == PcodeOp.BRANCHIND) {
                    break;  // Subsequent operations can depend on an internal branch.
                }
                if ((code == PcodeOp.LOAD || code == PcodeOp.STORE) &&
                    op.getInput(0).getOffset() == base.getAddressSpace().getSpaceID()) {
                    Long at = stackOffset(ix, ops, i, op.getInput(1), depth, 8);
                    if (at != null) {
                        boolean read = code == PcodeOp.LOAD;
                        access(sites, ix, base, instructions, read ? "Read" : "Write", at,
                            read ? op.getOutput().getSize() : op.getInput(2).getSize());
                    }
                }
                if (ix.getMnemonicString().equals("LEA") && op.getOutput() != null &&
                        op.getOutput().isRegister()) {
                    Long at = stackOffset(ix, ops, i + 1, op.getOutput(), depth, 8);
                    if (at != null) {
                        access(sites, ix, base, instructions, "Address", at, 0);
                    }
                }
            }
        }
        // Only export a first-argument pointer proven by the decompiler's expression.
        // The host verifies the IAT target and its output contract from snapshot bytes.
        var iter = high.getPcodeOps();
        while (iter.hasNext()) {
            PcodeOp op = iter.next();
            if ((op.getOpcode() == PcodeOp.CALL || op.getOpcode() == PcodeOp.CALLIND) &&
                op.getNumInputs() > 1 && body.contains(op.getSeqnum().getTarget())) {
                PcodeOp pointer = op.getInput(1).getDef();
                if (pointer == null || pointer.getOpcode() != PcodeOp.PTRSUB ||
                    !pointer.getInput(1).isConstant() || !pointer.getInput(0).isInput() ||
                    !currentProgram.getCompilerSpec().getStackPointer().getAddress().equals(
                        pointer.getInput(0).getAddress())) {
                    continue;
                }
                Address arg = HighFunctionDBUtil.getSpacebaseReferenceAddress(
                    currentProgram.getAddressFactory(), pointer);
                if (arg != null && arg.isStackAddress()) {
                    Instruction ix = getInstructionAt(op.getSeqnum().getTarget());
                    if (ix != null && ix.getFlowType().isCall()) {
                        access(sites, ix, base, instructions, "Argument 1", arg.getOffset(), 0);
                    }
                }
            }
        }
    }

    private static void addGlobal(JsonArray globals, ClangToken token, HighFunction function,
            Address base, int start, int end) {
        if (!(token instanceof ClangVariableToken) || start == end) {
            return;
        }
        HighSymbol symbol = token.getHighSymbol(function);
        if (symbol == null || !symbol.isGlobal() || !symbol.getStorage().isMemoryStorage()) {
            return;
        }
        Varnode storage = symbol.getStorage().getFirstVarnode();
        Address address = storage.getAddress();
        if (!address.getAddressSpace().equals(base.getAddressSpace())) {
            return;
        }
        long rva = address.subtract(base);
        int size = storage.getSize();
        // An undefined database symbol can occupy one byte even when Ghidra recovered a wider global.
        if (token.getHighVariable() instanceof HighGlobal global && global.getRepresentative() != null &&
            address.equals(global.getRepresentative().getAddress())) {
            size = Math.max(size, global.getRepresentative().getSize());
        }
        if (rva < 0 || rva + size > 0x100000000L) {
            return;
        }
        JsonObject span = new JsonObject();
        span.addProperty("start", start);
        span.addProperty("end", end);
        span.addProperty("rva", rva);
        span.addProperty("size", size);
        globals.add(span);
    }

    private static void addOp(Set<Address> addresses, PcodeOp op) {
        if (op != null && op.getOpcode() != PcodeOp.MULTIEQUAL && op.getOpcode() != PcodeOp.INDIRECT) {
            addresses.add(op.getSeqnum().getTarget());
        }
    }

    private void addFunction(JsonArray spans, ClangToken token, Function function,
            Address base, int start, int end) {
        if (!(token instanceof ClangFuncNameToken) || start >= end) {
            return;
        }
        PcodeOp op = token.getPcodeOp();
        Address target;
        JsonObject span = new JsonObject();
        if (token.Parent() instanceof ClangFuncProto proto && op == null &&
                proto.getClangFunction().getHighFunction().getFunction().equals(function)) {
            target = function.getEntryPoint();
            span.addProperty("kind", "definition");
        } else if (token.Parent() instanceof ClangStatement && op != null &&
                op.getOpcode() == PcodeOp.CALL && op.getNumInputs() > 0) {
            Address site = op.getSeqnum().getTarget();
            Instruction ix = getInstructionAt(site);
            target = op.getInput(0).getAddress();
            if (!site.getAddressSpace().equals(base.getAddressSpace()) || ix == null ||
                    !ix.getFlowType().isCall() || ix.getFlowType().isComputed() ||
                    ix.getFlows().length != 1 || !ix.getFlows()[0].equals(target)) {
                return;
            }
            span.addProperty("kind", "call");
            span.addProperty("site", site.subtract(base));
        } else {
            return;
        }
        if (!target.getAddressSpace().equals(base.getAddressSpace())) {
            return;
        }
        long rva = target.subtract(base);
        if (rva < 0 || rva > 0xffffffffL) {
            return;
        }
        span.addProperty("start", start);
        span.addProperty("end", end);
        span.addProperty("rva", rva);
        spans.add(span);
    }

    @Override
    public void run() throws Exception {
        String[] args = getScriptArgs();
        long start = Long.parseUnsignedLong(args[0], 16);
        long end = Long.parseUnsignedLong(args[1], 16);
        Address base = currentProgram.getImageBase();
        Address entry = base.addNoWrap(start);
        AddressSet range = new AddressSet(entry, base.addNoWrap(end - 1));
        DisassembleCommand dis = new DisassembleCommand(entry, range, true);
        dis.enableCodeAnalysis(false);
        dis.applyTo(currentProgram, monitor);
        if (!args[3].equals("none")) {
            Address target = base.addNoWrap(Long.parseUnsignedLong(args[3], 16));
            Instruction tail = getInstructionContaining(range.getMaxAddress());
            if (tail != null && tail.getMaxAddress().equals(range.getMaxAddress()) &&
                tail.getFlowType() == RefType.UNCONDITIONAL_JUMP && tail.getFlows().length == 1 &&
                target.equals(tail.getFlows()[0])) {
                tail.setFlowOverride(FlowOverride.CALL_RETURN);
            }
        }
        Function function = getFunctionAt(entry);
        if (function == null) {
            function = createFunction(entry, null);
        }
        if (function == null || getInstructionAt(entry) == null) {
            throw new IllegalArgumentException("Ghidra could not establish a function at this RVA.");
        }

        DecompInterface decompiler = new DecompInterface();
        try {
            decompiler.setOptions(new DecompileOptions());
            if (!decompiler.openProgram(currentProgram)) {
                throw new IllegalStateException("Could not open the Ghidra decompiler.");
            }
            DecompileResults result = decompiler.decompileFunction(function, 35, monitor);
            if (!result.decompileCompleted() || result.getCCodeMarkup() == null) {
                throw new IllegalStateException("Ghidra produced no pseudocode for this routine.");
            }
            PrettyPrinter printer = new PrettyPrinter(function, result.getCCodeMarkup(), null);
            JsonArray lines = new JsonArray();
            JsonObject instructions = new JsonObject();
            instructions.addProperty(Long.toString(start), HexFormat.of().formatHex(getInstructionAt(entry).getBytes()));
            for (ClangLine line : printer.getLines()) {
                monitor.checkCancelled();
                String text = PrettyPrinter.getText(line);
                if (lines.size() >= 8192 || text.length() > 32768) {
                    throw new IllegalArgumentException("Decompiler text exceeds the display limit.");
                }
                Set<Address> addresses = new TreeSet<>();
                JsonArray globals = new JsonArray();
                JsonArray stack = new JsonArray();
                JsonArray functions = new JsonArray();
                int column = line.getIndent();
                for (ClangToken token : line.getAllTokens()) {
                    String spelling = token.getText();
                    int next = column + spelling.codePointCount(0, spelling.length());
                    addGlobal(globals, token, result.getHighFunction(), base, column, next);
                    addFunction(functions, token, function, base, column, next);
                    if (token instanceof ClangVariableToken && next > column) {
                        JsonObject span = stackStorage(token.getHighSymbol(result.getHighFunction()));
                        if (span != null) {
                            span.addProperty("start", column);
                            span.addProperty("end", next);
                            stack.add(span);
                        }
                    }
                    column = next;
                    addOp(addresses, token.getPcodeOp());
                    // A label definition identifies its first instruction. A goto operand names a destination.
                    if (token instanceof ClangLabelToken && text.stripTrailing().endsWith(":") &&
                        token.getMinAddress() != null && token.getMinAddress().equals(token.getMaxAddress())) {
                        addresses.add(token.getMinAddress());
                    }
                    // Statements carry the root operation, e.g. CBRANCH. Anchor it to the
                    // first token of the statement only, so wrapped lines do not inherit it.
                    ClangNode node = token;
                    while (node.Parent() != null && node.Parent().Child(0) == node) {
                        node = node.Parent();
                        if (node instanceof ClangStatement statement) {
                            addOp(addresses, statement.getPcodeOp());
                            break;
                        }
                    }
                }
                JsonArray locations = new JsonArray();
                for (Address address : addresses) {
                    if (!address.getAddressSpace().equals(base.getAddressSpace()) || !address.isMemoryAddress()) {
                        continue;
                    }
                    long rva = address.subtract(base);
                    if (rva < 0 || rva > 0xffffffffL) {
                        continue;
                    }
                    locations.add(rva);
                    Instruction instruction = getInstructionAt(address);
                    if (instruction != null) {
                        instructions.addProperty(Long.toString(rva), HexFormat.of().formatHex(instruction.getBytes()));
                    }
                }
                JsonObject record = new JsonObject();
                record.addProperty("text", text);
                record.add("rvas", locations);
                record.add("globals", globals);
                record.add("stack", stack);
                record.add("functions", functions);
                lines.add(record);
            }
            JsonObject document = new JsonObject();
            JsonArray slots = new JsonArray();
            var symbols = result.getHighFunction().getLocalSymbolMap().getSymbols();
            while (symbols.hasNext()) {
                HighSymbol symbol = symbols.next();
                JsonObject slot = stackStorage(symbol);
                if (slot != null) {
                    slot.addProperty("name", symbol.getName());
                    slots.add(slot);
                }
            }
            JsonArray accesses = new JsonArray();
            if (!slots.isEmpty()) {
                stackAccesses(accesses, instructions, function, result.getHighFunction(), range, base);
            }
            document.add("stack", slots);
            document.add("accesses", accesses);
            document.addProperty("version", Application.getApplicationVersion());
            document.addProperty("digest", currentProgram.getExecutableSHA256());
            document.addProperty("entry", function.getEntryPoint().subtract(base));
            document.add("instructions", instructions);
            document.add("lines", lines);
            try (Writer writer = Files.newBufferedWriter(Path.of(args[2]))) {
                new Gson().toJson(document, writer);
            }
        } finally {
            decompiler.dispose();
        }
    }
}
