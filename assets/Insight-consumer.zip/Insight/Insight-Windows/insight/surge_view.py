"""Select a Surge observation and DLL, inspect their independent byte evidence, and cite a draft."""

from pathlib import Path
import tkinter as tk
from tkinter import filedialog, ttk

from . import dialogs
from .appearance import MONO, MUTED, SURFACE
from .surge_exchange import attach_observation, bind_observation, read_observations, verify_observation


def _bytes(raw):
    return bytes.fromhex(raw).hex(" ").upper()


class SurgeView(tk.Toplevel):
    def __init__(self, app):
        super().__init__(app.root, background=SURFACE)
        self.app = app
        self.title("Surge observation — Insight")
        self.records, self.bound, self.work = (), None, None
        self.anchor = None
        body = ttk.Frame(self, padding=12)
        body.pack(fill="both",expand=True)
        body.columnconfigure(0,weight=1)
        ttk.Button(body,text="Choose observation…",command=self.choose).grid(row=0,column=0,sticky="w")
        self.choice = ttk.Combobox(body,state="readonly",width=48)
        self.choice.grid(row=1,column=0,sticky="ew",pady=6)
        self.choice.bind("<<ComboboxSelected>>",self._selection)
        self.summary = ttk.Label(body,wraplength=470,foreground=MUTED)
        self.summary.grid(row=2,column=0,sticky="ew")
        self.file = ttk.Label(body,font=MONO,wraplength=470)
        self.capture = ttk.Label(body,font=MONO,wraplength=470)
        self.file.grid(row=3,column=0,sticky="ew",pady=(8,2))
        self.capture.grid(row=4,column=0,sticky="ew",pady=(2,8))
        line = ttk.Frame(body)
        line.grid(row=5,column=0,sticky="ew")
        self.bind_dll = ttk.Button(line,text="Verify DLL…",command=self.pick_dll)
        self.open_case = ttk.Button(line,text="Open verified case",command=self.activate)
        self.attach = ttk.Button(line,text="Cite in saved draft",command=self.cite)
        for button in (self.bind_dll,self.open_case,self.attach):
            button.pack(side="left",padx=(0,4))
        self.status = ttk.Label(body,wraplength=470)
        self.status.grid(row=6,column=0,sticky="ew",pady=(7,0))
        self.protocol("WM_DELETE_WINDOW",self.close)
        self.bind("<Escape>",lambda _:self.close())
        self.bind("<Configure>",lambda e:self._wrap(e) if e.widget is self else None)
        self._selection()

    def _wrap(self,event):
        for label in (self.summary,self.file,self.capture,self.status):
            label.configure(wraplength=max(170,event.width-30))

    def record(self):
        index = self.choice.current()
        return self.records[index] if 0 <= index < len(self.records) else None

    def _selection(self,_=None):
        if self.work is not None and self.app.pending is self.work:
            self.app.cancel_work(announce=False)
        self.work, self.bound, self.anchor = None,None,None
        row = self.record()
        self.bind_dll.state(["!disabled" if row else "disabled"])
        self.open_case.state(["disabled"])
        self.attach.state(["disabled"])
        self.file.configure(text="Selected DLL bytes · awaiting verification" if row else "")
        self.capture.configure(text="")
        self.summary.configure(text="")
        self.status.configure(text="Choose a Surge native observation or capture." if not row else "")
        if row:
            self.summary.configure(text=f"{row['captured_at']} · PID {row['pid']} · session {row['session_id']}\n"
                                   f"Module SHA-256 {row['module_sha256']}")
            memory = _bytes(row["observed_hex"]) if row["observed_hex"] else " ".join(["??"]*row["size"])
            self.capture.configure(text=f"Surge memory · {row['memory_status']} · "
                                   f"{row['read_mask'].count('1')}/{row['size']} bytes read\n{memory}")

    def choose(self):
        def browse(dialog,_value):
            return filedialog.askopenfilename(parent=dialog,title="Open Surge observation",
                        filetypes=[("Surge observations","*.json *.jsonl"),("All files","*.*")])
        path = dialogs.input_value(self,"Open Surge observation","Surge JSON or JSONL file","Read observations",
                                   browse=browse)
        if path:
            self.read_file(path)

    def read_file(self,path):
        self.records = ()
        self.choice["values"] = ()
        self.choice.set("")
        self._selection()
        def display(rows):
            self.work = None
            self.records = rows
            self.choice["values"] = [f"{r['phase']} · {r['range_name']} · 0x{r['rva']:X} · {r['memory_status']}"
                                     for r in rows]
            self.choice.current(0)
            self._selection()
        self._work("Reading Surge observation…",lambda stop:read_observations(Path(path),stop),display)

    def pick_dll(self):
        path = dialogs.choose_file(self)
        if path:
            self.verify(path)

    def _work(self,title,task,done):
        self.app.busy(title,task,done,failed=lambda error:self.status.configure(text=error),
                      cancelled=lambda:self.status.configure(text="Cancelled. Current investigation retained."))
        self.work = self.app.pending

    def verify(self,path):
        row = self.record()
        if not row:
            return
        self._selection()
        def inspect(stop):
            case = bind_observation(path,row,stop)
            owners = [r for r in case.routines if r.rva <= row["rva"] < r.end]
            anchor = None
            if len(owners) == 1:
                for inst in case.instructions(owners[0],stop):
                    if inst.rva == row["rva"] and inst.flow != "invalid":
                        anchor = case.key(owners[0]),inst.rva,inst.raw
                        break
            return case, anchor
        def ready(result):
            self.work = None
            if self.record() is not row:
                return
            case, self.anchor = result
            raw = verify_observation(case,row)
            self.bound = case
            self.file.configure(text=f"Selected DLL · RVA 0x{row['rva']:X} · {len(raw)} bytes\n{raw.hex(' ').upper()}")
            memory = bytes.fromhex(row["observed_hex"])
            self.status.configure(text=(f"{sum(x!=y for x,y in zip(raw,memory))} differing captured bytes."
                                       if memory else "No captured bytes corroborate this range."))
            self.open_case.state(["!disabled"])
        self._work("Checking DLL fingerprint and reference range…",inspect,ready)

    def activate(self):
        case, row, anchor = self.bound, self.record(), self.anchor
        if case is None or row is None:
            return
        def opened(active):
            if not self.winfo_exists() or active is not self.app.case or active.digest != case.digest:
                return
            self.attach.state(["!disabled"])
            self.status.configure(text=("Save a draft pinned inside this range, then choose Cite in saved draft."
                                   if anchor else "No verified instruction starts at the range origin. "
                                   "The file and capture bytes remain available here."))
        if self.app.case and self.app.case.digest == case.digest:
            opened(self.app.case)
            if anchor:
                self.app.open_citation(*anchor)
        else:
            self.app.load_case(lambda:case,after=opened,selected=anchor)

    def cite(self):
        app, row = self.app, self.record()
        notes = app.notes
        try:
            if self.bound is None or row is None or app.case is None or app.case.digest != self.bound.digest:
                raise ValueError("Open this verified observation’s DLL first.")
            if not notes.note or notes.dirty():
                raise ValueError("Save the draft pinned to an instruction in this range first.")
            attach_observation(app.store,app.case,notes.note["id"],notes.active+1,row)
            self.status.configure(text=f"Surge observation cited in revision {notes.active+1}.")
        except ValueError as error:
            self.status.configure(text=str(error))

    def close(self):
        if self.work is not None and self.work is self.app.pending:
            self.app.cancel_work(announce=False)
        self.app.surge_window = None
        self.destroy()


def open_observation(app):
    current = getattr(app,"surge_window",None)
    if current is not None and current.winfo_exists():
        current.lift()
        return current
    app.surge_window = SurgeView(app)
    return app.surge_window
