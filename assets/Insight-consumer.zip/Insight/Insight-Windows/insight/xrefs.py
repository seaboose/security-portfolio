"""Index import calls and verified direct data accesses in a read-only PE snapshot."""

from bisect import bisect_right
from dataclasses import dataclass
from struct import unpack_from
from time import monotonic

from .call_tree import CallSite, CallTree, ImportSymbol, direct_target, distinct_instruction, validated_calls
from .data_access import direct_access
from .ghidra import NON_INSTRUCTIONS
from .pe import MAX_ENTRIES, MAX_ROUTINE_BYTES, Routine, disassemble

MAX_VISITED = 1_000_000
MAX_SECONDS = 120
MAX_LABEL_BYTES = 4 * 1024 * 1024
MAX_CALLS = 32_768
MAX_TREE_SITES = 32_768
MAX_DATA_SITES = 32_768


@dataclass(frozen=True)
class DataSite:
    routine: Routine
    rva: int
    raw: bytes
    target_rva: int
    width: int
    kind: str
    assembly: str


@dataclass(frozen=True)
class CallIndex:
    imports: tuple[ImportSymbol, ...]
    calls: tuple[CallSite, ...]
    coverage: str
    partial: bool = False
    data: tuple[DataSite, ...] = ()
    call_tree: CallTree | None = None


def _check_cancel(cancel):
    if cancel is not None and cancel.is_set():
        raise ValueError("XREF indexing cancelled.")


def _name(image, rva):
    if rva <= 0:
        raise ValueError("Missing PE import name.")
    start = image.offset(rva, 1)
    section = image.section_at(rva)
    stop = section.offset + section.backed if section else image.header_size
    end = image.data.find(b"\0", start, min(stop, start + 4097))
    if end <= start or not all(32 <= b < 127 for b in image.data[start:end]):
        raise ValueError("Malformed or oversized PE import name.")
    return image.data[start:end].decode("ascii")


def read_imports(image, cancel=None):
    slots = {}
    unavailable = 0
    entries = 0
    label_bytes = 0
    for delayed, (rva, size) in enumerate(image.imports):
        if not rva and not size:
            continue
        width = 32 if delayed else 20
        if not rva or size < width or size // width > MAX_ENTRIES:
            raise ValueError("Invalid PE import descriptor table.")
        start = image.offset(rva, size)
        for at in range(start, start + size - width + 1, width):
            _check_cancel(cancel)
            fields = unpack_from("<8I" if delayed else "<5I", image.data, at)
            if not any(fields):
                break
            if delayed:
                attrs, library, _, iat, lookup, _, _, _ = fields
                if attrs not in (0, 1):
                    raise ValueError("Invalid PE delay-import attributes.")
                if attrs == 0:
                    library, iat, lookup = (v - image.base for v in (library, iat, lookup))
            else:
                lookup, timestamp, _, library, iat = fields
                if not lookup and timestamp:
                    # A bound IAT contains resolved addresses; the import names were discarded.
                    unavailable += 1
                    continue
                lookup = lookup or iat
            module = _name(image, library)
            label_bytes += len(module)
            if label_bytes > MAX_LABEL_BYTES:
                raise ValueError("PE import names exceed the display limit.")
            if min(iat, lookup) <= 0:
                raise ValueError("Missing PE import lookup or address table.")
            for index in range(MAX_ENTRIES + 1):
                if index % 256 == 0:
                    _check_cancel(cancel)
                pointer, = unpack_from("<Q", image.data, image.offset(lookup + 8 * index, 8))
                if not pointer:
                    break
                entries += 1
                if entries > MAX_ENTRIES:
                    raise ValueError("PE import count exceeds the supported limit.")
                slot = iat + 8 * index
                image.offset(slot, 8)
                if pointer >> 63:
                    if pointer & 0x7fffffffffff0000:
                        raise ValueError("Invalid PE import ordinal.")
                    name = f"#{pointer & 0xffff}"
                else:
                    image.offset(pointer, 2)
                    name = _name(image, pointer + 2)
                label_bytes += len(module) + len(name)
                if label_bytes > MAX_LABEL_BYTES:
                    raise ValueError("PE import names exceed the display limit.")
                symbol = ImportSymbol(module, name, slot)
                if slot in slots and slots[slot] != symbol:
                    raise ValueError("Conflicting imports claim the same address slot.")
                slots[slot] = symbol
        else:
            raise ValueError("PE import descriptors have no terminating entry.")
    return slots, unavailable


class _Code:
    """Decode small batches, accepting starts only from PE roots or actual control flow."""

    def __init__(self, image, cancel):
        self.image, self.cancel = image, cancel
        self.cache = {}

    def get(self, at):
        if at in self.cache:
            return self.cache[at]
        section = self.image.section_at(at)
        if not section or not section.executable:
            return None
        end = section.rva + section.backed
        length = min(4096, end - at)
        start = self.image.offset(at, length)
        rows = disassemble(self.image.data[start:start + length], at, self.cancel)
        if len(self.cache) > 65536:
            self.cache.clear()
        # A cropped x86 instruction at the chunk edge must be re-decoded with its remaining bytes.
        safe_end = end if at + length == end else at + length - 14
        self.cache.update((row.rva, row) for row in rows if row.rva < safe_end)
        return self.cache[at]


def _iat_slot(row, modrm):
    # FF /2 and /4 with mod=00,r/m=101 address [RIP + disp32]. Address-size and FS/GS
    # overrides change that interpretation. Do not use the disassembler's displayed address alone.
    raw = row.raw
    if len(raw) < 6 or raw[-6:-4] != bytes((0xff, modrm)):
        return None
    if any(b not in (0x2e, 0x3e, 0x26, 0x36, 0xf2, 0xf3) and not 0x40 <= b <= 0x4f
           for b in raw[:-6]):
        return None
    return row.rva + len(raw) + int.from_bytes(raw[-4:], "little", signed=True)


def _thunk_symbol(code, target, slots):
    # Ignore landing pads but never walk a function body to infer its caller's target.
    for _ in range(8):
        row = code.get(target)
        if row is None:
            break
        if row.flow == "indirect":
            return slots.get(_iat_slot(row, 0x25))
        if row.flow == "jump" and row.target is not None:
            target = row.target
        elif row.op in ("endbr64", "nop") or row.raw == b"\xf3\x0f\x1e\xfa":
            target += len(row.raw)
        else:
            break
    return None


def build_index(image, cancel=None):
    _check_cancel(cancel)
    slots, unavailable = read_imports(image, cancel)
    imports = tuple(sorted(slots.values(), key=lambda s: (s.module.casefold(), s.name.casefold(), s.iat_rva)))
    roots = {r.rva: r for r in image.routines if r.rva in image.function_entries}
    if not roots:
        return CallIndex(imports, (), "No established function entries to trace.", True,
                         call_tree=CallTree(image, (), partial=True))
    starts = sorted(roots)
    def indexed_owner(at, fallback):
        pos = bisect_right(starts, at) - 1
        if pos >= 0:
            known = roots[starts[pos]]
            if at < known.end and (known.extent.startswith("x64 unwind table")
                                   or not fallback.rva <= at < fallback.end):
                return known
        return fallback

    pending = [(r.rva, r) for r in reversed(tuple(roots.values()))]
    seen, calls, thunks = {}, [], {}
    code = _Code(image, cancel)
    deadline = monotonic() + MAX_SECONDS
    partial = False
    call_text = 0
    tree_sites = []
    tree_text = 0
    tree_limit = False
    data_sites = []
    data_limit = False
    data_text = 0
    while pending and not partial:
        at, owner = pending.pop()
        while at not in seen:
            _check_cancel(cancel)
            if len(seen) >= MAX_VISITED or monotonic() >= deadline or len(roots) > MAX_ENTRIES:
                partial = True
                break
            row = code.get(at)
            if row is None or row.flow == "invalid" or row.op in NON_INSTRUCTIONS:
                break
            seen[at] = len(row.raw)
            owner = roots.get(at, owner)
            target = row.target
            access = None if data_limit else direct_access(row)
            if access is not None:
                address, width, kind = access
                i = bisect_right(image.starts, address) - 1
                if i >= 0 and address + width <= image.sections[i].rva + image.sections[i].size:
                    caller = indexed_owner(at, owner)
                    asm = f"{row.op} {row.args}".rstrip()
                    data_text += len(caller.name) + len(asm)
                    if len(data_sites) >= MAX_DATA_SITES or data_text > MAX_LABEL_BYTES:
                        data_limit = True
                    else:
                        data_sites.append(DataSite(caller, at, row.raw, address, width, kind, asm))
            if row.flow == "call":
                symbol = slots.get(_iat_slot(row, 0x15))
                target = direct_target(row)
                target_routine = None
                kind = "IAT call" if symbol else "Unresolved call"
                if target is not None:
                    kind = "Unverified direct call"
                    section = image.section_at(target)
                    if section and section.executable:
                        if target not in roots:
                            upper = section.rva + section.backed
                            next_root = bisect_right(starts, target)
                            if next_root < len(starts):
                                upper = min(upper, starts[next_root])
                            roots[target] = Routine(target, min(target + MAX_ROUTINE_BYTES, upper),
                                                    f"sub_{target:08X}", "Decoded direct call target")
                        target_routine = roots[target]
                        if target not in seen:
                            pending.append((target, target_routine))
                        if target not in thunks:
                            thunks[target] = _thunk_symbol(code, target, slots)
                        symbol = thunks[target]
                        kind = "Thunk call" if symbol else "Direct call"
                if symbol or not tree_limit:
                    assembly = f"{row.op} {row.args}".rstrip()
                    caller = indexed_owner(at, owner)
                    site = CallSite(caller, at, row.raw, symbol, kind, assembly, target_routine, target)
                    if not tree_limit:
                        tree_text += len(assembly) + len(caller.name)
                        if len(tree_sites) >= MAX_TREE_SITES or tree_text > MAX_LABEL_BYTES:
                            tree_limit = True
                        else:
                            tree_sites.append(site)
                if symbol:
                    call_text += len(symbol.module) + len(symbol.name) + len(assembly) + len(caller.name)
                    if len(calls) >= MAX_CALLS or call_text > MAX_LABEL_BYTES:
                        partial = True
                        break
                    calls.append(site)
            if row.flow in ("jump", "conditional") and target is not None and target not in seen:
                pending.append((target, owner))
            if row.flow in ("indirect", "jump", "return", "stop", "invalid"):
                break
            at += len(row.raw)

    # The matrix and tree retain different budgets. Validate their union once so
    # an import beyond the tree's display cap still has the same boundary checks.
    tree_rvas = {s.rva for s in tree_sites}
    import_rvas = {s.rva for s in calls}
    tree_sites.extend(s for s in calls if s.rva not in tree_rvas)
    valid = tuple(validated_calls(image, tree_sites, seen, cancel))
    shown = tuple(s for s in valid if s.rva in tree_rvas)
    calls = tuple(s for s in valid if s.rva in import_rvas and s.symbol)
    verified_data = tuple(sorted((site for site in data_sites
        if site.routine.rva <= site.rva and site.rva + len(site.raw) <= site.routine.end
        and distinct_instruction(site.rva, seen)), key=lambda site: site.rva))
    tree = CallTree(image, shown, partial=partial or tree_limit or bool(unavailable),
                    omitted=len(tree_rvas) - len(shown))
    summary = f"{len(seen):,} reachable instructions · direct, IAT and jump-thunk calls · direct RIP-relative integer accesses"
    if partial:
        summary = "Partial index (analysis limit) · " + summary
    if unavailable:
        summary += f" · {unavailable} bound import table(s) without names"
    if data_limit:
        summary += " · Partial data index (display limit)"
    if tree_limit:
        summary += " · Partial call tree (display limit)"
    if tree.omitted:
        summary += f" · {tree.omitted} call site(s) without a unique boundary or supported owner omitted from tree"
    if len(calls) < len(import_rvas):
        summary += " · Ambiguous import call evidence omitted"
    if len(verified_data) != len(data_sites):
        summary += " · Ambiguous or out-of-range data references omitted"
        partial = True
    return CallIndex(imports, calls, summary, partial or data_limit or bool(unavailable) or len(calls) < len(import_rvas),
                     verified_data, tree)

