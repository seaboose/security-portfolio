"""Keep immutable DLL snapshots, instruction bookmarks and note revisions in one local database."""

from contextlib import closing
from datetime import datetime, timezone
from hashlib import sha256
from pathlib import Path
import sqlite3

from .knowledge import Knowledge, SCHEMA
from .layout_store import SCHEMA as LAYOUT_SCHEMA


def now():
    return datetime.now(timezone.utc).isoformat(timespec="microseconds")


class Casebook:
    def __init__(self, folder: Path):
        folder.mkdir(parents=True, exist_ok=True)
        self.path = folder / "cases.sqlite3"
        self.db = sqlite3.connect(self.path, timeout=2)
        self.db.row_factory = sqlite3.Row
        self.db.execute("PRAGMA foreign_keys = ON")
        self.db.executescript("""
            CREATE TABLE IF NOT EXISTS artifacts (
                digest TEXT PRIMARY KEY, label TEXT NOT NULL, source TEXT NOT NULL, image BLOB,
                routine TEXT, rva INTEGER, raw BLOB
            );
            CREATE TABLE IF NOT EXISTS session (id INTEGER PRIMARY KEY CHECK(id=1), digest TEXT
                REFERENCES artifacts(digest));
            CREATE TABLE IF NOT EXISTS notes (
                id INTEGER PRIMARY KEY, digest TEXT NOT NULL REFERENCES artifacts(digest),
                routine TEXT NOT NULL, rva INTEGER NOT NULL, raw BLOB NOT NULL
            );
            CREATE TABLE IF NOT EXISTS revisions (
                note INTEGER NOT NULL REFERENCES notes(id), number INTEGER NOT NULL,
                body TEXT NOT NULL, created TEXT NOT NULL, approved TEXT, PRIMARY KEY(note,number)
            );
            CREATE TABLE IF NOT EXISTS finding_reviews (
                note INTEGER, rev INTEGER, tests TEXT NOT NULL, limitations TEXT NOT NULL,
                PRIMARY KEY(note,rev), FOREIGN KEY(note,rev) REFERENCES revisions(note,number)
            );
            CREATE TABLE IF NOT EXISTS finding_predictions (note INTEGER PRIMARY KEY REFERENCES notes(id));
            CREATE TABLE IF NOT EXISTS note_pins (
                digest TEXT PRIMARY KEY REFERENCES artifacts(digest),
                note INTEGER, revision INTEGER, CHECK((note IS NULL) = (revision IS NULL)),
                FOREIGN KEY(note,revision) REFERENCES revisions(note,number)
            );
        """)
        self.db.executescript(SCHEMA)
        self.db.executescript(LAYOUT_SCHEMA)

    def last(self):
        return self.db.execute("SELECT digest FROM session WHERE id=1").fetchone()

    def recent(self):
        return self.db.execute("SELECT digest,label,source FROM artifacts ORDER BY rowid DESC").fetchall()

    def metadata(self, digest):
        return self.db.execute("SELECT digest,label,source,routine,rva,raw FROM artifacts WHERE digest=?",
                               (digest,)).fetchone()

    def activate(self, case, key, row):
        with self.db:
            self.db.execute("BEGIN IMMEDIATE")
            if self.metadata(case.digest) is None:
                self.db.execute("INSERT INTO artifacts(digest,label,source,image) VALUES(?,?,?,?)",
                                (case.digest, case.label, case.source, case.data))
            knowledge = Knowledge(self, case.digest)
            functions = knowledge.functions()
            self.bookmark(case.digest, key, row, commit=False)
            self.db.execute("INSERT INTO session VALUES(1,?) ON CONFLICT(id) DO UPDATE SET digest=excluded.digest",
                            (case.digest,))
        return knowledge, functions

    def bookmark(self, digest, key, row, commit=True):
        self.db.execute("UPDATE artifacts SET routine=?, rva=?, raw=? WHERE digest=?",
                        (key, row.rva, row.raw, digest))
        if commit:
            self.db.commit()

    def notes(self, digest):
        return self.db.execute("SELECT * FROM notes WHERE digest=? ORDER BY id DESC", (digest,)).fetchall()

    def revisions(self, note):
        return self.db.execute("SELECT * FROM revisions WHERE note=? ORDER BY number", (note,)).fetchall()

    def note_pin(self, digest):
        row = self.db.execute("""SELECT p.note,p.revision,n.digest,r.number FROM note_pins p
            LEFT JOIN notes n ON n.id=p.note LEFT JOIN revisions r ON r.note=p.note AND r.number=p.revision
            WHERE p.digest=?""", (digest,)).fetchone()
        if row is None:
            return None  # Older casebooks opened the note at the current instruction.
        note, revision, owner, number = row
        if (note is None) != (revision is None) or (note is not None and (digest != owner or number != revision)):
            raise ValueError("The saved note selection does not match this build and revision.")
        return note, revision

    def pin_note(self, digest, note, revision):
        with self.db:
            if note is None and revision is None:
                changed = self.db.execute("""INSERT OR REPLACE INTO note_pins
                    SELECT digest,NULL,NULL FROM artifacts WHERE digest=?""", (digest,))
            elif any(type(value) is not int or not 0 < value < 2**63 for value in (note,revision)):
                raise ValueError("Choose a saved note and revision for this build.")
            else:
                changed = self.db.execute("""INSERT OR REPLACE INTO note_pins
                    SELECT n.digest,n.id,r.number FROM notes n JOIN revisions r ON r.note=n.id
                    WHERE n.digest=? AND n.id=? AND r.number=?""", (digest,note,revision))
            if changed.rowcount != 1:
                raise ValueError("The requested note or revision does not belong to this build.")

    def save_note(self, digest, key, rva, raw, body, note=None, previous=0, *, prediction=False):
        if not isinstance(body, str) or not 1 <= len(body) <= 16000 or not body.strip():
            raise ValueError("Enter a note of 1 to 16,000 characters.")
        if prediction and (note is not None or previous):
            raise ValueError("A prediction must be saved before the first interpretation.")
        with self.db:
            self.db.execute("BEGIN IMMEDIATE")
            if note is None:
                note = self.db.execute("INSERT INTO notes(digest,routine,rva,raw) VALUES(?,?,?,?)",
                                       (digest,key,rva,raw)).lastrowid
            else:
                stored = self.db.execute("SELECT digest,routine,rva,raw FROM notes WHERE id=?", (note,)).fetchone()
                if not stored or tuple(stored) != (digest,key,rva,raw):
                    raise ValueError("The pinned citation does not match this instruction.")
            latest = self.db.execute("SELECT MAX(number) FROM revisions WHERE note=?", (note,)).fetchone()[0] or 0
            if latest != previous:
                raise ValueError("A newer revision exists. Reopen the note before editing.")
            self.db.execute("INSERT INTO revisions VALUES(?,?,?,?,NULL)", (note, latest+1, body, now()))
            self.db.execute("INSERT OR REPLACE INTO note_pins VALUES(?,?,?)", (digest,note,latest+1))
            if prediction:
                from .findings import mark_prediction
                mark_prediction(self,note)
        return note

    def approve(self, note, number):
        with self.db:
            change = self.db.execute("""UPDATE revisions SET approved=? WHERE note=? AND number=?
                AND approved IS NULL AND number=(SELECT MAX(number) FROM revisions WHERE note=?)""",
                                     (now(),note,number,note))
            if change.rowcount != 1:
                raise ValueError("Only the latest unapproved revision can be approved.")


def read_snapshot(database, digest):
    from .pe import MAX_FILE_SIZE
    with closing(sqlite3.connect(Path(database).as_uri() + "?mode=ro", uri=True)) as db:
        row = db.execute("SELECT image FROM artifacts WHERE digest=? AND length(image) BETWEEN 1 AND ?",
                         (digest, MAX_FILE_SIZE)).fetchone()
    if not row or row[0] is None or sha256(row[0]).hexdigest() != digest:
        raise ValueError("The saved DLL fingerprint does not match its recorded case.")
    return row[0]
