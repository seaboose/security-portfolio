"""Suggest private-function counterparts from bounded, read-only decoded evidence."""

from collections import Counter
from heapq import nsmallest
import re
from time import monotonic

from .binary_diff import FunctionMatch, _check
from .flow_graph import build_graph
from .pe import MAX_ROUTINE_BYTES


DECODE_LIMIT = 24
RESULT_LIMIT = 8
TIME_LIMIT = 12
_COMMON = set("mov movsx movsxd movzx lea push pop enter leave nop int3 endbr64 "
              "add adc sub sbb and or xor cmp test inc dec xchg".split())
_FRAME = re.compile(r"\b(?:[re]?(?:sp|bp)|[sb]pl)\b", re.I)
_LITERAL = re.compile(r"(?:0x([0-9a-f]+)|([0-9][0-9a-f]*)h|(\d+))", re.I)


def _anchors(row):
    if row.flow != "next" or _FRAME.search(row.args):
        return ()
    op = row.op.lower()
    anchors = [] if op in _COMMON else [op]
    # Only a whole immediate operand is evidence. An address in brackets, stack
    # adjustment, branch displacement or register name must not become a fingerprint.
    value = _LITERAL.fullmatch(row.args.rsplit(",", 1)[-1].strip())
    if value and op not in ("push", "pop"):
        hex_value, masm_hex, decimal = value.groups()
        number = int(hex_value or masm_hex or decimal, 10 if decimal else 16)
        if 0xFF < number <= 0xFFFFFFFF and number & (number-1) and number & (number+1):
            anchors.append(f"{op} immediate 0x{number:X}")
    return anchors


def _profile(rows):
    runs, anchors, exits = set(), set(), Counter()
    for number, block in enumerate(build_graph(rows).blocks):
        signature = tuple((e.kind, "unresolved" if e.block is None else
                           "back" if e.block < number else "self" if e.block == number else "forward")
                          for e in block.edges)
        exits[signature] += 1
        for index in range(block.first, block.stop):
            evidence = _anchors(rows[index])
            if evidence:
                anchors.update(evidence)
                for start in range(max(block.first, index-2), min(index+1, block.stop-2)):
                    runs.add(tuple(r.op for r in rows[start:start+3]))
    return runs, anchors, exits


def _score(source, peer):
    runs, anchors = source[0] & peer[0], source[1] & peer[1]
    shared_exits = (source[2] & peer[2]).total()
    if len(runs) < 2 or not anchors or not shared_exits:
        return None
    run_fraction = 2 * len(runs) / (len(source[0]) + len(peer[0]))
    exit_fraction = 2 * shared_exits / (source[2].total() + peer[2].total())
    if run_fraction < .35 or exit_fraction < .4:
        return None
    reason = (f"Advisory · {len(runs)} shared instruction triples (e.g. {' / '.join(min(runs))})"
              f" · {min(anchors)} · {shared_exits} blocks with matching exit patterns · identity unverified")
    return run_fraction + exit_fraction, reason


def is_private(case, routine):
    image = case.image
    return (image is not None and routine is not None and routine.rva in image.function_entries and
            routine.rva != image.entry and routine.rva not in image.export_names)


def suggest_private(left, right, matches, unmatched, cancel=None):
    """Compare one unmatched private range against the closest-sized unresolved peers."""
    _check(cancel)
    builds = left.digest, right.digest
    if (unmatched.status != "Unmatched" or unmatched.builds != builds or
            (unmatched.left is None) == (unmatched.right is None) or unmatched not in matches):
        raise ValueError("Select an unmatched private function from these two builds.")
    from_left = unmatched.left is not None
    case, other = (left, right) if from_left else (right, left)
    origin = unmatched.left or unmatched.right
    if not is_private(case, origin):
        raise ValueError("Select a private function without a named or ordinal export.")
    size = case.image.range_ends[origin.rva] - origin.rva
    if origin.end - origin.rva != size or size > MAX_ROUTINE_BYTES:
        return (), "The selected range exceeds the 16 KiB decoding limit."

    deadline = monotonic() + TIME_LIMIT

    class Budget:
        def is_set(self):
            return (cancel is not None and cancel.is_set()) or monotonic() >= deadline

    budget = Budget()
    candidates = []
    seen = set()
    complete_index = True
    for item in matches:
        _check(cancel)
        if budget.is_set():
            complete_index = False
            break
        if item.builds != builds:
            raise ValueError("The function index belongs to different DLL snapshots.")
        routine = item.right if from_left else item.left
        if (item.status not in ("Candidate", "Unmatched") or not is_private(other, routine)
                or routine.rva in seen):
            continue
        seen.add(routine.rva)
        length = other.image.range_ends[routine.rva] - routine.rva
        if (length == routine.end - routine.rva and length <= MAX_ROUTINE_BYTES
                and size <= length*3 and length <= size*3):
            candidates.append((abs(length-size), routine.rva, routine))
    shortlist = nsmallest(DECODE_LIMIT, candidates, key=lambda item: item[:2])
    ranked = []
    checked = failures = 0
    issue = ""
    try:
        if shortlist and not budget.is_set():
            source = _profile(case.instructions(origin, budget))
            if len(source[0]) < 2 or not source[1]:
                issue = "Insufficient distinctive instruction evidence in the selected range."
                shortlist = ()
            for _, _, peer in shortlist:
                if budget.is_set():
                    break
                try:
                    evidence = _profile(other.instructions(peer, budget))
                except (OSError, ValueError):
                    if budget.is_set():
                        break
                    failures += 1
                    continue
                checked += 1
                score = _score(source, evidence)
                if score:
                    a, b = (origin, peer) if from_left else (peer, origin)
                    match = FunctionMatch(a.name, "Candidate", score[1], a, b, builds)
                    ranked.append((-score[0], peer.rva, match))
    except (OSError, ValueError) as error:
        if not budget.is_set():
            raise ValueError(f"Could not decode the selected private function: {error}") from error
    _check(cancel)
    expired = budget.is_set()
    results = tuple(entry[2] for entry in sorted(ranked, key=lambda x: x[:2])[:RESULT_LIMIT])
    summary = (f"Decoded {checked} of {len(seen)} unresolved private peers indexed. {len(candidates)} complete ranges "
               f"within ⅓–3× size. Closest-size limit {DECODE_LIMIT}, 16 KiB per range, {TIME_LIMIT}s. "
               f"Showing {len(results)} of {len(ranked)} advisory results.")
    if expired:
        summary += " Time limit reached."
    if not complete_index:
        summary += " The function index was only partially searched."
    if failures:
        summary += f" {failures} peer decodes failed."
    if issue:
        summary += " " + issue
    return results, summary
