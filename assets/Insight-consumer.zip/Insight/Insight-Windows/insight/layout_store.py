"""Persist analyst-defined layouts for exact stack storage in one immutable build."""

import json
from itertools import islice
import re

from .knowledge import StaleEdit, Subject
from .records import unique_fields
from .stack_frame import MAX_REGIONS, project_regions
from .struct_layout import Field, Layout, MAX_FIELDS


SCHEMA = """
    CREATE TABLE IF NOT EXISTS stack_layouts (
        digest TEXT NOT NULL REFERENCES artifacts(digest),
        routine TEXT NOT NULL, offset INTEGER NOT NULL, size INTEGER NOT NULL,
        version INTEGER NOT NULL, body BLOB,
        PRIMARY KEY(digest, routine, offset, size, version)
    );
    CREATE TABLE IF NOT EXISTS stack_regions (
        digest TEXT NOT NULL REFERENCES artifacts(digest), routine TEXT NOT NULL,
        offset INTEGER NOT NULL, size INTEGER NOT NULL, PRIMARY KEY(digest,routine,offset,size)
    );
"""
MAX_BODY = 32 * 1024


def _decode(body, size):
    try:
        record = json.loads(body, object_pairs_hook=unique_fields)
        if not isinstance(record, dict) or record.keys() != {"name", "size", "fields"} or record["size"] != size:
            raise ValueError("Invalid stored layout identity or size.")
        fields = record["fields"]
        if not isinstance(fields, list) or len(fields) > MAX_FIELDS:
            raise ValueError("Invalid stored layout field count.")
        if not all(isinstance(row, list) and len(row) == 4 for row in fields):
            raise ValueError("Invalid stored field definition.")
        return Layout(record["name"], record["size"], tuple(Field(*row) for row in fields))
    except (TypeError, ValueError, RecursionError) as error:
        raise ValueError("The saved stack layout is invalid.") from error


class LayoutStore:
    def __init__(self, store, digest):
        if not isinstance(digest, str) or not re.fullmatch("[a-f0-9]{64}", digest) or not store.metadata(digest):
            raise ValueError("Open the saved build before editing a layout.")
        self.db, self.digest = store.db, digest

    def regions(self, routine_key):
        Subject.function(routine_key)
        rows = self.db.execute("""SELECT offset,size FROM stack_regions WHERE digest=? AND routine=?
            ORDER BY offset,size LIMIT ?""", (self.digest, routine_key, MAX_REGIONS + 1))
        pairs = tuple((row[0], row[1]) for row in rows)
        if len(pairs) > MAX_REGIONS:
            raise ValueError("Saved stack regions exceed the supported count.")
        for offset, size in pairs:
            Subject.local(routine_key, offset, size)
        return pairs

    def add_region(self, routine_key, offset, size, slots):
        Subject.local(routine_key, offset, size)
        pair = offset, size
        slots = tuple(islice(slots, 8193))
        with self.db:
            self.db.execute("BEGIN IMMEDIATE")
            existing = self.regions(routine_key)
            native = any((s.offset, s.size) == pair for s in slots)
            included = native or pair in existing
            project_regions(existing if included else (*existing, pair), slots)
            if included:
                return False
            self.db.execute("INSERT INTO stack_regions VALUES(?,?,?,?)",
                            (self.digest, routine_key, offset, size))
        return True

    def remove_region(self, routine_key, offset, size):
        Subject.local(routine_key, offset, size)
        with self.db:
            row = self.db.execute("DELETE FROM stack_regions WHERE digest=? AND routine=? AND offset=? AND size=?",
                                  (self.digest, routine_key, offset, size))
        return row.rowcount == 1

    def _key(self, routine_key, slot):
        Subject.local(routine_key, slot.offset, slot.size)
        return self.digest, routine_key, slot.offset, slot.size

    def _read(self, routine_key, slot, revision=None):
        key = self._key(routine_key, slot)
        clause = "ORDER BY version DESC LIMIT 1" if revision is None else "AND version=?"
        args = key if revision is None else (*key, revision)
        # SQLite can read a BLOB length from its header. Guard the actual read
        # even if a damaged casebook contains a gigabyte-sized or non-BLOB cell.
        row = self.db.execute(f"""SELECT version, typeof(body),
            CASE WHEN typeof(body)='blob' AND length(body)<=? THEN body END FROM stack_layouts
            WHERE digest=? AND routine=? AND offset=? AND size=? {clause}""", (MAX_BODY, *args)).fetchone()
        if row is None:
            if revision is not None:
                raise ValueError("There is no such layout revision for this slot.")
            return None, 0
        version, storage, body = row
        if type(version) is not int or not 1 <= version < 2**63:
            raise ValueError("The saved stack layout exceeds the supported limits.")
        if storage != "null" and (storage != "blob" or not isinstance(body, bytes)):
            raise ValueError("The saved stack layout is invalid.")
        return (_decode(body, slot.size) if body is not None else None), version

    def get(self, routine_key, slot):
        return self._read(routine_key, slot)

    def get_revision(self, routine_key, slot, version):
        if type(version) is not int or not 0 <= version < 2**63:
            raise ValueError("Invalid layout revision.")
        if version == 0:
            self._key(routine_key, slot)
            return None
        return self._read(routine_key, slot, version)[0]

    def versions(self, routine_key, slot, before=None, limit=60):
        if type(limit) is not int or not 1 <= limit <= 200:
            raise ValueError("Choose between 1 and 200 layout revisions.")
        if before is not None and (type(before) is not int or not 0 <= before < 2**63):
            raise ValueError("Invalid layout revision.")
        clause = "" if before is None else "AND version<?"
        args = self._key(routine_key, slot)
        if before is not None:
            args = (*args, before)
        rows = self.db.execute(f"""SELECT version FROM stack_layouts WHERE digest=? AND routine=? AND offset=?
            AND size=? {clause} ORDER BY version DESC LIMIT ?""", (*args, limit))
        revisions = tuple(row[0] for row in rows)
        if not all(type(v) is int and 1 <= v < 2**63 for v in revisions):
            raise ValueError("Invalid stored layout revision.")
        return revisions

    def save(self, routine_key, slot, layout, expected):
        if layout is not None and (not isinstance(layout, Layout) or layout.size != slot.size):
            raise ValueError("The layout must fit the exact selected stack slot.")
        if type(expected) is not int or not 0 <= expected < 2**63 - 1:
            raise ValueError("Invalid layout revision.")
        with self.db:
            self.db.execute("BEGIN IMMEDIATE")
            current, version = self.get(routine_key, slot)
            if expected != version:
                raise StaleEdit("Another editor changed this layout. Reload it before saving.")
            if current == layout:
                return version
            body = None
            if layout is not None:
                fields = [[f.name, f.type_name, f.offset, f.size] for f in layout.fields]
                body = json.dumps(dict(name=layout.name, size=layout.size, fields=fields),
                                  separators=(",", ":")).encode("ascii")
                if len(body) > MAX_BODY:
                    raise ValueError("The layout exceeds its storage limit.")
            self.db.execute("INSERT INTO stack_layouts VALUES(?,?,?,?,?,?)",
                (self.digest, routine_key, slot.offset, slot.size, version + 1, body))
        return version + 1
