"""A cursor-linked native drawer for statically observed callers and callees."""

import tkinter as tk
from tkinter import ttk
from bisect import bisect_left

from .appearance import MONO, MUTED


PAGE = 32
MAX_DEPTH = 8
MAX_SITES = 512


class ContextView(ttk.Frame):
    def __init__(self, parent, follow, close, matrix, select_type):
        super().__init__(parent, padding=6)
        self.follow = follow
        self.function_name = lambda r: r.name
        self.key = self.model = None
        self.branches, self.sites, self.more = {}, {}, {}
        self.columnconfigure(0, weight=1)
        self.rowconfigure(2, weight=1)
        header = ttk.Frame(self)
        header.grid(row=0, column=0, sticky="ew")
        header.columnconfigure(0, weight=1)
        self.heading = ttk.Label(header, style="DockTitle.TLabel")
        self.heading.grid(row=0, column=0, sticky="w")
        ttk.Button(header, text="Close inspector", command=close).grid(row=0, column=1)
        self.location = ttk.Label(self, font=MONO)
        self.location.grid(row=1, column=0, sticky="ew", pady=(2, 4))
        body = ttk.Frame(self)
        body.grid(row=2, column=0, sticky="nsew")
        body.rowconfigure(0, weight=1)
        body.columnconfigure(0, weight=1)
        self.tree = ttk.Treeview(body, show="tree", selectmode="browse", style="Insight.Treeview")
        self.tree.grid(row=0, column=0, sticky="nsew")
        bar = ttk.Scrollbar(body, orient="vertical", command=self.tree.yview, style="Insight.Vertical.TScrollbar")
        bar.grid(row=0, column=1, sticky="ns")
        self.tree.configure(yscrollcommand=bar.set)
        self.tree.bind("<<TreeviewOpen>>", lambda _: self._expand(self.tree.focus()))
        self.tree.bind("<<TreeviewSelect>>", lambda _: self._detail())
        self.tree.bind("<Double-Button-1>", self._double_click)
        self.tree.bind("<Return>", self._activate)
        self.tree.bind("<Escape>", lambda _: close())
        self.evidence = ttk.Label(self, font=MONO)
        self.evidence.grid(row=3, column=0, sticky="ew", pady=(4, 1))
        actions = ttk.Frame(self)
        actions.grid(row=4, column=0, sticky="ew")
        self.open_site = ttk.Button(actions, text="Inspect call site", command=self._activate)
        self.open_site.pack(side="left")
        self.open_routine = ttk.Button(actions, text="Open routine", command=self._routine)
        self.open_routine.pack(side="left", padx=3)
        resources = ttk.Frame(self)
        resources.grid(row=5, column=0, sticky="ew", pady=(3, 0))
        self.matrix = ttk.Button(resources, text="Caller references", command=matrix)
        self.matrix.grid(row=0, column=0, sticky="w")
        self.stack = ttk.Button(resources, text="Stack Frame", command=lambda: select_type("stack"))
        self.stack.grid(row=0, column=1, padx=3, sticky="w")
        self.struct = ttk.Button(resources, text="Struct Layout", command=lambda: select_type("struct"))
        self.status = ttk.Label(self, foreground=MUTED)
        self.status.grid(row=6, column=0, sticky="ew", pady=(3, 0))
        self.bind("<Configure>", self._wrap)

    def clear(self):
        self.key = self.model = None
        self.tree.delete(*self.tree.get_children())
        self.branches.clear()
        self.sites.clear()
        self.more.clear()
        self._detail()

    def _wrap(self, event):
        for label in (self.location, self.evidence, self.status):
            label.configure(wraplength=max(100, event.width-14))
        if self.struct.winfo_manager():
            self._fit_struct(event.width)

    def _fit_struct(self, width):
        narrow = width < sum(w.winfo_reqwidth() for w in (self.matrix, self.stack, self.struct)) + 20
        self.struct.grid(row=int(narrow), column=0 if narrow else 2, sticky="w")

    def show(self, digest, routine, row, model, message, *, dll, has_struct):
        self.heading.configure(text=self.function_name(routine))
        coord = f"RVA 0x{row.rva:X}" if dll else f"+0x{row.rva:X}"
        instruction = f"{coord}   {row.op} {row.args}".rstrip()
        if model is not None and model.digest == digest and row.flow == "call":
            outgoing = model.outgoing(routine.rva)
            position = bisect_left(outgoing, row.rva, key=lambda site: site.rva)
            if position < len(outgoing) and outgoing[position].rva == row.rva:
                instruction += "  →  " + outgoing[position].label
        self.location.configure(text=instruction)
        self.matrix.state(["!disabled" if dll else "disabled"])
        self.stack.state(["!disabled" if dll else "disabled"])
        if has_struct:
            self._fit_struct(self.winfo_width())
        else:
            self.struct.grid_remove()
        self.status.configure(text=message)
        key = (digest, routine, id(model))
        if key == self.key:
            return
        self.clear()
        self.key = key
        if model is None or model.digest != digest:
            return
        self.model = model
        for title, lookup in (("Incoming", model.incoming), ("Outgoing", model.outgoing)):
            count = len(lookup(routine.rva))
            item = self.tree.insert("", "end", text=f"{title} calls   {count:,}", open=True)
            self.branches[item] = (title, routine.rva, (routine.rva,))
            self._expand(item)

    def _expand(self, item, start=0):
        if item not in self.branches:
            return
        direction, at, path = self.branches[item]
        if not start:
            self.branches.pop(item)
            self.tree.delete(*self.tree.get_children(item))
        sites = self.model.incoming(at) if direction == "Incoming" else self.model.outgoing(at)
        for site in sites[start:start+PAGE]:
            if len(self.sites) >= MAX_SITES:
                self.tree.insert(item, "end", text="Tree limit reached. Open a routine to explore from there.")
                return
            neighbor = site.routine if direction == "Incoming" else site.target
            name = self.function_name(site.routine) if direction == "Incoming" else site.label
            if direction == "Outgoing" and site.target:
                name = self.function_name(site.target)
            if direction == "Outgoing" and site.symbol:
                name = site.symbol.name
            cycle = neighbor and neighbor.rva in path
            suffix = "  ·  cycle" if cycle else ""
            child = self.tree.insert(item, "end", text=f"0x{site.rva:X}   {name}{suffix}")
            self.sites[child] = site, neighbor
            if neighbor and not cycle:
                lookup = self.model.incoming if direction == "Incoming" else self.model.outgoing
                if lookup(neighbor.rva):
                    if len(path) < MAX_DEPTH:
                        self.branches[child] = (direction, neighbor.rva, (*path, neighbor.rva))
                        self.tree.insert(child, "end", text="…")
                    else:
                        self.tree.item(child, text=self.tree.item(child, "text") + "  ·  depth limit")
        if start + PAGE < len(sites):
            more = self.tree.insert(item, "end", text=f"Show more · {len(sites)-start-PAGE:,} remaining")
            self.more[more] = (direction, at, path, start+PAGE)

    def _detail(self):
        selected = self.tree.selection()
        record = self.sites.get(selected[0]) if selected else None
        self.open_site.state(["!disabled" if record else "disabled"])
        self.open_routine.state(["!disabled" if record and record[1] else "disabled"])
        text = ""
        if record:
            site = record[0]
            text = f"0x{site.rva:X}   {site.raw.hex(' ').upper()}\n{site.assembly}  ·  {site.kind}"
            if site.symbol:
                text += "\n" + site.label
        self.evidence.configure(text=text)

    def _activate(self, _event=None):
        selected = self.tree.selection()
        if selected and selected[0] in self.more:
            item = selected[0]
            direction, at, path, start = self.more.pop(item)
            parent = self.tree.parent(item)
            self.tree.delete(item)
            self.branches[parent] = (direction, at, path)
            self._expand(parent, start)
            self.branches.pop(parent, None)
        elif selected and selected[0] in self.sites:
            self.follow(self.sites[selected[0]][0], None)
        return "break"

    def _routine(self):
        selected = self.tree.selection()
        if selected and selected[0] in self.sites:
            site, routine = self.sites[selected[0]]
            if routine is not None:
                self.follow(site, routine)

    def _double_click(self, event):
        item = self.tree.identify_row(event.y)
        if item in self.sites or item in self.more:
            self.tree.selection_set(item)
            return self._activate()
