"""Dock the live widgets; each investigation selection and draft has a single owner."""

from tkinter import ttk

from .workspace_settings import capture_geometry, restore_geometry


PANE_NAMES = {"listing": "Listing and bytes", "reader": "Interpretation", "notes": "Analyst notes",
              "structure": "Struct Layout"}


class Sash:
    """Keep a two-pane fraction across resizes; sample after Tk finishes a real drag."""

    def __init__(self, widget, leading, visible=None):
        self.widget, self.leading, self.visible = widget, leading, visible
        self.pending = None
        self.dragging = False
        widget.bind("<ButtonPress-1>", self._press, add="+")
        widget.bind("<ButtonRelease-1>", self._release, add="+")
        widget.bind("<Configure>", self.place, add="+")
        widget.bind("<Destroy>", lambda _: self._cancel(), add="+")

    def _cancel(self):
        if self.pending:
            self.widget.after_cancel(self.pending)
            self.pending = None

    def _press(self, event):
        self.dragging = bool(self.widget.identify(event.x,event.y))
        if self.dragging:
            self._cancel()

    def _release(self, _event):
        if self.dragging:
            self.dragging = False
            self.pending = self.widget.after_idle(lambda:self._apply(remember=True))

    def place(self, _event=None):
        if not self.dragging and self.pending is None:
            self.pending = self.widget.after_idle(self._apply)

    def _apply(self, remember=False):
        self.pending = None
        w = self.widget
        if len(w.panes()) != 2 or (self.visible and not self.visible()):
            return
        vertical = str(w.cget("orient")) == "vertical"
        span = w.winfo_height() if vertical else w.winfo_width()
        if span < 2:
            return
        if remember:
            self.leading = max(.05, min(.95, w.sash_coord(0)[int(vertical)] / span))
        else:
            at = round(span*self.leading)
            w.sash_place(0, 1 if vertical else at, at if vertical else 1)


class WorkspaceDocks:
    def __init__(self, app, changed=None, bind_window=None, unbind_window=None):
        self.app = app
        self.views = views = app.views
        self.widgets = {"listing": views.machine, "reader": views.reader_host,
                        "notes": app.notes, "structure": views.struct}
        self.changed, self.bind_window, self.unbind_window = changed, bind_window, unbind_window
        self.geometries = {}
        self.notes_visible, self.compact_notes = True, False
        self.short = self.applying = self.closed = False
        self.inspector_wanted = False
        self.protocols = {k: app.root.register(lambda key=k:self.redock(key)) for k in self.widgets}
        self.empty = ttk.Frame(views)
        ttk.Label(self.empty, text="Listing and interpretation are in separate windows.").pack(pady=(8, 2))
        ttk.Button(self.empty, text="Dock listing", command=lambda:self.redock("listing")).pack()
        self.notes_sash = Sash(app.dock, .75, lambda:"notes" not in self.detached and
                               not app.root.tk.getboolean(app.dock.panecget(app.notes,"hide")))

    @property
    def detached(self):
        return self.views.floating

    def _notify(self):
        if self.changed and not self.applying and not self.closed:
            self.changed()

    def _main_area(self):
        self.views.refresh_layout()
        if {"listing", "reader"} <= self.detached:
            self.empty.pack(before=self.views.split, fill="x")
        else:
            self.empty.pack_forget()

    def detach(self, pane):
        widget = self.widgets[pane]
        if pane in self.detached:
            widget.lift()
            return
        root, views = self.app.root, self.views
        root.update_idletasks()
        base = capture_geometry(root)
        if base:
            base = dict(base, x=base["x"]+24, y=base["y"]+30,
                        width=max(320, widget.winfo_width()), height=max(170, widget.winfo_height()))
        self.detached.add(pane)
        if pane == "notes":
            self.app.dock.forget(widget)
            self.notes_visible = True
        elif pane == "structure":
            if str(widget) in map(str, views.reader_split.panes()):
                views.reader_split.forget(widget)
            views._struct_position()
        else:
            self._main_area()
        widget.tk.call("wm", "manage", widget._w)
        widget.tk.call("wm", "title", widget._w, f"{PANE_NAMES[pane]} — Insight")
        widget.tk.call("wm", "protocol", widget._w, "WM_DELETE_WINDOW", self.protocols[pane])
        widget.tk.call("wm", "minsize", widget._w, 240, 135)
        restore_geometry(widget, self.geometries.get(pane, base), root)
        if self.bind_window:
            self.bind_window(widget)
        self._notes_presentation()
        self._notify()

    def redock(self, pane):
        if pane not in self.detached:
            return
        widget = self.widgets[pane]
        place = capture_geometry(widget)
        if place:
            self.geometries[pane] = place
        if self.unbind_window:
            self.unbind_window(widget)
        widget.tk.call("wm", "forget", widget._w)
        self.detached.remove(pane)
        if pane == "notes":
            self.app.dock.add(widget, minsize=100, stretch="never")
            self.compact_notes = True
            self._notes_presentation()
        elif pane == "structure":
            self.views._struct_position()
        else:
            self._main_area()
        self._notify()

    def toggle(self, pane):
        (self.redock if pane in self.detached else self.detach)(pane)

    def arrange(self, orientation, listing_first=True):
        if orientation not in ("horizontal", "vertical"):
            raise ValueError("Choose a horizontal or vertical split.")
        self.views.listing_first = listing_first
        self.views.split.configure(orient=orientation)
        self._main_area()
        self._notify()

    def deep(self, enable=True):
        self.views.deep_mode = enable
        self.views._struct_position()
        self._notify()

    def graph(self, enable=True):
        self.views.graph_only = enable
        if enable:
            self.views.active_pane = 1
        self._main_area()
        self._notify()

    def fit(self, short):
        self.app.short_dock = self.short = bool(short)
        self._notes_presentation()

    def _notes_presentation(self):
        floating = "notes" in self.detached
        visible = floating or self.notes_visible and (not self.short or self.compact_notes)
        if not floating:
            self.app.dock.paneconfigure(self.app.notes, hide=not visible)
            if visible:
                self.notes_sash.place()
        button = self.app.notes_toggle
        if self.short or not self.notes_visible or floating:
            button.configure(text="Dock analyst notes" if floating else
                             "Hide analyst notes" if visible else "Show analyst notes")
            button.grid(row=0, column=1, padx=(6, 0))
        else:
            button.grid_remove()

    def set_notes(self, visible):
        if not visible and "notes" in self.detached:
            self.redock("notes")
        self.notes_visible = bool(visible)
        if self.short:
            self.compact_notes = bool(visible)
        self._notes_presentation()
        self._notify()

    def toggle_notes(self):
        if "notes" in self.detached:
            self.redock("notes")
        else:
            hidden = self.app.root.tk.getboolean(self.app.dock.panecget(self.app.notes, "hide"))
            self.set_notes(hidden)
            if hidden:
                self.app.notes.editor.focus_set()

    def capture(self):
        for name, widget in (("main", self.app.root), *((k,self.widgets[k]) for k in self.detached)):
            place = capture_geometry(widget)
            if place:
                self.geometries[name] = place
        views = self.views
        selected = views.reader.select()
        return dict(detached=[k for k in self.widgets if k in self.detached], geometries=dict(self.geometries),
                    split_ratio=views.split_sash.leading, notes_ratio=round(1-self.notes_sash.leading, 6),
                    structure_ratio=round(1-views.struct_sash.leading, 6), compact_notes=self.compact_notes,
                    notes_visible=self.notes_visible, split_orientation=str(views.split.cget("orient")),
                    listing_first=views.listing_first, active_pane=views.active_pane,
                    reader_tab=views.reader.tab(selected,"text") if selected else "Instruction",
                    inspector_open=self.app.xrefs.context_open)

    def restore_inspector(self):
        if self.inspector_wanted and self.app.case and self.app.rows:
            self.inspector_wanted = False
            self.app.xrefs.open_context()

    def apply(self, settings, restore_main=False, restore_inspector=True):
        views = self.views
        self.applying = True
        try:
            if restore_main:
                restore_geometry(self.app.root, settings["geometries"].get("main"))
            if self.app.xrefs.context_open:
                self.app.xrefs.hide_context()
            self.inspector_wanted = settings["inspector_open"] and settings["preset"] not in ("Graph","Deep decompilation")
            for pane in tuple(self.detached):
                if pane not in settings["detached"]:
                    self.redock(pane)
            self.geometries = dict(settings["geometries"])
            views.graph_only = settings["preset"] == "Graph"
            views.active_pane = settings["active_pane"]
            self.deep(settings["preset"] == "Deep decompilation")
            self.arrange(settings["split_orientation"], settings["listing_first"])
            views.split_sash.leading = settings["split_ratio"]
            views.struct_sash.leading = 1-settings["structure_ratio"]
            self.notes_sash.leading = 1-settings["notes_ratio"]
            self.compact_notes = settings["compact_notes"]
            self.notes_visible = settings["notes_visible"]
            self._notes_presentation()
            self.app.root.update_idletasks()
            for pane in settings["detached"]:
                if pane not in self.detached:
                    self.detach(pane)
                else:
                    restore_geometry(self.widgets[pane], self.geometries.get(pane), self.app.root)
            for tab in views.reader.tabs():
                if views.reader.tab(tab,"text") == settings["reader_tab"] and views.reader.tab(tab,"state") != "hidden":
                    views.reader.select(tab)
                    break
            self.notes_sash.place()
            views.split_sash.place()
            views.struct_sash.place()
            if restore_inspector:
                self.restore_inspector()
        finally:
            self.applying = False

    def close(self):
        self.closed = True
        for pane in tuple(self.detached):
            self.redock(pane)
