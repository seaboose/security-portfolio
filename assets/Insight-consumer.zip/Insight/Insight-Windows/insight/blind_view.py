"""Native offline inspection of frozen evidence packets and sealed paired results."""

from pathlib import Path
import tkinter as tk
from tkinter import filedialog, ttk

from . import dialogs
from .appearance import AMBER, CANVAS, INK, MONO, MUTED, SELECTION, scrollable
from .blind import DEFAULT_TRIAL, archived_report, digest, packet, read_manifest


def open_blind(app):
    existing = getattr(app,"blind_window",None)
    if existing and existing.winfo_exists():
        existing.lift()
        return existing
    path = DEFAULT_TRIAL
    if not (path/"manifest.json").is_file():
        path = _choose_manifest(app.root)
        if path is None:
            return
    manifest = read_manifest(path)
    app.blind_window = BlindView(app.root,path,manifest)
    return app.blind_window


def _choose_manifest(parent):
    def browse(owner,_):
        return filedialog.askopenfilename(parent=owner,title="Open frozen trial manifest",
                                          filetypes=(("Trial manifest","manifest.json"),))
    filename = dialogs.input_value(parent,"Open blind trial","Select the trial's manifest.json","Open trial",browse=browse)
    if not filename:
        return None
    file = Path(filename.strip('"'))
    if file.name!="manifest.json":
        raise ValueError("Select the manifest.json from a frozen trial.")
    return file.parent


class BlindView(tk.Toplevel):
    def __init__(self,parent,folder,manifest):
        super().__init__(parent)
        self.title("Blind recovery trial — Insight")
        self.geometry("840x630")
        self.minsize(500,380)
        self.folder, self.manifest = folder,manifest
        self.report = None
        self.columnconfigure(0,weight=1)
        self.rowconfigure(2,weight=1)
        top = ttk.Frame(self,padding=(8,6))
        top.grid(row=0,column=0,sticky="ew")
        ttk.Label(top,text="Anonymous packet").pack(side="left")
        self.pick = ttk.Combobox(top,state="readonly",values=sorted(manifest["slots"]),font=MONO,width=18)
        self.pick.current(0)
        self.pick.pack(side="left",padx=5)
        self.pick.bind("<<ComboboxSelected>>",self.show_packet)
        ttk.Button(top,text="View packet",command=self.show_packet).pack(side="left")
        ttk.Button(top,text="Open trial…",command=self.change_trial).pack(side="left",padx=4)
        self.replay = ttk.Button(top,text="Verify and reveal both…",command=self.reveal)
        self.replay.pack(side="right")
        self.scope = ttk.Label(self,padding=(8,3),foreground=MUTED)
        self.scope.grid(row=1,column=0,sticky="ew")
        self.scope.bind("<Configure>",lambda e:self.scope.configure(wraplength=max(150,e.width-18)))
        box = ttk.Frame(self,padding=(8,4))
        box.grid(row=2,column=0,sticky="nsew")
        self.body = tk.Text(box,font=MONO,state="disabled",wrap="word",width=30,height=12,
                            background=CANVAS,foreground=INK,selectbackground=SELECTION)
        self.body.tag_configure("title",foreground=AMBER)
        scrollable(box,self.body)
        self.status = ttk.Label(self,padding=(8,5))
        self.status.grid(row=3,column=0,sticky="ew")
        self.status.bind("<Configure>",lambda e:self.status.configure(wraplength=max(150,e.width-18)))
        self.show_packet()

    def change_trial(self):
        path = _choose_manifest(self)
        if path is not None:
            manifest = read_manifest(path)
            self.folder, self.manifest, self.report = path,manifest,None
            self.pick.configure(values=sorted(manifest["slots"]))
            self.pick.current(0)
            self.show_packet()

    def display(self,sections):
        self.body.configure(state="normal")
        self.body.delete("1.0","end")
        for heading,lines in sections:
            self.body.insert("end",heading+"\n","title")
            self.body.insert("end","\n".join(lines)+"\n\n")
        self.body.configure(state="disabled")
        self.body.yview_moveto(0)

    def show_packet(self,_event=None):
        data = packet(self.folder,self.pick.get())
        limits = data["settings"]
        self.scope.configure(text=f"{limits['model']} · {limits['effort']} · 1 call per stage · "
                             f"{limits['max_seconds_per_stage']} seconds · {limits['max_reply_bytes']}-byte reply")
        rows = [f"+0x{r['offset']:02X}   {r['bytes']:<19} {r['instruction']}" for r in data["listing"]]
        self.display([("Task",[data["prompt"],data["signature"]]),
                      ("Public examples",[f"now={p['now']}  deadline={p['deadline']}  → {p['result']}" for p in data["public"]]),
                      ("Anonymous routine",rows),("Runner conditions",[limits["isolation"],limits["accounting"]])])
        self.status.configure(text="Packet SHA-256 "+digest(data))

    def reveal(self):
        try:
            self.report = archived_report(self.folder)
        except (OSError,ValueError) as error:
            self.status.configure(text=f"Offline replay unavailable: {error}")
            return
        report = self.report
        self.scope.configure(text=report["rubric"])
        sections = []
        for trial in report["trials"]:
            for stage in trial["stages"]:
                answer,usage,hidden = stage["answer"],stage["usage"],stage["hidden"]
                lines = [f"{stage['fraction'] or 'Unscored'}  ·  {answer['outcome']}  ·  {answer['expression'] or '—'}",
                         answer["reason"], "Instruction offsets: "+(", ".join(f"+0x{i:X}" for i in answer["citations"]) or "none"),
                         f"{usage['calls']} call · {usage['elapsed_ms']} ms · {usage['reply_bytes']} reply bytes",
                         f"Tokens in/out/reasoning: "+"/".join(str(usage[k]) if usage[k] is not None else "unknown"
                                   for k in ("input_tokens","output_tokens","reasoning_tokens")),
                         usage["provenance"]]
                if hidden:
                    lines.extend(f"Miss · now {m['now']:g}, deadline {m['deadline']:g}: expected {m['expected']}, returned {m['actual']}"
                                 for m in hidden["misses"])
                sections.append((f"{trial['build']}  ·  {stage['stage']}  ·  {trial['packet']}",lines))
        control = report["incorrect_control"]["result"]
        sections.append(("Deliberate scoring control",
                         [f"now > deadline · {control['passed']}/{control['total']} · misses at equality for deadlines "
                          +", ".join(str(m["deadline"]) for m in control["misses"])]))
        self.display(sections)
        self.status.configure(text="Verified pair seal SHA-256 "+report["pair_seal_sha256"])
