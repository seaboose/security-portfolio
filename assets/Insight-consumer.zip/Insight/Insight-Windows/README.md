# Insight for Windows

Extract this folder and double-click **Launch Insight.pyw**. Insight runs locally and reads x64 DLLs as data. User notes and saved cases live in your Windows profile.

This distribution uses Windows x64, Python 3.12 or later with Tk, and Microsoft Visual C++ x64 build tools. Decompilation uses Ghidra 12.2 and JDK 25. Insight can use its existing installation under `%LOCALAPPDATA%\Insight\runtime`, or paths set in `GHIDRA_INSTALL_DIR` and `JAVA_HOME`.

On a new machine, install the x64 C++ tools and point those two variables at the extracted Ghidra folder and the JDK folder. [Python for Windows](https://www.python.org/downloads/windows/) · [Microsoft C++ Build Tools](https://visualstudio.microsoft.com/visual-cpp-build-tools/) · [Ghidra releases](https://github.com/NationalSecurityAgency/ghidra/releases) · [Temurin JDK 25](https://adoptium.net/temurin/releases/?version=25)

Choose **Open DLL…** and press **F5** in a routine to decompile it. Select an underlined global in pseudocode to open its cross-references. **Read** and **Write** filter direct references. Open a row to inspect the instruction and its bytes, then choose **Return to** to recover your place. The **Calls** filter finds incoming calls to imports.

Open **Workspace** to choose **Investigation**, **Triage**, **Deep decompilation** or **Graph**. Triage shows strings and imports alongside their original file bytes. Deep decompilation links pseudocode, the listing and Struct Layout when space permits. Graph shows the current block and the selected instruction’s bytes.

Choose **Stack vertically**, **Side by side** or **Swap pane order** to change the split. **Dock and detach** moves a live pane into its own window. Closing that window docks it again. Open **Save current layout…** to keep the arrangement, then choose its name under **Saved layouts** to restore it. Reopening Insight restores the last workspace and the build’s cursor and selected saved note revision.

**Workspace → Keyboard and text size…** offers independent type sizes, a code typeface and editable shortcuts for the Insight, Ghidra, IDA Pro, Binary Ninja and Vim profiles. The shortcuts in this guide use the Insight profile. In the listing, hover over the **Iris** to identify marked instructions. Enable **Entropy overlay** to inspect how nearby byte distributions vary across the file.

Select an underlined local variable in pseudocode to open **Stack Frame**. It shows the variable’s offset from RSP on routine entry, its size and its verified accesses. **Read** and **Write** narrow the list. **All** includes address calculations. Select an access to inspect its bytes, then choose **Return to** to recover the original instruction and variable. From the keyboard, use **Alt+L**, then **Enter**, to open a local.

For the output variable passed to **QueryPerformanceCounter**, choose **Open LARGE_INTEGER layout**. The byte map places LowPart and HighPart over the same eight bytes as QuadPart. Select a field, then a read, to inspect the exact instruction bytes. **Return to** takes you back to the selected field and row.

For another recovered stack local, select its slot and choose **View layout**. To split a slot or group several locals, choose **Define range…**, enter the signed offset from entry RSP and the size, and choose **Open range**. Insight proposes fields from observed memory accesses and shows gaps for unassigned bytes. **Edit layout…** lets you name and type fields, enter offsets and sizes, and model overlaps. Select a field and filter **Read** or **Write** to follow the supporting instruction and exact bytes.

**Save layout** keeps the interpretation with this build, routine and stack storage. Open **Revisions…** to preview and restore an earlier version, or **Use recovered layout** to return to the initial interpretation. Saved revisions remain available after reopening the case.

Choose **Compare builds…** to compare two x64 DLLs or the open snapshot and a second file. Choose **Changed** and select a function. Select a pseudocode line or an instruction to highlight its verified evidence on each side. **Build details…** shows both file identities. **Return to investigation** restores the original workspace. All comparison analysis is read-only.

Open **Graph** beside the listing to see the decoded routine’s basic blocks. Select a block or follow a branch to inspect its exact bytes. Use **Alt+Left** to return to the instruction you came from. The graph identifies incomplete ranges and unresolved branch destinations.

In a two-build comparison, choose a basic block to see its matching evidence, linked pseudocode and instructions. Select a changed immediate value to inspect the two encodings. **Whole function** restores the full listing. For an unmatched private function, **Find private matches…** searches a bounded set of routines in the other build. Selecting a candidate opens it for inspection and leaves its identity advisory.

Press **Ctrl+K** or choose **Find / Go to…** to find an instruction address, function, file-backed string or workbench command. Inspect a string’s original bytes before opening its references. The **Visited** trail returns to a previous instruction in this build. **Inspector** shows the selected routine’s incoming and outgoing calls. Open a caller reference to see its assembly and bytes. The XREF matrix can group results by caller.

If the initial string index covers only part of a large DLL, use the palette’s exact-text search to scan every file-backed section. Each substring match carries its own address and byte range.

In **Analyst notes**, write a hypothesis and choose **Preview** to follow an instruction address such as `@0x181A` in a DLL or `@+0x64` in the pinned example routine. **Save note** creates a revision. Approve a saved revision to export it.

Open **Investigation → Function triage…** to record and filter routine status and confidence. From the listing, press **L** to rename the function or **T** to record a type. In the pseudocode pane, focus a global with **Alt+G** or a stack local with **Alt+L**, then press **L** or **T** to edit that symbol. The display labels belong to this build and preserve the original instruction mappings.

Use **Alt+F** in pseudocode to focus a verified function name. Press **L** or **T** to annotate it, or **Enter** to open its function. Choose **Return to** to recover the original instruction and symbol.

Open **Investigation → Analysis history…** to review, undo and redo symbol or triage edits, including after reopening Insight. **Restore after selected** brings back the state immediately following that edit. A new edit from an earlier point starts a new forward history. Reviewed notes retain their separate revision and approval records.

## Inspect bytes and runtime evidence

- **Tools → Transform bytes…** previews the selected hex bytes or instruction. Use **XOR**, **Base64 decode**, **From hex**, a zlib operation or a bit shift. **Patch proposal** highlights proposed replacements against the original SHA-256-identified source. Input is limited to 16 KiB and expanded output to 64 KiB. **Clear preview** discards the result. The DLL stays read-only.
- **Tools → Live observations…** reads one Windows process snapshot. Enter an authorized running x64 process’s PID and choose **Capture once**. Select a thread to compare timestamped registers and observed bytes with the open DLL. **Show matching instruction** opens a verified match. Captures time out after eight seconds. **Disconnect** clears the sample. Breakpoints and execution controls belong to your external debugger.
- **Tools → Evidence scripts…** accepts six read-only Insight query commands. Type `instructions(cursor, 3)` or open a local file as text, choose **Review**, then **Run reviewed script**. The review identifies the source and current investigation. Runs are limited to 8 KiB of source, 64 commands, two seconds and 32 KiB of output. Source files never run as Python or shell scripts.

## Share a reviewed finding

Use **Investigation → Record prediction…** with a new note to keep your first reading. Investigate the routine, write your interpretation and save a new revision. **Investigation → Review finding…** shows the citations, exact bytes, revision history, checks and limitations. Approve the revision, then export Markdown for a colleague or JSON for a supported Surge investigation. The finding ID and revision identify the same record in both formats.

To inspect a runtime observation, use **File → Open Surge observation…**, select a collector capture and choose the corresponding x64 DLL. Verify its fingerprint, then open the case. The view shows the DLL and captured memory on separate lines. Save a draft pinned to a covered instruction and choose **Cite in saved draft** before approval.

**Investigation → Blind trials…** opens frozen anonymous packets and replays sealed results offline. The separate **Example replay results** command shows the synthetic controls.
