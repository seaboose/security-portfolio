"""Open the Insight desktop investigation from Windows Explorer."""

from ctypes import windll

if __name__ == "__main__":
    try:
        from insight.desktop import launch
        launch()
    except Exception as error:
        try:
            import tkinter as tk
            from insight import dialogs
            root = tk.Tk(className="Insight")
            root.withdraw()
            dialogs.apply_theme(root)
            dialogs.inform(root, "Insight could not start", str(error))
            root.destroy()
        except Exception:
            windll.user32.MessageBoxW(None, str(error), "Insight could not start", 0x10)
